const notificationService = require("../services/notifications");

exports.createNotifications = async (req, res) => {
  const notification = await notificationService.createNotification(req, res);
  return notification;
};
exports.getAllNotifications = async (req, res) => {
  const notification = await notificationService.getAllNotification(req, res);
  return notification;
};
