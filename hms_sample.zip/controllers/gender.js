const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const GenderService = require("../services/gender");
exports.getGender = async (req, res) => {
  try {
    const result = await GenderService.getGenderList(req, res);
    return result;
  } catch (error) {
    return failureResponse(res, 500, error.message);
  }
};
