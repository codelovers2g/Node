const UserService = require("../services/user");

exports.createUser = async (req, res) => {
  const user = await UserService.createUser(req, res);
  return user;
};

exports.getAllUsers = async (req, res) => {
  const user = await UserService.getAllUsers(req, res);
  return user;
};

exports.getUserById = async (req, res) => {
  const user = await UserService.getUserById(req, res);
  return user;
};

exports.updateUser = async (req, res) => {
  const user = await UserService.updateUser(req, res);
  return user;
};

exports.deleteUser = async (req, res) => {
  const user = await UserService.deleteUser(req, res);
  return user;
};
exports.getIdName = async (req, res) => {
  const user = await UserService.getUsersIdName(req, res);
  return user;
};

exports.getDocument = async (req, res) => {
  const user = await UserService.getDocument(req, res);
  return user;
};
