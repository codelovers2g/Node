const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const SkillService = require("../services/skills");
exports.getSkills = async (req, res) => {
  try {
    const result = await SkillService.getSkills(req, res);
    return result;
  } catch (error) {
    return error.message;
  }
};
