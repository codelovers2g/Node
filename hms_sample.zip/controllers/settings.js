const settingService = require("../services/settings");

exports.getSetting = async (req, res) => {
  const settings = await settingService.getSettings(req, res);
  return settings;
};
