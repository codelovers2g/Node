const organisationService = require("../services/organisationService");
const dotenv = require("dotenv");
dotenv.config({ path: "../.env" });
const bcrypt = require("bcrypt");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const { query, conn, connPromise } = require("../config/connection");
const jwt = require("jsonwebtoken");
const { v4: uuidv4 } = require("uuid");
const getAllOrganisationService = require("../services/allorganisations");

exports.register = async (req, res) => {
  try {
    const registerOrganisation = await organisationService.createOrganisation(
      req,
      res
    );
    return registerOrganisation;
  } catch (err) {
    return failureResponse(res, 500, err.message);
  }
};

exports.getAllOrganisations = async (req, res) => {
  try {
    const orgs = await getAllOrganisationService.getAllOrganisations();
    return successResponse(res, "Organizations retrieved", orgs);
  } catch (err) {
    return failureResponse(res, 500, err.message);
  }
};

exports.loginUser = async (req, res) => {
  const user = await organisationService.loginUser(req, res);
  return user;
};
exports.getPermissions = async (req, res) => {
  const permission = await organisationService.getPermissionsByUserId(req, res);
  return permission;
};

exports.changePassword = async (req, res) => {
  const user = await organisationService.changePassword(req, res);
  return user;
};

exports.editLoggedInUserProfile = async (req, res) => {
  const user = await organisationService.editloggedInUserProfile(req, res);
  return user;
};
