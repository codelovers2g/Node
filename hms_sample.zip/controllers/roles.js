const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const RoleService = require("../services/roles");
exports.getRole = async (req, res) => {
  try {
    const result = await RoleService.getRoleList(req, res);
    return result;
  } catch (error) {
    return error.message;
  }
};

exports.getPermissionList = async (req, res) => {
  try {
    const result = await RoleService.getPermissionList(req, res);
    return result;
  } catch (error) {
    return error.message;
  }
};

exports.createRole = async (req, res) => {
  try {
    const result = await RoleService.createRole(req, res);
    return result;
  } catch (error) {
    return error.message;
  }
};

exports.getAllRoles = async (req, res) => {
  try {
    const result = await RoleService.getAllRoles(req, res);
    return result;
  } catch (error) {
    return error.message;
  }
};

exports.getRoleById = async (req, res) => {
  try {
    const result = await RoleService.getRoleById(req, res);
    return result;
  } catch (error) {
    return error.message;
  }
};

exports.updateRole = async (req, res) => {
  try {
    return await RoleService.updateRole(req, res);
  } catch (error) {
    return error.message;
  }
};

exports.deleteRole = async (req, res) => {
  try {
    return RoleService.deleteRole(req, res);
  } catch (error) {
    return error.message;
  }
};
