const DashboardService = require("../services/dashboard");

exports.getAllCandidatesCounts = async (req, res) => {
  const candidate = await DashboardService.candidateCounts(req, res);
  return candidate;
};

exports.getAvarageUserRating = async (req, res) => {
  const rating = await DashboardService.averageUserRating(req, res);
  return rating;
};
exports.getTodayTask = async (req, res) => {
  const task = await DashboardService.getTodayTask(req, res);
  return task;
};
exports.getAverageUserRankingOfDepartment = async (req, res) => {
  const ranking = await DashboardService.averageUserRankingOfDepartments(
    req,
    res
  );
  return ranking;
};
