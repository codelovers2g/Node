const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const OrganisationTypeService = require("../services/organisationTypeService");
exports.getOrganisationType = async (req, res) => {
  try {
    const result = await OrganisationTypeService.getAllOrganisationTypes();
    return successResponse(res, "Fetched", result);
  } catch (error) {
    return failureResponse(res, 500, "Error while fetch organisations types");
  }
};
