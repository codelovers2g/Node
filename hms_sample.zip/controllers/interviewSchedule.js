const interviewService = require("../services/interviewSchedule");

exports.addInterviewSchedule = async (req, res) => {
  const interviewSchedule = await interviewService.addInterviewSchedule(
    req,
    res
  );
  return interviewSchedule;
};
exports.getInterviewDetails = async (req, res) => {
  const interview = await interviewService.getInterviewDetails(req, res);
  return interview;
};
exports.startInterview = async (req, res) => {
  const interview = await interviewService.startInterview(req, res);
  return interview;
};
exports.saveAnswer = async (req, res) => {
  const question = await interviewService.saveAnswer(req, res);
  return question;
};
exports.getQuestionOnIndex = async (req, res) => {
  const question = await interviewService.getQuestionOnIndex(req, res);
  return question;
};

exports.getCandidateByInterviewId = async (req, res) => {
  const question = await interviewService.getCandidateByInterviewId(req, res);
  return question;
};
