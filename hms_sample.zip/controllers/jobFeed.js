const jobFeedService = require("../services/jobFeed");

exports.createJobs = async (req, res) => {
  const Jobs = await jobFeedService.createJobs(req, res);
  return Jobs;
};
exports.getAllJobs = async (req, res) => {
  const Jobs = await jobFeedService.getAllJobs(req, res);
  return Jobs;
};
exports.getJobById = async (req, res) => {
  const Jobs = await jobFeedService.getJobById(req, res);
  return Jobs;
};

exports.editJob = async (req, res) => {
  const Jobs = await jobFeedService.editJob(req, res);
  return Jobs;
};
exports.deleteJob = async (req, res) => {
  const Jobs = await jobFeedService.deleteJob(req, res);
  return Jobs;
};
exports.updateJobStatus = async (req, res) => {
  const Jobs = await jobFeedService.updateJobStatus(req, res);
  return Jobs;
};
exports.shareJob = async (req, res) => {
  const Jobs = await jobFeedService.shareJob(req, res);
  return Jobs;
};
exports.getAllCandidatesOfJobFeed = async (req, res) => {
  const Jobs = await jobFeedService.getCandidatesOfJobFeed(req, res);
  return Jobs;
};

exports.getAllInterviews = async (req, res) => {
  const interviewSchedule = await jobFeedService.getAllInterviews(req, res);
  return interviewSchedule;
};

exports.editInterviews = async (req, res) => {
  const interviewSchedule = await jobFeedService.editInterviewSchedule(
    req,
    res
  );
  return interviewSchedule;
};

exports.setStatus = async (req, res) => {
  const candidate = await jobFeedService.setCandidateStatus(req, res);
  return candidate;
};

exports.getAllJobNames = async (req, res) => {
  const candidate = await jobFeedService.getAllJobNames(req, res);
  return candidate;
};
