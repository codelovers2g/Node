const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const ethnicityService = require("../services/ethnicity");
exports.getEthnicity = async (req, res) => {
  try {
    const result = await ethnicityService.getAllEthnicity(req, res);
    return result;
  } catch (error) {
    return failureResponse(res, 500, error.message);
  }
};
