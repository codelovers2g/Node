const paymentService = require("../services/stripePayment");

exports.createPayment = async (req, res) => {
  const payment = await paymentService.createPaymentIntent(req, res);
  return payment;
};
