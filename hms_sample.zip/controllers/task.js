const taskService = require("../services/task");

exports.createTask = async (req, res) => {
  const task = await taskService.createTask(req, res);
  return task;
};
exports.getTaskById = async (req, res) => {
  const task = await taskService.getTaskById(req, res);
  return task;
};
exports.getAllTasks = async (req, res) => {
  const task = await taskService.getAllTasks(req, res);
  return task;
};
exports.editTask = async (req, res) => {
  const task = await taskService.editTask(req, res);
  return task;
};
exports.deleteTask = async (req, res) => {
  const task = await taskService.deleteTask(req, res);
  return task;
};
exports.getUserDepartmentName = async (req, res) => {
  const task = await taskService.getUserDepartmentName(req, res);
  return task;
};
