const departmentService = require("../services/department");

exports.createDepartment = async (req, res) => {
  const department = await departmentService.createDepartment(req, res);
  return department;
};

exports.getAllDepartments = async (req, res) => {
  const departments = await departmentService.getAllDepartments(req, res);
  return departments;
};
exports.getDepartmentById = async (req, res) => {
  const departments = await departmentService.getDepartmentById(req, res);
  return departments;
};

exports.editDepartments = async (req, res) => {
  const departments = await departmentService.editDepartment(req, res);
  return departments;
};

exports.deleteDepartment = async (req, res) => {
  const departments = await departmentService.deleteDepartment(req, res);
  return departments;
};
exports.viewDepartmentEmployees = async (req, res) => {
  const departments = await departmentService.viewDepartmentEmployees(req, res);
  return departments;
};

exports.totalCandidatesOfDepartment = async (req, res) => {
  const departments = await departmentService.DepartmentTotalCandidates(
    req,
    res
  );
  return departments;
};
