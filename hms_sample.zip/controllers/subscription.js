const subscriptionService = require("../services/subscription");
const { failureResponse } = require("../middlewares/errorHandler");

exports.getSubscriptionDetails = async (req, res) => {
  try {
    const subscriptionDetails =
      await subscriptionService.getSubscriptionDetails(req, res);
    return subscriptionDetails;
  } catch (err) {
    return failureResponse(res, 500, err.message);
  }
};
