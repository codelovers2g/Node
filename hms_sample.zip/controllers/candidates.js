const candidateService = require("../services/candidates");

exports.createCandidate = async (req, res) => {
  const candidate = await candidateService.createCandidate(req, res);
  return candidate;
};

exports.getAllCandidate = async (req, res) => {
  const candidate = await candidateService.getAllCandidates(req, res);
  return candidate;
};
exports.getAllRegisterdCandidates = async (req, res) => {
  const candidate = await candidateService.getAllRegisteredCandidates(req, res);
  return candidate;
};
exports.getCandidateById = async (req, res) => {
  const candidate = await candidateService.getCandidateById(req, res);
  return candidate;
};
exports.updateCandidate = async (req, res) => {
  const candidate = await candidateService.updateCandidate(req, res);
  return candidate;
};
exports.deleteCandidate = async (req, res) => {
  const candidate = await candidateService.deleteCandidate(req, res);
  return candidate;
};

exports.getDocument = async (req, res) => {
  const candidate = await candidateService.getDocument(req, res);
  return candidate;
};

exports.getJobsOfDepartment = async (req, res) => {
  const jobs = await candidateService.getJobFeedsOfDepartment(req, res);
  return jobs;
};
exports.getAllJobsOfCandidate = async (req, res) => {
  const jobs = await candidateService.getAllJobsOfCandidate(req, res);
  return jobs;
};
exports.getAllInformationOfCandidate = async (req, res) => {
  const candidate = await candidateService.getAllInformationOfCandidates(
    req,
    res
  );
  return candidate;
};

exports.candidateBulkUpload = async (req, res) => {
  const candidate = await candidateService.candidateBulkUpload(req, res);
  return candidate;
};
