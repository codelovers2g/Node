const util = require("util");
const mysql = require("mysql2");
const mysqlPromise = require("mysql2/promise");

require("dotenv").config();
//database connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

// converts a callback-based function to a Promise-based one.
const query = util.promisify(pool.query).bind(pool);

const conn = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  multipleStatements: true,
});

const connPromise = mysqlPromise.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  multipleStatements: true,
});

module.exports = { query, conn, connPromise };
