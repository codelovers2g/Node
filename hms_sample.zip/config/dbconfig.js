const { Sequelize } = require("sequelize");
const dotenv = require("dotenv");
const path = require("path");
const envPath = path.join(__dirname, "../.env");
dotenv.config({ path: envPath });

const mainDbConfig = {
  dialect: process.env.DB_DIALECT,
  host: process.env.DB_HOST,
  username: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.MAIN_DB_NAME,
};

const sequelize = new Sequelize(mainDbConfig);

if (process.env.DB_NAMES == undefined) {
  process.env.DB_NAMES = "hms";
} else {
  process.env.DB_NAMES = process.env.DB_NAMES;
}

// Split the DB_NAMES environment variable to get an array of database names
const dbNames = process.env.DB_NAMES.split(",");
console.log("dbNames executed in config +++++++++", dbNames);

const dynamicDbConfigs = dbNames.map((dbName) => ({
  dialect: process.env.DB_DIALECT,
  host: process.env.DB_HOST,
  username: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: dbName,
}));

const sequelizeDynamic = dynamicDbConfigs.map(
  (config) => new Sequelize(config)
);

// process.on("SIGINT", async () => {
//   await Promise.all(sequelizeDynamic.map((sequelize) => sequelize.close()));
//   process.exit(0);
// });

module.exports = { sequelize, sequelizeDynamic };
