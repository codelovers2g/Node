const { Sequelize, UUID, DataTypes, DATE } = require("sequelize");
const { sequelize, sequelizeDynamic } = require("../config/dbconfig");
const { Organisation } = require("./organisation");
require("dotenv").config();
const payment = sequelize.define("Payment", {
  id: {
    type: UUID,
    defaultValue: Sequelize.UUIDV4,
    allowNull: false,
    primaryKey: true,
  },
  organisationId: {
    type: UUID,
    defaultValue: Sequelize.UUIDV4,
    allowNull: false,
    references: {
      model: Organisation,
      key: "Id",
    },
  },
  SubscriptionId: {
    type: UUID,
    allowNull: true,
    defaultValue: null,
  },
  PaymentId: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  Status: {
    type: DataTypes.UUID,
    allowNull: true,
    defaultValue: "Pending",
  },
  createdAt: {
    allowNull: true,
    type: Sequelize.DATE,
    defaultValue: DATE.now,
  },
  updatedAt: {
    allowNull: true,
    type: Sequelize.DATE,
    defaultValue: null,
  },
});
payment.sync({ force: false, alter: true });
module.exports = { sequelize, payment };
