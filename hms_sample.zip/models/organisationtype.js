const { Sequelize, UUID } = require("sequelize");
const { sequelize } = require("../config/dbconfig");
require("dotenv").config();
const OrganisationType = sequelize.define("OrganisationType", {
  Id: {
    type: UUID,
    defaultValue: Sequelize.UUIDV4,
    allowNull: false,
    primaryKey: true,
  },
  OrganisationType: {
    type: Sequelize.STRING,
  },
});
OrganisationType.sync({ force: false });
module.exports = { sequelize, OrganisationType };
