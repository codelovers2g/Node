const { Sequelize, UUID, DataTypes, DATE } = require("sequelize");
const { sequelize, sequelizeDynamic } = require("../config/dbconfig");
require("dotenv").config();
const Organisation = sequelize.define("Organisation", {
  Id: {
    type: UUID,
    defaultValue: DataTypes.UUIDV4,
    allowNull: false,
    primaryKey: true,
  },
  Name: {
    type: Sequelize.STRING,
    allowNull: false,
    unique: true,
  },
  Type: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  Purpose: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  OwnerFirstName: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  OwnerLastName: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  Email: {
    type: Sequelize.STRING,
    allowNull: false,
    unique: true,
  },
  Password: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  Website: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  Address: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  Pin: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  City: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  State: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  Country: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  Revenue: {
    type: Sequelize.STRING,
    allowNull: true,
  },
  ExpectedHiring: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  CompanyGoal: {
    type: Sequelize.TEXT,
    allowNull: true,
    defaultValue: null,
  },
  BriefDescription: {
    type: Sequelize.TEXT,
    allowNull: true,
    defaultValue: null,
  },
  ConnectionString: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  IsActive: {
    type: Sequelize.BOOLEAN,
    allowNull: true,
    defaultValue: true,
  },
  createdAt: {
    allowNull: true,
    type: Sequelize.DATE,
    defaultValue: DATE.now,
  },
  createdBy: {
    type: UUID,
    allowNull: true,
    defaultValue: null,
  },
  updatedAt: {
    allowNull: true,
    defaultValue: null,
    type: Sequelize.DATE,
  },
  updatedBy: {
    type: UUID,
    allowNull: true,
    defaultValue: null,
  },
  isDeleted: {
    allowNull: true,
    defaultValue: false,
    type: Sequelize.BOOLEAN,
  },
  deletedAt: {
    allowNull: true,
    defaultValue: null,
    type: Sequelize.DATE,
  },
  deletedBy: {
    type: UUID,
    allowNull: true,
    defaultValue: null,
  },
});
Organisation.sync({ force: false });
module.exports = { sequelize, Organisation };
