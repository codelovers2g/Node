const { DataTypes } = require("sequelize");
const { sequelizeDynamic } = require("../config/dbconfig");

const Department = sequelizeDynamic.define("Department", {
  id: {
    type: DataTypes.UUID,
    allowNull: false,
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4,
  },
  Name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Department_Rank: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  Manager: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  Description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  Goals: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  createdBy: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  updatedAt: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  updatedBy: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  isDeleted: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  deletedAt: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  deletedBy: {
    type: DataTypes.UUID,
    allowNull: true,
  },
});
Department.sync({ force: false, alter: true });
module.exports = { sequelizeDynamic, Department };
