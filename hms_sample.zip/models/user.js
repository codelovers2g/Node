const { Sequelize, DataTypes } = require("sequelize");
const { sequelizeDynamic } = require("../config/dbconfig");
const jwt = require("jsonwebtoken");
require("dotenv").config();
const User = sequelizeDynamic.define("user", {
  id: {
    type: DataTypes.UUID,
    allowNull: true,
    defaultValue: Sequelize.UUIDV4,
    primaryKey: true,
  },
  EmployeeNumber: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  FirstName: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  LastName: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  Email: {
    type: Sequelize.STRING,
    allowNull: false,
    unique: true,
  },
  Password: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  PhoneNumber: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  GenderId: {
    type: Sequelize.INTEGER,
    allowNull: true,
    defaultValue: null,
  },
  RoleId: {
    type: DataTypes.UUID,
    allowNull: true,
    defaultValue: null,
  },
  EthnicityId: {
    type: Sequelize.INTEGER,
    allowNull: true,
    defaultValue: null,
  },
  DateHired: {
    type: Sequelize.DATE,
    allowNull: true,
    defaultValue: null,
  },
  JobTitle: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  DepartmentId: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  PerformanceMetrics: {
    type: Sequelize.BIGINT,
    allowNull: true,
    defaultValue: null,
  },
  IsEmployee: {
    type: Sequelize.TINYINT,
    allowNull: true,
    defaultValue: null,
  },
  CurrentCompany: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  Experiance: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  InterviewResult: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  DateOfJoining: {
    type: Sequelize.DATE,
    allowNull: true,
    defaultValue: null,
  },
  ExpectedCtc: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  Reliability: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  Behaviour: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  SchoolAttendant: {
    type: Sequelize.TINYINT,
    allowNull: true,
    defaultValue: null,
  },
  Notes: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  UserRank: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  Resume: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  DrivingLicense: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  EmployeeAgreement: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  ProfilePhoto: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  UserToken: {
    type: Sequelize.STRING,
  },
  createdAt: {
    allowNull: false,
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW,
  },
  updatedAt: {
    allowNull: false,
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW,
  },
});

User.prototype.getJwtToken = function () {
  const payload = {
    userId: this.Id,
    email: this.Email,
  };

  const secret = process.env.JWT_SECRET;
  const expiresIn = process.env.JWT_EXPIRY;

  const token = jwt.sign(payload, secret, { expiresIn });

  // Store the JWT in the user model's `userToken` field
  this.UserToken = token;
  this.save();
  return token;
};
if (sequelizeDynamic.config.database !== process.env.MAIN_DB_NAME) {
  User.sync({ force: false });
} else {
  return;
}
module.exports = { sequelizeDynamic, User };
