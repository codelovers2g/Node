const { Sequelize, UUID, DataTypes, DATE } = require("sequelize");
const { sequelize, sequelizeDynamic } = require("../config/dbconfig");
const { Organisation } = require("./organisation");
require("dotenv").config();
const subscription = sequelize.define("subscription", {
  id: {
    type: UUID,
    defaultValue: Sequelize.UUIDV4,
    allowNull: false,
    primaryKey: true,
  },
  organisationId: {
    type: UUID,
    defaultValue: Sequelize.UUIDV4,
    allowNull: false,
    references: {
      model: Organisation,
      key: "Id",
    },
  },
  SubscriptionPackage: {
    type: Sequelize.STRING,
  },
  Amount: {
    type: Sequelize.STRING,
    allowNull: true,
  },
  EmployeeSize: {
    type: Sequelize.STRING,
    allowNull: true,
  },
  SubscriptionPurchaseDate: {
    type: DataTypes.DATE,
  },
  SubscriptionExpiryDate: {
    type: DataTypes.DATE,
  },
});
subscription.sync({ force: false, alter: true });
module.exports = { sequelize, subscription };
