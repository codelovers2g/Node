const { Sequelize, UUID, DataTypes, DATE } = require("sequelize");
const { sequelize, sequelizeDynamic } = require("../config/dbconfig");
const { Organisation } = require("./organisation");
require("dotenv").config();
const notificationclear = sequelize.define("notificationclear", {
  id: {
    type: UUID,
    defaultValue: Sequelize.UUIDV4,
    allowNull: false,
    primaryKey: true,
  },
  UserId: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  CreationDateTime: {
    allowNull: false,
    type: Sequelize.DATE,
    defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
  },
});
notificationclear.sync({ force: false, alter: true });
module.exports = { sequelize, notificationclear };
