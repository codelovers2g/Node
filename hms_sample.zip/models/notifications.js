const { Sequelize, UUID, DataTypes, DATE } = require("sequelize");
const { sequelize, sequelizeDynamic } = require("../config/dbconfig");
const { Organisation } = require("./organisation");
require("dotenv").config();
const notification = sequelize.define("notifications", {
  id: {
    type: UUID,
    defaultValue: Sequelize.UUIDV4,
    allowNull: false,
    primaryKey: true,
  },
  OrganisationId: {
    type: UUID,
    defaultValue: Sequelize.UUIDV4,
    allowNull: false,
    references: {
      model: Organisation,
      key: "Id",
    },
  },
  UserId: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  Message: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  Status: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  CreationDateTime: {
    allowNull: false,
    type: Sequelize.DATE,
    defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
  },
  isDeleted: {
    allowNull: true,
    defaultValue: false,
    type: Sequelize.BOOLEAN,
  },
});
notification.sync({ force: false, alter: true });
module.exports = { sequelize, notification };
