const { Sequelize, UUID, DataTypes, DATE } = require("sequelize");
const { sequelize } = require("../config/dbconfig"); // Import your Sequelize instance

const Candidate = sequelize.define("Candidates", {
  id: {
    type: Sequelize.UUID,
    allowNull: false,
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4,
  },
  FirstName: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  LastName: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  Email: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  PhoneNumber: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  GenderId: {
    type: Sequelize.INTEGER,
    allowNull: true,
    defaultValue: null,
  },
  CurrentState: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  CurrentCity: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  CurrentCompany: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  CurrentCtc: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  ExpectedCtc: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  WorkStatus: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  InterviewResult: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  Resume: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  ProfilePhoto: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null,
  },
  createdAt: {
    allowNull: true,
    type: Sequelize.DATE,
    defaultValue: DATE.now,
  },
  createdBy: {
    type: UUID,
    allowNull: true,
    defaultValue: null,
  },
  updatedAt: {
    allowNull: true,
    defaultValue: null,
    type: Sequelize.DATE,
  },
  updatedBy: {
    type: UUID,
    allowNull: true,
    defaultValue: null,
  },
  isDeleted: {
    allowNull: true,
    defaultValue: false,
    type: Sequelize.BOOLEAN,
  },
  deletedAt: {
    allowNull: true,
    defaultValue: null,
    type: Sequelize.DATE,
  },
  deletedBy: {
    type: UUID,
    allowNull: true,
    defaultValue: null,
  },
});

Candidate.sync({ force: false });
module.exports = { sequelize, Candidate };
