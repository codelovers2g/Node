const { connPromise } = require("../config/connection");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");

class DashboardService {
  static async candidateCounts(req, res) {
    try {
      const conn = await connPromise;

      const [getAllApprovedCandidates] = await conn.query(
        `SELECT COUNT(*) AS ApprovedCounts FROM CandidateInterview AS ci
        JOIN Candidates AS c ON ci.CandidateId = c.id 
        WHERE ci.InterviewStatus = 'Approve' AND c.isDeleted <> 1`
      );
      const [getAllRejectedCandidates] = await conn.query(
        `SELECT COUNT(*) AS RejectCounts FROM CandidateInterview AS ci
        JOIN Candidates AS c ON ci.CandidateId = c.id 
        WHERE InterviewStatus = 'Reject' AND c.isDeleted <> 1`
      );
      const [getAllWaitingCandidates] = await conn.query(
        `SELECT COUNT(*) AS WaitingCounts FROM CandidateInterview AS ci
        JOIN Candidates AS c ON ci.CandidateId = c.id 
        WHERE InterviewStatus = 'waiting' AND c.isDeleted <> 1`
      );
      const [getAllScheduledCandidates] = await conn.query(
        `SELECT COUNT(*) AS ScheduledCounts FROM CandidateInterview AS ci
        JOIN Candidates AS c ON ci.CandidateId = c.id 
        WHERE InterviewStatus = 'scheduled' AND c.isDeleted <> 1`
      );

      const response = {
        ApprovedCounts: getAllApprovedCandidates[0].ApprovedCounts,
        RejectCounts: getAllRejectedCandidates[0].RejectCounts,
        WaitingCounts: getAllWaitingCandidates[0].WaitingCounts,
        ScheduledCounts: getAllScheduledCandidates[0].ScheduledCounts,
      };

      return successResponse(
        res,
        "Candiadtes counts fetched successfully",
        response
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async averageUserRating(req, res) {
    try {
      const conn = await connPromise;

      const [getUsersRating] = await conn.query(
        `SELECT AVG(Rating) AS averageRating FROM CandidateInterview`
      );

      console.log("getUsersRating ++++++++++", getUsersRating);

      return successResponse(
        res,
        "Candiadtes Rating fetched successfully",
        getUsersRating
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async getTodayTask(req, res) {
    try {
      const conn = await connPromise;
      const userId = req.userId;
      const [checkUser] = await conn.query(`SELECT * FROM Users WHERE id = ?`, [
        userId,
      ]);

      if (checkUser.length === 0) {
        return failureResponse(res, 404, "User Not found");
      }

      const user = checkUser[0];

      const [tasks] = await conn.query(
        `SELECT t.* , DATE_FORMAT(t.DueDate, '%Y-%m-%d')  FROM taskassignedto ta
        JOIN task t ON ta.TaskId = t.id
        WHERE ta.UserId = ?
        AND (t.DueDate BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:59'))`,
        [userId]
      );

      // Assuming you want to return the fetched tasks
      return successResponse(res, "Today's tasks fetched successfully", tasks);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async averageUserRankingOfDepartments(req, res) {
    try {
      const conn = await connPromise;

      const [averageRanking] = await conn.query(`
        SELECT AVG(u.UserRank) as averageRank, d.Name as DepartmentName FROM Users u
        JOIN Department d ON u.DepartmentId = d.id
        WHERE d.isDeleted <> 1 AND u.isDeleted <> 1
        GROUP BY d.Name
      `);

      const [totalEmployeesCount] = await conn.query(`
        SELECT COUNT(u.id) as total, d.Name as DepartmentName FROM Users u
        LEFT JOIN Department d ON u.DepartmentId = d.id
        WHERE d.isDeleted <> 1 AND u.isDeleted <> 1
        GROUP BY d.Name
      `);

      const departmentsData = averageRanking.map((item) => {
        const departmentName = item.DepartmentName;
        const averageRank = item.averageRank;
        const totalEmployees = totalEmployeesCount.find(
          (dept) => dept.DepartmentName === departmentName
        ).total;
        return {
          DepartmentName: departmentName,
          averageRank,
          totalEmployees,
        };
      });

      return successResponse(
        res,
        "User rank and total employees fetched successfully",
        departmentsData
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }
}

module.exports = DashboardService;
