const { conn } = require("../config/connection");
const { OrganisationType } = require("../models/organisationtype");

class OrganisationTypeService {
  static async getAllOrganisationTypes() {
    try {
      const organisationTypes = [
        { Id: 1, OrganisationType: "Non-Profit" },
        { Id: 2, OrganisationType: "Government Agency" },
        { Id: 3, OrganisationType: "Educational Institution" },
        { Id: 4, OrganisationType: "Corporation" },
        { Id: 5, OrganisationType: "Small Business" },
      ];

      const existingOrganisationTypes = await OrganisationType.findAll();
      if (existingOrganisationTypes.length > 0) {
        return { organisationType: existingOrganisationTypes };
      }

      const organisationType = await OrganisationType.bulkCreate(
        organisationTypes
      );
      return { organisationType };
    } catch (error) {
      throw new Error(error.message);
    }
  }
}

module.exports = OrganisationTypeService;
