const { connPromise } = require("../config/connection");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
class GenderService {
  static async getGenderList(req, res) {
    try {
      const conn = await connPromise;
      const getGender = await conn.query(`SELECT * FROM gender`);
      return successResponse(res, "Success", getGender[0]);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
}

module.exports = GenderService;
