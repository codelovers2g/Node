const { connPromise } = require("../config/connection");
const { v4: uuidv4 } = require("uuid");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const { notificationclear } = require("../models/notificationclear");
const { io } = require("../socket");
const moment = require("moment/moment");
class NotificationService {
  static async createNotification(req, res) {
    try {
      const userId = req.body.userId;
      const conn = await connPromise;
      const checkNotificationWithUser = await notificationclear.findAll({
        where: {
          userId: req.body.userId,
        },
      });
      if (checkNotificationWithUser.length === 0) {
        const notification = await notificationclear.create({
          id: uuidv4(),
          UserId: userId,
        });
      } else {
        const notification = await notificationclear.update(
          {
            CreationDateTime: new Date(),
          },
          {
            where: {
              UserId: userId,
            },
          }
        );
      }

      const [getnotifications] = await conn.query(
        `SELECT * FROM hms.notifications`
      );

      const [getClearNotifications] = await conn.query(
        `SELECT * FROM hms.notificationclears WHERE UserId = ?`,
        [userId]
      );

      if (getClearNotifications.length > 0) {
        const clearDateTime = moment(
          getClearNotifications[0].CreationDateTime
        ).format("YYYY-MM-DD HH:mm:ss");
        const [result] = await conn.query(
          `SELECT * FROM hms.notifications WHERE CreationDateTime > ?`,
          [clearDateTime]
        );
        io.emit("initialNotifications", result[0]);
      } else {
        const [result] = await conn.query(`SELECT * FROM hms.notifications`);
        io.emit("initialNotifications", result[0]);
      }

      return successResponse(res, "notification cleared successfully");
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async getAllNotification(req, res) {
    try {
      const userId = req.userId;
      const conn = await connPromise;
      const [getnotifications] = await conn.query(
        `SELECT * FROM hms.notifications`
      );

      const [getClearNotifications] = await conn.query(
        `SELECT * FROM hms.notificationclears WHERE UserId = ?`,
        [userId]
      );

      if (getClearNotifications.length > 0) {
        const clearDateTime = moment(
          getClearNotifications[0].CreationDateTime
        ).format("YYYY-MM-DD HH:mm:ss");
        const [result] = await conn.query(
          `SELECT * FROM hms.notifications WHERE CreationDateTime > ?`,
          [clearDateTime]
        );
        await res.json({
          message: "notification get successfully",
          data: result,
        });
        const emit = io.emit("initialNotifications", result);
        console.log(
          "initialNotifications emiited >>>>>>>>>>>>>+++++++++++++++",
          emit
        );
      } else {
        const [result] = await conn.query(`SELECT * FROM hms.notifications`);
        await res.json({
          message: "notification get successfully",
          data: result,
        });
        const emit = io.emit("initialNotifications", result);
        console.log(
          "initialNotifications emiited >>>>>>>>>>>>>+++++++++++++++",
          emit
        );
      }
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }
}

module.exports = NotificationService;
