require("dotenv").config();
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const { connPromise } = require("../config/connection");
const { v4: uuidv4 } = require("uuid");

class PaymentService {
  static async createPaymentIntent(req, res) {
    try {
      const { amount } = req.body;
      const userId = req.userId;
      const organisationId = req.OrganisationId;
      const actualAmount = amount === undefined ? 1 : Math.floor(amount * 100);
      const conn = await connPromise;
      await conn.query(`USE hms_${req.body.organisationName};`);
      const id = uuidv4();
      const expiryDate = new Date(
        new Date().setDate(new Date().getDate() + 30)
      );
      if (!req.body.paymentStatus) {
        // create payment method
        const createPaymentMethod = await stripe.paymentMethods.create({
          type: "card",
          card: {
            number: "4242424242424242",
            exp_month: 9,
            exp_year: 2026,
            cvc: "234",
          },
        });
        // create customer
        const customer = await stripe.customers.create({
          name: "aditya",
          address: {
            line1: "510 Townsend St",
            postal_code: "98140",
            city: "San Francisco",
            state: "CA",
            country: "US",
          },
        });
        // create payment intent
        const paymentIntent = await stripe.paymentIntents.create({
          amount: actualAmount,
          currency: "USD",
          customer: customer.id,
          description: "HRM Application Plan",
          payment_method: createPaymentMethod.id,
          confirm: true,
          payment_method_types: ["card"],
        });

        const savePaymentId = uuidv4();

        await conn.query(
          `UPDATE hms.subscriptions SET SubscriptionPackage = ?,SubscriptionPurchaseDate = ?,
          SubscriptionExpiryDate = ?,Amount =?,EmployeeSize=?,updatedAt = NOW()
          WHERE organisationId =?`,
          [
            req.body.Name,
            new Date(),
            expiryDate,
            req.body.amount,
            req.body.EmployeeSize,
            organisationId,
          ]
        );

        await conn.query(
          `UPDATE subscriptions SET SubscriptionPackage = ?,SubscriptionPurchaseDate = ?,
          SubscriptionExpiryDate = ?,Amount =?,EmployeeSize=?,updatedAt = NOW()
          WHERE organisationId =?`,
          [
            req.body.Name,
            new Date(),
            expiryDate,
            req.body.amount,
            req.body.EmployeeSize,
            organisationId,
          ]
        );

        const [getPlanDetails] = await conn.query(
          `SELECt * FROM hms.subscriptions where organisationId = ?`,
          organisationId
        );

        const [checkPaymentExist] = await conn.query(
          `SELECT * FROM hms.payments WHERE organisationId = ?`,
          organisationId
        );

        if (checkPaymentExist.length === 0) {
          await conn.query(
            `INSERT INTO hms.payments(id,organisationId,SubscriptionId,PaymentId,Status,createdAt) VALUES (?,?,?,?,?,NOW())`,
            [
              savePaymentId,
              organisationId,
              getPlanDetails[0].id,
              null,
              "pending",
            ]
          );
        } else {
          await conn.query(
            "UPDATE hms.payments SET SubscriptionId = ?, PaymentId = ? ,updatedAt = NOW() WHERE organisationId = ?",
            [getPlanDetails[0].id, paymentIntent.id, organisationId]
          );
        }
        res.json({
          success: true,
          clientSecret: paymentIntent,
        });
      } else {
        await conn.query(
          "UPDATE hms.payments SET Status = ?, PaymentId = ? ,updatedAt = NOW() WHERE organisationId = ?",
          [req.body.paymentStatus, req.body.paymentId, organisationId]
        );
      }

      // If the Payment Intent is confirmed successfully, return success response
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }
}

module.exports = PaymentService;
