const { connPromise } = require("../config/connection");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");

class EthnicityService {
  static async getAllEthnicity(req, res) {
    try {
      const conn = await connPromise;
      const getAllEthnicity = await conn.query(`SELECT * FROM ethnicity`);
      return successResponse(res, "Success", getAllEthnicity[0]);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
}

module.exports = EthnicityService;
