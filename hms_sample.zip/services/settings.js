const { connPromise } = require("../config/connection");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");

class SettingsService {
  static async getSettings(req, res) {
    try {
      const conn = await connPromise;
      const { organisationName } = req.query;

      await conn.query(`USE hms_${organisationName};`);

      const [settingData] = await conn.query(`SELECT * FROM settings`);

      return successResponse(res, "Settings", settingData);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
}

module.exports = SettingsService;
