const { connPromise } = require("../config/connection");
const { v4: uuidv4 } = require("uuid");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");

class DepartmentService {
  static async createDepartment(req, res) {
    try {
      const data = req.body;
      const userId = req.userId;
      const id = uuidv4();
      const conn = await connPromise;
      if (!data.Name || !data.Manager) {
        return failureResponse(res, 400, "All fields must be present");
      }

      const [checkDepartmentExist] = await conn.query(
        `SELECT Name FROM Department WHERE Name = ? AND isDeleted <> 1`,
        [data.Name]
      );
      if (checkDepartmentExist.length !== 0) {
        return failureResponse(
          res,
          400,
          "Department with this name already exist"
        );
      }

      const [checkUser] = await conn.query(
        `SELECT * FROM Users WHERE id = ? AND isDeleted <> 1`,
        [data.Manager]
      );
      if (checkUser.length === 0) {
        return failureResponse(res, 404, "Invalid manager Id");
      }
      if (data.Department_Rank) {
        const AllowedDepartmentRankValues = [
          "1",
          "2",
          "3",
          "4",
          "5",
          1,
          2,
          3,
          4,
          5,
        ];

        if (!AllowedDepartmentRankValues.includes(data.Department_Rank)) {
          return failureResponse(res, 404, "Incorrect Department Rank value");
        }
      }

      await conn.query(
        `
      INSERT INTO department (id , Name, Department_Rank,Manager,Description,Goals,createdBy) VALUES (?, ? ,?,?,?,?,?)`,
        [
          id,
          data.Name,
          data.Department_Rank,
          data.Manager,
          data.Description,
          data.Goals,
          userId,
        ]
      );
      return successResponse(res, "Department created successfully", data);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async getAllDepartments(req, res) {
    try {
      const conn = await connPromise;
      const search = req.query.name
        ? `AND d.Name LIKE '%${req.query.name}%'`
        : "";
      const query = `
        SELECT d.*, COUNT(u.id) AS userCount,
          (SELECT SUM(jf.ExpectedHiring) FROM jobfeed jf WHERE jf.Department = d.id AND jf.isDeleted <> 1) AS expectedHiring,
          (SELECT COUNT(c.id) FROM candidates c
            JOIN candidateinterview ci ON c.id = ci.CandidateId
            JOIN jobfeed jf ON ci.SelectedJobId = jf.id
            WHERE jf.Department = d.id AND c.isDeleted <> 1 AND jf.isDeleted <> 1) AS totalCandidates
        FROM Department d
        LEFT JOIN Users u ON d.id = u.DepartmentId AND u.isDeleted <> 1
        WHERE d.isDeleted <> 1 ${search}
        GROUP BY d.id
        ORDER BY createdAt DESC`;

      const [rows] = await conn.query(query);

      return successResponse(
        res,
        "All departments retrieved successfully",
        rows
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async getDepartmentById(req, res) {
    try {
      const conn = await connPromise;
      const id = req.params.id;

      const [departmentRows] = await conn.query(
        `SELECT * FROM Department WHERE id = ? AND isDeleted <> 1`,
        id
      );
      if (departmentRows.length === 0) {
        return failureResponse(res, 404, "Department does not exist");
      }
      const [userCountRows] = await conn.query(
        `SELECT COUNT(id) AS userCount FROM users WHERE DepartmentId = ? AND isDeleted <> 1`,
        id
      );

      // const [managerCountRows] = await conn.query(
      //   `SELECT COUNT(Manager) AS managerCount FROM Department WHERE id = ? AND isDeleted <> 1`,
      //   id
      // );
      const department = {
        ...departmentRows[0],
        userCount: userCountRows[0].userCount,
        // + managerCountRows[0].managerCount,
      };

      return successResponse(
        res,
        "Department retrieved successfully",
        department
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async editDepartment(req, res) {
    try {
      const data = req.body;
      const id = req.params.id;
      const userId = req.userId;
      const conn = await connPromise;

      if (!data.Name || !data.Department_Rank || !data.Manager) {
        return failureResponse(res, 400, "can't save empty values");
      }

      const [departmentName] = await conn.query(
        "SELECT * FROM Department WHERE Name = ? AND id != ? AND isDeleted <> 1",
        [data.Name, id]
      );
      if (departmentName.length !== 0) {
        return failureResponse(res, 400, "Department already exists");
      }

      const [checkDepartment] = await conn.query(
        `SELECT * FROM Department WHERE id = ? AND isDeleted <> 1`,
        id
      );

      if (checkDepartment.length === 0) {
        return failureResponse(res, 404, "Department not found");
      }
      const [checkUser] = await conn.query(
        `SELECT * FROM Users WHERE id = ? AND isDeleted <> 1`,
        [data.Manager]
      );
      if (checkUser.length === 0) {
        return failureResponse(res, 404, "Invalid manager Id");
      }

      await conn.query(
        `UPDATE department SET 
          Name = ?, 
          Department_Rank = ?, 
          Manager = ?, 
          Description = ?, 
          Goals = ?, 
          updatedAt = NOW(),
          updatedBy = ?
        WHERE id = ?`,
        [
          data.Name,
          data.Department_Rank,
          data.Manager,
          data.Description,
          data.Goals,
          userId,
          id,
        ]
      );

      return successResponse(res, "Department updated successfully", data);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async deleteDepartment(req, res) {
    try {
      const id = req.params.id;
      const userId = req.userId;
      const conn = await connPromise;

      const [department] = await conn.query(
        "SELECT * FROM department WHERE id = ? AND isDeleted <> 1",
        [id]
      );
      if (department.length === 0) {
        return failureResponse(res, 404, "Department not found");
      }

      const [countUser] = await conn.query(
        `
        SELECT count(*) as userCount 
        FROM Department d 
        join users u on d.id = u.DepartmentId and u.isDeleted<>1
        where d.id = ? 
        group by d.id
`,
        [id]
      );
      //       const [countUser] = await conn.query(
      //         `
      //   SELECT d.id, d.Name, COUNT(u.id) AS userCount
      //   FROM Department d
      //   LEFT JOIN Users u ON d.id = u.DepartmentId
      //   WHERE (u.isDeleted <> 1 OR u.DepartmentId IS NULL) AND d.isDeleted <> 1 AND d.id = ?
      //   GROUP BY d.id
      // `,
      //         [id]
      //       );
      if (countUser.length > 0) {
        if (countUser[0].userCount > 0) {
          return failureResponse(
            res,
            403,
            "This department contain employees so it can't be deleted"
          );
        }
      }
      const [deletedDepartment] = await conn.query(
        "UPDATE department SET isDeleted=1 , deletedAt = NOW() , deletedBy = ? WHERE id = ?",
        [userId, id]
      );
      return successResponse(
        res,
        "Department deleted successfully",
        deletedDepartment
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async viewDepartmentEmployees(req, res) {
    try {
      const id = req.params.id;
      const startIndex = req.query.startIndex || 0;
      const endIndex = req.query.endIndex || 10;
      const conn = await connPromise;

      const [departmentRows] = await conn.query(
        `SELECT * FROM Department WHERE id = ? AND isDeleted <> 1`,
        id
      );
      if (departmentRows.length === 0) {
        return failureResponse(res, 404, "Department does not exist");
      }

      const query = `
      SELECT u.*
      FROM Department d
      LEFT JOIN Users u ON d.id = u.DepartmentId
      WHERE (u.isDeleted <> 1 OR u.DepartmentId IS NULL) AND (d.isDeleted <> 1 OR d.id IS NULL) AND u.DepartmentId = ?
      GROUP BY u.id
      ORDER BY createdAt DESC
      LIMIT ?, ?`;

      const countQuery = `
      SELECT COUNT(u.id) as totalEmployeesOFDepartment
      FROM Department d
      LEFT JOIN Users u ON d.id = u.DepartmentId
      WHERE u.DepartmentId = ? AND u.isDeleted <> 1`;

      const [rows] = await conn.query(query, [
        id,
        parseInt(startIndex),
        parseInt(endIndex - startIndex),
      ]);

      const [countEmployee] = await conn.query(countQuery, [id]);

      const response = {
        rows,
        totalEmployeesOFDepartment:
          countEmployee.length > 0
            ? countEmployee[0].totalEmployeesOFDepartment
            : 0,
      };

      return successResponse(
        res,
        "Employees of the department retrieved successfully",
        response
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }
  static async DepartmentTotalCandidates(req, res) {
    try {
      const id = req.params.id;
      const conn = await connPromise;

      const [departmentRows] = await conn.query(
        `SELECT * FROM Department WHERE id = ? AND isDeleted <> 1`,
        id
      );
      if (departmentRows.length === 0) {
        return failureResponse(res, 404, "Department does not exist");
      }

      const query = `
      SELECT count(d.id) as totalCandidatesOfDepartment FROM candidates as c
      join candidateinterview as ci ON c.id = ci.CandidateId
      join jobfeed as jf ON ci.SelectedJobId = jf.id
      join department as d ON jf.Department = d.id
      where d.id = ? and d.isDeleted <> 1 and c.isDeleted <> 1 and jf.isDeleted <> 1
      group by d.id`;

      const [countTotalCandidatesOfDepartment] = await conn.query(query, [id]);

      const totalCandidates =
        countTotalCandidatesOfDepartment.length > 0
          ? countTotalCandidatesOfDepartment[0].totalCandidatesOfDepartment
          : 0;

      const expectedHiringquery = `
        SELECT SUM(ExpectedHiring) as expectedHiring FROM jobfeed where Department = ? AND isDeleted <> 1`;

      const [countExpectedHiringInDepartment] = await conn.query(
        expectedHiringquery,
        [id]
      );

      const expectedHiring =
        countExpectedHiringInDepartment.length > 0 &&
        countExpectedHiringInDepartment[0].expectedHiring !== null
          ? countExpectedHiringInDepartment[0].expectedHiring
          : 0;

      const result = {
        totalCandidates,
        expectedHiring,
      };
      return successResponse(
        res,
        "total candidates retrieved successfully",
        result
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }
}

module.exports = DepartmentService;
