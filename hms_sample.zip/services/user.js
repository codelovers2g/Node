const fs = require("fs");
const mime = require("mime-types");
const { v4: uuidv4 } = require("uuid");
require("dotenv").config();
const moment = require("moment");

const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const { connPromise } = require("../config/connection");
const bcrypt = require("bcrypt");
const path = require("path");
const { io } = require("../socket");
const { notification } = require("../models/notifications");
class UserService {
  static async createUser(req, res) {
    try {
      const data = req.body;
      const userId = uuidv4();
      const createdBy = req.userId;
      const OrganisationId = req.OrganisationId;
      const conn = await connPromise;
      const hashPassword = await bcrypt.hash(data.Password, 10);
      data.Password = hashPassword;

      const dateHired =
        data.DateHired != "null" ? moment(data.DateHired, "YYYY/MM/DD") : null;
      const formattedDateHired =
        data.DateHired != "null" ? dateHired.format("YYYY-MM-DD") : null;

      const formattedDateOfJoining = null;

      if (
        !data.EmployeeNumber ||
        !data.FirstName ||
        !data.LastName ||
        !data.Email ||
        !data.Password ||
        !data.GenderId ||
        !data.EthnicityId ||
        !data.DepartmentId ||
        !data.RoleId ||
        !data.Skill ||
        !data.Reliability ||
        !data.Behaviour ||
        !data.PerformanceMetrics ||
        !data.DateHired
      ) {
        return failureResponse(res, 400, "All required fields must be present");
      }

      // Check if the Employee number is valid
      const [checkEmployeeNumber] = await conn.query(
        "SELECT * FROM Users WHERE EmployeeNumber = ? AND isDeleted <> 1",
        [data.EmployeeNumber]
      );
      if (checkEmployeeNumber.length !== 0) {
        return failureResponse(res, 400, "Employee Number already exist");
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.Email)) {
        return failureResponse(res, 400, "Invalid email format");
      }

      // Check if the department ID is valid
      const [checkEmail] = await conn.query(
        "SELECT * FROM Users WHERE Email = ? AND isDeleted <> 1",
        [data.Email]
      );
      if (checkEmail.length !== 0) {
        return failureResponse(res, 400, "Email already exist");
      }

      // Check if the department ID is valid
      const [department] = await conn.query(
        "SELECT * FROM Department WHERE id = ? AND isDeleted <> 1",
        [data.DepartmentId]
      );
      if (department.length === 0) {
        return failureResponse(res, 400, "Invalid department ID");
      }

      // Check if the role ID is valid
      const [role] = await conn.query("SELECT * FROM Role WHERE id = ?", [
        data.RoleId,
      ]);
      if (role.length === 0) {
        return failureResponse(res, 400, "Invalid role ID");
      }
      // Check if the Gender ID is valid
      const [gender] = await conn.query("SELECT * FROM Gender WHERE id = ?", [
        data.GenderId,
      ]);
      if (gender.length === 0) {
        return failureResponse(res, 400, "Invalid Gender ID");
      }
      // Check if the Ethnicity ID is valid
      const [ethnicity] = await conn.query(
        "SELECT * FROM Ethnicity WHERE id = ?",
        [data.EthnicityId]
      );
      if (ethnicity.length === 0) {
        return failureResponse(res, 400, "Invalid Ethnicity ID");
      }

      const allowedUserRankValues = ["1", "2", "3", "4", "5"];
      if (!allowedUserRankValues.includes(data.UserRank)) {
        return failureResponse(res, 404, "Invalid Rank Value");
      }

      data.Resume =
        req.files && req.files["ResumeDoc"]
          ? req.files["ResumeDoc"][0].filename
          : null;

      data.DrivingLicense =
        req.files && req.files["DrivingLicenseDoc"]
          ? req.files["DrivingLicenseDoc"][0].filename
          : null;

      data.EmployeeAgreement =
        req.files && req.files["EmployeeAgreementDoc"]
          ? req.files["EmployeeAgreementDoc"][0].filename
          : null;

      data.ProfilePhoto =
        req.files && req.files["ProfilePhotoDoc"]
          ? req.files["ProfilePhotoDoc"][0].filename
          : null;

      // Insert user data into database, including file paths
      const [result] = await conn.query(
        `INSERT INTO Users (id, EmployeeNumber , FirstName, LastName, Email, Password, PhoneNumber, GenderId,
          RoleId, EthnicityId ,DateHired, JobTitle, DepartmentId, PerformanceMetrics,
          DateOfJoining, 
          Reliability,Behaviour,
          SchoolAttendant,
          Notes,
          UserRank,
          Resume,
          DrivingLicense,
          EmployeeAgreement,
          ProfilePhoto,
          createdBy
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ? , ? , ? , ? , ? ,?)`,
        [
          userId,
          data.EmployeeNumber,
          data.FirstName,
          data.LastName,
          data.Email,
          data.Password,
          data.PhoneNumber,
          data.GenderId,
          data.RoleId,
          data.EthnicityId,
          formattedDateHired,
          data.JobTitle,
          data.DepartmentId,
          data.PerformanceMetrics,
          formattedDateOfJoining,
          data.Reliability,
          data.Behaviour,
          data.SchoolAttendant,
          data.Notes,
          data.UserRank,
          data.Resume,
          data.DrivingLicense,
          data.EmployeeAgreement,
          data.ProfilePhoto,
          createdBy,
        ]
      );
      // Insert user skills into the UserSkill table
      if (data.Skill) {
        let skillArray = [];

        data.Skill.split(",").forEach((element) => {
          skillArray.push(parseInt(element));
        });
        if (skillArray.length > 0) {
          const userSkills = skillArray.map((skillId) => [userId, skillId]);
          await conn.query(`INSERT INTO UserSkill (UserId, SkillId) VALUES ?`, [
            userSkills,
          ]);
        }
      }
      io.emit("userAdded", {
        Message: `${
          data.FirstName + " " + data.LastName
        } is added as an Employee`,
      });

      const notificationId = uuidv4();

      await notification.create({
        id: notificationId,
        OrganisationId: OrganisationId,
        UserId: createdBy,
        Message: `${
          data.FirstName + " " + data.LastName
        } is added as an Employee`,
        Status: "userAdded",
      });
      return res.status(200).send({
        success: true,
        message: "User created successfully",
        result,
        userId,
        data,
      });
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }

  static async getAllUsers(req, res) {
    try {
      const conn = await connPromise;
      // Pagination
      const page = parseInt(req.query.page) || 1; // Set default value to 1 if page is not provided or is NaN
      const limit = parseInt(req.query.limit) || 10;
      const startIndex = (page - 1) * limit;
      const endIndex = page * limit;

      // Sorting
      const sortBy = req.query.sortBy || "createdAt";
      const sortOrder = req.query.sortOrder || "asc";
      const order = sortOrder === "desc" ? "DESC" : "ASC";

      // Searching
      const search = req.query.search || "";

      // Get users
      const query = `
        SELECT u.* FROM Users as u
        JOIN Role as r
        ON u.RoleId = r.id
        WHERE (CONCAT(u.FirstName, ' ', u.LastName) LIKE ? OR u.Email LIKE ?)
        AND u.isDeleted <> 1
        AND r.Name <> 'MasterAdmin'
        ORDER BY ${sortBy} ${order}
        LIMIT ${startIndex},${limit}
      `;

      const params = [`%${search}%`, `%${search}%`, startIndex, limit];

      const [result] = await conn.query(query, params);

      // Get total number of users
      const countQuery = `
        SELECT COUNT(u.id) as total FROM Users as u
        JOIN Role as r
        ON u.RoleId = r.id
        WHERE CONCAT(u.FirstName, ' ', u.LastName) LIKE ?
        AND u.isDeleted <> 1
        AND r.Name <> 'MasterAdmin'
      `;

      const [count] = await conn.query(countQuery, [`%${search}%`]);

      //fetch roles from user
      let roles = [];
      const roleIds = result.map((user) => user.RoleId);
      if (roleIds.length > 0) {
        const roleQuery = `SELECT * FROM Role WHERE id IN (?)`;
        [roles] = await conn.query(roleQuery, [roleIds]);
      }
      //fetch gender from user
      let gender = [];
      const genderIds = result.map((user) => user.GenderId);
      if (genderIds.length > 0) {
        const genderQuery = `SELECT * FROM Gender WHERE id IN (?)`;
        [gender] = await conn.query(genderQuery, [genderIds]);
      }

      //fetch department from user
      let department = [];
      const departmentIds = result.map((user) => user.DepartmentId);
      if (departmentIds.length > 0) {
        const departmentQuery = `SELECT * FROM Department WHERE id IN (?) AND isDeleted <> 1`;
        [department] = await conn.query(departmentQuery, [departmentIds]);
      }

      //fetch Ethnicity from user
      let ethnicity = [];
      const ethnicityIds = result.map((user) => user.EthnicityId);
      if (ethnicityIds.length > 0) {
        const ethnicityQuery = `SELECT * FROM Ethnicity WHERE id IN (?)`;
        [ethnicity] = await conn.query(ethnicityQuery, [ethnicityIds]);
      }

      // Create response object
      const response = {
        success: true,
        data: result.map((user) => {
          return {
            ...user,
            role: roles.find((role) => role.id === user.RoleId),
            gender: gender.find((gender) => gender.id === user.GenderId),
            department: department.find(
              (department) => department.id === user.DepartmentId
            ),
            ethnicity: ethnicity.find(
              (ethnicity) => ethnicity.id === user.EthnicityId
            ),
          };
        }),
        total: count[0].total,
        currentPage: page,
        totalPages: Math.ceil(count[0].total / limit),
      };

      // Add links for pagination
      if (endIndex < count[0].total) {
        response.next = {
          page: page + 1,
          limit: limit,
        };
      }

      if (startIndex > 0) {
        response.previous = {
          page: page - 1,
          limit: limit,
        };
      }

      return successResponse(res, "Users retrieved successfully", response);
    } catch (err) {
      return failureResponse(res, 400, err.message);
    }
  }

  static async getUserById(req, res) {
    try {
      const userId = req.params.id;
      const conn = await connPromise;

      const [result] = await conn.query(
        `SELECT * FROM Users WHERE id IN (?) AND isDeleted <> 1`,
        [userId]
      );

      if (result.length === 0) {
        return failureResponse(res, 404, "User Not found");
      }
      //fetch roles from user
      const roleIds = result.map((user) => user.RoleId);
      const roleQuery = `SELECT * FROM Role WHERE id IN (?)`;
      const [roles] = await conn.query(roleQuery, [roleIds]);

      //fetch gender from user
      const genderIds = result.map((user) => user.GenderId);
      const genderQuery = `SELECT * FROM Gender WHERE id IN (?)`;
      const [gender] = await conn.query(genderQuery, [genderIds]);

      //fetch department from user
      const departmentIds = result.map((user) => user.DepartmentId);
      const departmentQuery = `SELECT * FROM Department WHERE id IN (?) AND isDeleted <> 1`;
      const [department] = await conn.query(departmentQuery, [departmentIds]);

      //fetch Ethnicity from user
      const ethnicityIds = result.map((user) => user.EthnicityId);
      const ethnicityQuery = `SELECT * FROM Ethnicity WHERE id IN (?)`;
      const [ethnicity] = await conn.query(ethnicityQuery, [ethnicityIds]);

      //fetch Skills from userskill
      const [skillsSelected] = await conn.query(
        `
        SELECT s.*
         FROM userskill AS us 
         LEFT JOIN skills as s on us.SkillId = s.id 
         WHERE us.UserId = ?
        `,
        [userId]
      );

      const response = {
        success: true,
        data: result.map((user) => {
          return {
            ...user,
            role: roles.find((role) => role.id === user.RoleId),
            gender: gender.find((gender) => gender.id === user.GenderId),
            department: department.find(
              (department) => department.id === user.DepartmentId
            ),
            ethnicity: ethnicity.find(
              (ethnicity) => ethnicity.id === user.EthnicityId
            ),
            skills: skillsSelected,
          };
        }),
      };

      return successResponse(res, "User found successfully", response);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async updateUser(req, res) {
    try {
      const userId = req.params.id;
      const OrganisationName = req.OrganisationName;
      const conn = await connPromise;
      const hashPassword = await bcrypt.hash(req.body.Password, 10);

      const data = {
        EmployeeNumber:
          req.body.EmployeeNumber === "undefined" ||
          req.body.EmployeeNumber == "null"
            ? null
            : req.body.EmployeeNumber,
        FirstName:
          req.body.FirstName === "undefined" || req.body.FirstName == "null"
            ? null
            : req.body.FirstName,
        LastName:
          req.body.LastName === "undefined" || req.body.LastName === "null"
            ? null
            : req.body.LastName,
        Email:
          req.body.Email === "undefined" || req.body.Email == "null"
            ? null
            : req.body.Email,
        Password:
          req.body.Password === "undefined" || req.body.Password == "null"
            ? null
            : hashPassword,
        PhoneNumber:
          req.body.PhoneNumber === "undefined" || req.body.PhoneNumber == "null"
            ? null
            : req.body.PhoneNumber,
        GenderId:
          req.body.GenderId === "undefined" || req.body.GenderId == "null"
            ? null
            : req.body.GenderId,
        RoleId:
          req.body.RoleId === "undefined" || req.body.RoleId == "null"
            ? null
            : req.body.RoleId,
        EthnicityId:
          req.body.EthnicityId === "undefined" || req.body.EthnicityId == "null"
            ? null
            : req.body.EthnicityId,
        DateHired:
          req.body.DateHired === "undefined" || req.body.DateHired == "null"
            ? null
            : req.body.DateHired,
        JobTitle:
          req.body.JobTitle === "undefined" || req.body.JobTitle == "null"
            ? null
            : req.body.JobTitle,
        DepartmentId:
          req.body.DepartmentId === "undefined" ||
          req.body.DepartmentId == "null"
            ? null
            : req.body.DepartmentId,
        PerformanceMetrics:
          req.body.PerformanceMetrics === "undefined" ||
          req.body.PerformanceMetrics == "null"
            ? null
            : req.body.PerformanceMetrics,
        DateOfJoining:
          req.body.DateOfJoining === "undefined" ||
          req.body.DateOfJoining == "null"
            ? null
            : req.body.DateOfJoining,
        Reliability:
          req.body.Reliability === "undefined" || req.body.Reliability == "null"
            ? null
            : req.body.Reliability,
        Behaviour:
          req.body.Behaviour === "undefined" || req.body.Behaviour == "null"
            ? null
            : req.body.Behaviour,
        SchoolAttendant:
          req.body.SchoolAttendant === "undefined" ||
          req.body.SchoolAttendant == "null"
            ? null
            : req.body.SchoolAttendant,
        Notes:
          req.body.Notes === "undefined" || req.body.Notes == "null"
            ? null
            : req.body.Notes,
        UserRank:
          req.body.UserRank === "undefined" || req.body.UserRank == "null"
            ? null
            : req.body.UserRank,
        Resume:
          req.body.Resume === "undefined" || req.body.Resume == "null"
            ? null
            : req.body.Resume,
        DrivingLicense:
          req.body.DrivingLicense === "undefined" ||
          req.body.DrivingLicense == "null"
            ? null
            : req.body.DrivingLicense,
        EmployeeAgreement:
          req.body.EmployeeAgreement === "undefined" ||
          req.body.EmployeeAgreement == "null"
            ? null
            : req.body.EmployeeAgreement,
        ProfilePhoto:
          req.body.ProfilePhoto === "undefined" ||
          req.body.ProfilePhoto == "null"
            ? null
            : req.body.ProfilePhoto,
      };

      const userExistsQuery =
        "SELECT * FROM users WHERE id = ? AND isDeleted <> 1";
      const [existingUser] = await conn.query(userExistsQuery, [userId]);

      if (existingUser.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }
      const [existingEmployeeNumber] = await conn.query(
        "SELECT * FROM users WHERE EmployeeNumber = ? AND id != ? AND isDeleted <> 1",
        [data.EmployeeNumber, userId]
      );
      if (existingEmployeeNumber.length !== 0) {
        return failureResponse(res, 400, "Employee Number already exists");
      }

      const [existingEmail] = await conn.query(
        "SELECT * FROM users WHERE Email = ? AND id != ? AND isDeleted <> 1",
        [data.Email, userId]
      );

      if (existingEmail.length !== 0) {
        return failureResponse(res, 400, "Email already exists");
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.Email)) {
        return failureResponse(res, 400, "Invalid email format");
      }

      // Check if the department ID is valid
      const [department] = await conn.query(
        "SELECT * FROM Department WHERE id = ? AND isDeleted <> 1",
        [data.DepartmentId]
      );
      if (department.length === 0) {
        return failureResponse(res, 400, "Invalid department ID");
      }

      // Check if the role ID is valid
      const [role] = await conn.query("SELECT * FROM Role WHERE id = ?", [
        data.RoleId,
      ]);
      if (role.length === 0) {
        return failureResponse(res, 400, "Invalid role ID");
      }
      // Check if the Gender ID is valid
      const [gender] = await conn.query("SELECT * FROM Gender WHERE id = ?", [
        data.GenderId,
      ]);
      if (gender.length === 0) {
        return failureResponse(res, 400, "Invalid Gender ID");
      }
      // Check if the Ethnicity ID is valid
      const [ethnicity] = await conn.query(
        "SELECT * FROM Ethnicity WHERE id = ?",
        [data.EthnicityId]
      );
      if (ethnicity.length === 0) {
        return failureResponse(res, 400, "Invalid Ethnicity ID");
      }

      const allowedUserRankValues = ["1", "2", "3", "4", "5"];
      if (!allowedUserRankValues.includes(data.UserRank)) {
        return failureResponse(res, 404, "Invalid Rank Value");
      }

      const filePath = path.join(__dirname, "../Files", OrganisationName);

      const fileExists = fs.existsSync(filePath);
      // if (!fileExists) {
      //   return failureResponse(res, 404, "File not found");
      // }

      if (!fileExists) {
        try {
          fs.mkdirSync(filePath);
        } catch (err) {}
      } else {
      }

      if (req.body.Skill) {
        const skillIds = req.body.Skill.split(",").map((skillId) =>
          parseInt(skillId.trim())
        );

        // Delete existing user skills
        await conn.query("DELETE FROM UserSkill WHERE UserId = ?", [userId]);

        // Insert updated user skills
        if (skillIds.length > 0) {
          const userSkills = skillIds.map((skillId) => [userId, skillId]);
          await conn.query("INSERT INTO UserSkill (UserId, SkillId) VALUES ?", [
            userSkills,
          ]);
        }
      }
      if (req.files) {
        if (
          !req?.files["ResumeDoc"] &&
          (!data.Resume || data.Resume === "") &&
          existingUser[0].Resume
        ) {
          fs.unlinkSync(
            filePath + `\\${existingUser[0].Resume}`,
            (error) => {}
          );
        } else if (req?.files["ResumeDoc"]) {
          data.Resume =
            req.files && req?.files["ResumeDoc"]
              ? req?.files["ResumeDoc"][0]?.filename
              : null;
          if (existingUser[0].Resume) {
            fs.unlinkSync(
              filePath + `\\${existingUser[0].Resume}`,
              (error) => {}
            );
          }
        }

        if (
          !req.files["DrivingLicenseDoc"] &&
          (!data.DrivingLicense || data.DrivingLicense === "") &&
          existingUser[0].DrivingLicense
        ) {
          fs.unlinkSync(
            filePath + `\\${existingUser[0].DrivingLicense}`,
            (error) => {}
          );
        } else if (req.files["DrivingLicenseDoc"]) {
          data.DrivingLicense =
            req.files && req.files["DrivingLicenseDoc"]
              ? req.files["DrivingLicenseDoc"][0].filename
              : null;
          if (existingUser[0].DrivingLicense) {
            fs.unlinkSync(
              filePath + `\\${existingUser[0].DrivingLicense}`,
              (error) => {}
            );
          }
        }

        if (
          !req.files["EmployeeAgreementDoc"] &&
          (!data.EmployeeAgreement || data.EmployeeAgreement === "") &&
          existingUser[0].EmployeeAgreement
        ) {
          fs.unlinkSync(
            filePath + `\\${existingUser[0].EmployeeAgreement}`,
            (error) => {}
          );
        } else if (req.files["EmployeeAgreementDoc"]) {
          data.EmployeeAgreement =
            req.files && req.files["EmployeeAgreementDoc"]
              ? req.files["EmployeeAgreementDoc"][0].filename
              : null;
          if (existingUser[0].EmployeeAgreement) {
            fs.unlinkSync(
              filePath + `\\${existingUser[0].EmployeeAgreement}`,
              (error) => {}
            );
          }
        }

        if (
          !req.files["ProfilePhotoDoc"] &&
          (!data.ProfilePhoto || data.ProfilePhoto === "") &&
          existingUser[0].ProfilePhoto
        ) {
          fs.unlinkSync(
            filePath + `\\${existingUser[0].ProfilePhoto}`,
            (error) => {}
          );
        } else if (req.files["ProfilePhotoDoc"]) {
          data.ProfilePhoto =
            req.files && req.files["ProfilePhotoDoc"]
              ? req.files["ProfilePhotoDoc"][0].filename
              : null;
          if (existingUser[0].ProfilePhoto) {
            fs.unlinkSync(
              filePath + `\\${existingUser[0].ProfilePhoto}`,
              (error) => {}
            );
          }
        }
      }

      if (req.body.Password) {
        req.body.Password = hashPassword;
      }

      const [result] = await conn.query(`UPDATE users SET ? WHERE id = ?`, [
        data,
        userId,
      ]);

      return res.status(200).json({
        success: true,
        message: "User updated successfully",
        result,
        data,
      });
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async deleteUser(req, res) {
    try {
      const id = req.params.id;
      const conn = await connPromise;

      const [userCount] = await conn.query(
        "SELECT * FROM users WHERE isDeleted <> 1"
      );
      if (userCount.length === 1)
        return failureResponse(res, 403, "Last user can't be deleted");

      const [user] = await conn.query("SELECT * FROM users WHERE id = ?", [id]);
      if (user.length === 0) {
        return failureResponse(res, 404, "user not found");
      }
      const deletedUser = await conn.query(
        "UPDATE users SET isDeleted=1 WHERE id = ?",
        [id]
      );
      return successResponse(res, "User deleted successfully", deletedUser);
    } catch (err) {
      return failureResponse(res, 400, err.message);
    }
  }

  static async getUsersIdName(req, res) {
    try {
      const conn = await connPromise;

      const [getIdName] = await conn.query(
        `SELECT id , FirstName , LastName FROM Users WHERE isDeleted <> 1`
      );

      if (getIdName.length === 0) {
        return failureResponse(res, 404, "No user founds");
      }

      const response = getIdName.map((user) => {
        const name = `${user.FirstName} ${user.LastName}`;
        return { id: user.id, name };
      });

      return successResponse(res, "Id Names list fethed", response);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
  static async getDocument(req, res) {
    try {
      const documentName = req.body.documentName;
      const OrganisationName = req.OrganisationName;
      const filePath = path.join(
        __dirname,
        "../Files",
        OrganisationName,
        documentName
      );

      const mimeType = mime.lookup(filePath.split("(#")[0]);

      await res.set("Content-Type", mimeType);
      await res.set(
        "Content-Disposition",
        `attachment; filename="${documentName.split("(#")[0]}"`
      );

      const fileExists = fs.existsSync(filePath);
      if (!fileExists) {
        return failureResponse(res, 404, "File not found");
      }

      const fileStream = fs.createReadStream(filePath);
      await fileStream.pipe(res);
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }
}

module.exports = UserService;
