const { connPromise } = require("../config/connection");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
class SkillService {
  static async getSkills(req, res) {
    try {
      const conn = await connPromise;
      const getSkills = await conn.query(`SELECT * FROM Skills`);
      return successResponse(res, "Success", getSkills[0]);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
}

module.exports = SkillService;
