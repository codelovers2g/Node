const express = require("express");
const app = express();
const fs = require("fs");
const mime = require("mime-types");
const { v4: uuidv4 } = require("uuid");
const pdfService = require("../utils/pdf");
require("dotenv").config();

const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const { connPromise, conn } = require("../config/connection");
const path = require("path");

const { Configuration, OpenAIApi } = require("openai");

const configuration = new Configuration({
  apiKey: process.env.OPEN_AI_SECRETKEY,
});
const openai = new OpenAIApi(configuration);

const { io } = require("../socket");
const { notification } = require("../models/notifications");
const csv = require("fast-csv");
const { Candidate } = require("../models/candidate");
class CandidateService {
  // Function to dynamically construct the prompt based on the candidate data and job details
  static async constructPrompt(data, jobNames, pdfText) {
    const providedData = JSON.stringify(data);
    const formatData = providedData.replace(/{/g, "'").replace(/}/g, "'");
    let prompt = `
        Job: ${jobNames}
      Please analyze the job requirements for the provided job name by yourself. Consider the typical technical skills associated with this provided job
      and analyze the key technical skills required for the provided job.

    Resume: ${pdfText}

    Next, analyze the candidate's technical skills and experiences from the provided resume. Identify and evaluate how well the
    candidate's relevent technical skills , which you analyze from the resume , align with the job requirements ,
    which you analyze by youself, for the ${jobNames} role. Provide an assessment of whether
    the candidate is a good fit for the role ${jobNames} , based on their technical skills and experiences.

    Note: The job name is dynamic and can vary widely (e.g., Software Engineer, Data Analyst, Product Manager, etc.), so the generated job
    requirements should be relevant to the specific job requirements provided. Also If the candidate's technical skills strongly match the required job
    requirements then you have to give the strong match for the role . otherwise gives the weak match for the role.`;

    prompt += `Also give the rating along with the analysis ,in a varaible name 'Rating' from value 1 to 5 where 1 is the lowest rating and 5 is the highest rating,
    If the candidate is strong match to the relevent job requirements, then gives the higher rating like 4 or 5 , otherwise gives the lower rating from 1, 2 or 3.`;

    prompt += `Also give a matching score in a variable name 'MatchingScore' indicate the percentage of how well the candidate fit for the job role.`;

    return JSON.stringify(prompt);
  }

  // Function to analyze candidate and generate review, rating, and matching
  static async analyzeCandidate(
    data,
    jobNames,
    pdfText,
    createdBy,
    candidateId
  ) {
    try {
      let userSendData = "";
      const aiResponces = [];
      Object.entries(data).forEach(([key, value]) => {
        userSendData += `${key}: ${value}\n`;
      });
      for (const x of jobNames) {
        // Construct the prompt for analyzing the candidate
        const prompt = CandidateService.constructPrompt(data, x, pdfText);

        // Make a request to ChatGPT to generate the analysis
        const response = await openai.createChatCompletion({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "Act as a senior recruiter" },
            {
              role: "user",
              content: (await prompt).replace(/{/g, "'"),
            },
          ],
          temperature: 0.4,
          max_tokens: 1000,
          top_p: 1.0,
          frequency_penalty: 0.0,
          presence_penalty: 0.0,
        });

        // const analysis = response.data.choices[0].message.content.trim();
        const messages = response.data.choices[0].message;
        const analysis = messages.content.trim();

        const ratingRegex = /Rating:\s*(\d+)/;
        const matchingRegex =
          /MatchingScore:\s*(\d+)/ ||
          /matching score:\s*(\d+)/ ||
          /Matching Score:\s*(\d+)/;
        const ratingMatch = messages.content.match(ratingRegex);
        const matchingMatch = messages.content.match(matchingRegex);

        const singleDigitRegex =
          /(?:Rating|The Rating for this match would be)\s*(\d+)\s*(?:out of 5)?/;
        const percentageRegex = /(\d+)%/;
        const singleDigitMatch = analysis.match(singleDigitRegex);
        const percentageMatch = analysis.match(percentageRegex);

        let rating, matching;

        if (ratingMatch) {
          rating = parseInt(ratingMatch[1]);
        } else if (singleDigitMatch) {
          rating = parseInt(singleDigitMatch[1]);
        } else {
          rating = 1;
        }

        if (matchingMatch) {
          matching = parseInt(matchingMatch[1]);
        } else if (percentageMatch) {
          matching = parseInt(percentageMatch[1]);
        } else {
          matching = 0;
        }

        const auditLogData = {
          CreatedBy: createdBy,
          Type: "CandidateCreate",
          Model: response.data.model,
          Messages: response.config.data,
          InputTokens: response.data.usage.prompt_tokens,
          ResponseTokens: response.data.usage.completion_tokens,
          TotalTokens: response.data.usage.total_tokens,
          RequestType: response.config.method,
          Response: analysis,
          StatusCode: response.status,
          RecordId: candidateId,
        };
        const conn = await connPromise;
        // Insert audit log entry with input data and response details
        const [auditLogEntry] = await conn.query(
          `INSERT INTO AuditLogs (CreatedBy, Type, Model, Messages, InputTokens, ResponseTokens, TotalTokens, RequestType, Response, StatusCode, RecordId) 
         VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            auditLogData.CreatedBy,
            auditLogData.Type,
            auditLogData.Model,
            auditLogData.Messages,
            auditLogData.InputTokens,
            auditLogData.ResponseTokens,
            auditLogData.TotalTokens,
            auditLogData.RequestType,
            auditLogData.Response,
            auditLogData.StatusCode,
            auditLogData.RecordId,
          ]
        );

        aiResponces.push({
          analysis: analysis,
          rating: rating,
          matching: matching,
        });
      }
      return aiResponces;
    } catch (error) {
      if (error.response && error.response.data) {
        console.error("Error Response:", error.response.data);
      }
      throw error;
    }
  }

  static async createCandidate(req, res) {
    try {
      const data = req.body;
      const createdBy = req.userId;
      const candidateId = uuidv4();
      const OrganisationId = req.OrganisationId;
      const conn = await connPromise;

      const documentName = req.files["ResumeDoc"][0].filename;
      const OrganisationName = req.OrganisationName;
      const filePath = path.join(
        __dirname,
        "../Files",
        OrganisationName,
        documentName
      );

      const pdfText = await pdfService.pdfToText(filePath);

      if (
        !data.FirstName ||
        !data.LastName ||
        !data.Email ||
        !data.PhoneNumber
      ) {
        return failureResponse(res, 400, "All required fields must be present");
      }
      // Check if the department ID is valid
      const [checkEmail] = await conn.query(
        "SELECT * FROM Candidates WHERE Email = ? AND isDeleted <> 1",
        [data.Email]
      );
      if (checkEmail.length !== 0) {
        return failureResponse(res, 400, "Email already exist");
      }
      // Check if the Gender ID is valid
      const [gender] = await conn.query("SELECT * FROM Gender WHERE id = ?", [
        data.GenderId,
      ]);
      if (gender.length === 0) {
        return failureResponse(res, 400, "Invalid Gender ID");
      }

      data.Resume =
        req.files && req.files["ResumeDoc"]
          ? req.files["ResumeDoc"][0].filename
          : null;

      data.ProfilePhoto =
        req.files && req.files["ProfilePhotoDoc"]
          ? req.files["ProfilePhotoDoc"][0].filename
          : null;

      const workStatus = ["Experienced", "Fresher"];

      if (!workStatus.includes(data.WorkStatus)) {
        return failureResponse(res, 400, "Invalid work status value");
      }

      // Check if the job IDs are valid
      let jobs = data.SelectedJobId.split(",");
      const jobNames = [];

      if (jobs?.length > 0) {
        for (const jobId of jobs) {
          const [jobTitleResult] = await conn.query(
            "SELECT Title FROM JobFeed WHERE id = ?",
            [jobId]
          );

          if (jobTitleResult.length > 0) {
            jobNames.push(jobTitleResult[0].Title);
          }
        }
      } else {
        return failureResponse(res, 400, "Job feed is required");
      }

      if (jobNames.length === 0) {
        return failureResponse(res, 400, "Enter valid Job feeds");
      }

      // const jobNames = jobTitles;

      const AIResponseResult = CandidateService.analyzeCandidate(
        data,
        jobNames,
        pdfText,
        createdBy,
        candidateId
      );

      // Insert user data into database, including file paths
      await conn.query(
        `INSERT INTO Candidates (id, FirstName, LastName, Email, PhoneNumber, GenderId,
        WorkStatus, CurrentState,CurrentCity,
        CurrentCompany, 
        CurrentCtc,
        ExpectedCtc,
        Resume,
        ProfilePhoto,
        createdBy
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?  , ? , ? , ? , ?,?)`,
        [
          candidateId,
          data.FirstName,
          data.LastName,
          data.Email,
          data.PhoneNumber,
          data.GenderId,
          data.WorkStatus,
          data.CurrentState,
          data.CurrentCity,
          data.CurrentCompany,
          data.CurrentCtc,
          data.ExpectedCtc,
          data.Resume,
          data.ProfilePhoto,
          createdBy,
        ]
      );

      //Insert candidate in main database
      await conn.query(
        `INSERT INTO hms.Candidates (id, FirstName, LastName, Email, PhoneNumber, GenderId,
        WorkStatus, CurrentState,CurrentCity,
        CurrentCompany, 
        CurrentCtc,
        ExpectedCtc,
        Resume,
        ProfilePhoto,
        createdAt,
        createdBy
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?  , ? , ? , ? , ?,NOW(),?)`,
        [
          candidateId,
          data.FirstName,
          data.LastName,
          data.Email,
          data.PhoneNumber,
          data.GenderId,
          data.WorkStatus,
          data.CurrentState,
          data.CurrentCity,
          data.CurrentCompany,
          data.CurrentCtc,
          data.ExpectedCtc,
          data.Resume,
          data.ProfilePhoto,
          createdBy,
        ]
      );
      if (data.SelectedJobId) {
        let SelectedJobArray = data.SelectedJobId.split(",");

        if (SelectedJobArray.length > 0) {
          AIResponseResult.then(async (responseResults) => {
            const promises = SelectedJobArray.map(async (jobId, i) => {
              const [jobExists] = await conn.query(
                "SELECT COUNT(*) AS count FROM jobfeed WHERE id = ?",
                [jobId]
              );

              if (jobExists[0].count > 0) {
                const candidateInterviewId = uuidv4();
                const { analysis, rating, matching } = responseResults[i];

                await conn.query(
                  `
                  INSERT INTO CandidateInterview (id, CandidateId, SelectedJobId, CandidateReview, Rating, Matching)
                  VALUES (?, ?, ?, ?, ?, ?)
                  `,
                  [
                    candidateInterviewId,
                    candidateId,
                    jobId,
                    analysis,
                    rating,
                    matching,
                  ]
                );
              } else {
                return failureResponse(res, 403, "Invalid Job Id");
              }
            });

            await Promise.all(promises);
          });
        }
      }

      // Insert skills into the CandidateSkill table
      if (data.Skill) {
        let skillArray = [];

        data.Skill.split(",").forEach((element) => {
          skillArray.push(parseInt(element));
        });
        if (skillArray.length > 0) {
          const userSkills = skillArray.map((skillId) => [
            candidateId,
            skillId,
          ]);
          await conn.query(
            `INSERT INTO CandidateSkill (CandidateId, SkillId) VALUES ?`,
            [userSkills]
          );
        }
      }

      // Insert Experince in user experince table
      if (data.Experience) {
        let experienceData = JSON.parse(data.Experience);
        if (experienceData.length > 0) {
          const userExperiences = experienceData
            .map((experience) => {
              if (experience.JobTitle && experience.Organisation) {
                const experienceId = uuidv4();
                return {
                  id: experienceId,
                  CandidateId: candidateId,
                  JobTitle: experience.JobTitle,
                  Organisation: experience.Organisation,
                  StartDate: experience.StartDate,
                  EndDate: experience.EndDate,
                  // YearOfExperience:
                  //   new Date(experience.EndDate).getFullYear() -
                  //   new Date(experience.StartDate).getFullYear(),
                };
              }
            })
            .filter((experience) => experience !== undefined);

          const values = userExperiences.map((experience) =>
            Object.values(experience)
          );

          await conn.query(
            `INSERT INTO CandidateExperience (id, CandidateId, JobTitle, Organisation, StartDate, EndDate)
           VALUES ?`,
            [values]
          );
        }
      }
      // Insert Education in user education table
      if (data.Education) {
        let educationData = JSON.parse(data.Education);
        const userEducations = educationData.map((education) => {
          if (education.InstituteName && education.Course) {
            const educationId = uuidv4();

            return {
              id: educationId,
              CandidateId: candidateId,
              InstituteName: education.InstituteName,
              Course: education.Course,
              StartYear: education.StartYear,
              EndYear: education.EndYear,
              Marks: education.Marks,
            };
          }
        });

        const values = userEducations.map((education) =>
          Object.values(education)
        );

        await conn.query(
          `INSERT INTO CandidateEducation (id, CandidateId, InstituteName,Course, StartYear, EndYear, Marks)
           VALUES ?`,
          [values]
        );
      }
      const notificationId = uuidv4();
      // Emit the event to all connected clients
      io.emit("clientAdded", {
        Message: `${data.FirstName} ${data.LastName} is added as a candidate`,
      });

      await notification.create({
        id: notificationId,
        OrganisationId: OrganisationId,
        UserId: createdBy,
        Message: `${data.FirstName} ${data.LastName} is added as a candidate`,
        Status: "clientAdded",
      });
      return successResponse(res, "Candidate created successfully", data);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async updateCandidate(req, res) {
    try {
      let pdfText;
      const data = req.body;
      const candidateId = req.params.id;
      const OrganisationName = req.OrganisationName;
      const conn = await connPromise;
      const createdBy = req.userId;
      const OrganisationId = req.OrganisationId;

      const [checkCandidate] = await conn.query(
        `SELECT * FROM Candidates WHERE isDeleted <> 1 AND id = ?`,
        [candidateId]
      );

      if (checkCandidate.length === 0) {
        return failureResponse(res, 404, "Candidate not found");
      }

      // Check if the Gender ID is valid
      if (data.GenderId) {
        const [gender] = await conn.query("SELECT * FROM Gender WHERE id = ?", [
          data.GenderId,
        ]);
        if (gender.length === 0) {
          return failureResponse(res, 400, "Invalid Gender ID");
        }
      }

      // Check if the job IDs are valid
      let jobs = data.SelectedJobId.split(",");
      const jobNames = [];

      if (jobs?.length > 0) {
        for (const jobId of jobs) {
          const [jobTitleResult] = await conn.query(
            "SELECT Title FROM JobFeed WHERE id = ?",
            [jobId]
          );

          if (jobTitleResult.length > 0) {
            jobNames.push(jobTitleResult[0].Title);
          }
        }
      } else {
        return failureResponse(res, 400, "Job feed is required");
      }

      if (jobNames.length === 0) {
        return failureResponse(res, 400, "Enter valid Job feeds");
      }

      const filePath = path.join(__dirname, "../Files", OrganisationName);

      const fileExists = fs.existsSync(filePath);
      if (!fileExists) {
        try {
          fs.mkdirSync(filePath);
        } catch (err) {}
      } else {
      }

      if (req.files) {
        const resumePath = filePath + `\\${checkCandidate[0].Resume}`;
        if (
          !req?.files["ResumeDoc"] &&
          (!data.Resume || data.Resume === "") &&
          checkCandidate[0].Resume
        ) {
          if (fs.existsSync(resumePath)) {
            fs.unlinkSync(resumePath, (error) => {});
          }
        } else if (req?.files["ResumeDoc"]) {
          data.Resume =
            req.files && req?.files["ResumeDoc"]
              ? req?.files["ResumeDoc"][0]?.filename
              : null;
          if (checkCandidate[0].Resume) {
            if (fs.existsSync(resumePath)) {
              fs.unlinkSync(resumePath, (error) => {});
            }
          }
        }

        if (
          !req?.files["ProfilePhotoDoc"] &&
          (!data.ProfilePhoto || data.ProfilePhoto === "") &&
          checkCandidate[0].ProfilePhoto
        ) {
          if (fs.existsSync(resumePath)) {
            fs.unlinkSync(resumePath, (error) => {});
          }
        } else if (req?.files["ProfilePhotoDoc"]) {
          data.ProfilePhoto =
            req.files && req?.files["ProfilePhotoDoc"]
              ? req?.files["ProfilePhotoDoc"][0]?.filename
              : null;
          if (checkCandidate[0].ProfilePhoto) {
            if (fs.existsSync(resumePath)) {
              fs.unlinkSync(resumePath, (error) => {});
            }
          }
        }
      }

      if (req.files && req.files["ResumeDoc"] && req.files["ResumeDoc"][0]) {
        const documentName = req.files["ResumeDoc"][0].filename;
        const resumePath = path.join(
          __dirname,
          "../Files",
          OrganisationName,
          documentName
        );
        pdfText = await pdfService.pdfToText(resumePath);
      } else {
        const resumeName = checkCandidate[0].Resume;
        const resumePath = path.join(
          __dirname,
          "../Files",
          OrganisationName,
          resumeName
        );
        pdfText = await pdfService.pdfToText(resumePath);
      }
      const AIResponseResult = CandidateService.analyzeCandidate(
        data,
        jobNames,
        pdfText,
        createdBy,
        candidateId
      );

      if (data.SelectedJobId) {
        // Split the input into an array of selected job IDs
        const SelectedJobArray = data.SelectedJobId.split(",");

        // Fetch the existing selected job IDs for the candidate
        const [existingSelectedJobs] = await conn.query(
          "SELECT SelectedJobId FROM CandidateInterview WHERE CandidateId = ?",
          [candidateId]
        );

        const existingJobIds = existingSelectedJobs.map(
          (job) => job.SelectedJobId
        );

        // Compare the existing and new job IDs to determine added and canceled jobs
        const addedJobs = SelectedJobArray.filter(
          (jobId) => !existingJobIds.includes(jobId)
        );
        const canceledJobs = existingJobIds.filter(
          (jobId) => !SelectedJobArray.includes(jobId)
        );

        // Handle added jobs
        const promises = [];

        for (let jobId of addedJobs) {
          const [jobExists] = await conn.query(
            "SELECT COUNT(*) AS count FROM jobfeed WHERE id = ?",
            [jobId]
          );

          if (jobExists[0].count > 0) {
            const candidateInterviewId = uuidv4();
            promises.push(
              conn.query(
                `
                INSERT INTO CandidateInterview (id, CandidateId, SelectedJobId)
                VALUES (?, ?, ?)
              `,
                [candidateInterviewId, candidateId, jobId]
              )
            );

            // Do not wait for OpenAI response here
            AIResponseResult.then((responseResults) => {
              const { analysis, rating, matching } =
                responseResults[SelectedJobArray.indexOf(jobId)];

              // Update the record with OpenAI response (in the background)
              conn.query(
                `
                UPDATE CandidateInterview
                SET CandidateReview = ?, Rating = ?, Matching = ?
                WHERE id = ?
              `,
                [analysis, rating, matching, candidateInterviewId]
              );
            });
          } else {
            return failureResponse(res, 403, "Invalid Job Id");
          }
        }

        // Handle canceled jobs
        for (let jobId of canceledJobs) {
          // Delete the interview details for the canceled job
          promises.push(
            conn.query(
              "DELETE FROM CandidateInterview WHERE CandidateId = ? AND SelectedJobId = ?",
              [candidateId, jobId]
            )
          );
        }

        await Promise.all(promises);
      }

      if (data.Skill) {
        const skillIds = data.Skill.split(",").map((skillId) =>
          parseInt(skillId.trim())
        );

        // Delete existing user skills
        await conn.query("DELETE FROM CandidateSkill WHERE CandidateId = ?", [
          candidateId,
        ]);

        // Insert updated user skills
        if (skillIds.length > 0) {
          const userSkills = skillIds.map((skillId) => [candidateId, skillId]);
          await conn.query(
            "INSERT INTO CandidateSkill (CandidateId, SkillId) VALUES ?",
            [userSkills]
          );
        }
      }

      if (data.Experience) {
        let experienceData = JSON.parse(data.Experience);
        if (experienceData.length > 0) {
          const userExperiences = experienceData.map((experience) => {
            if (experience.JobTitle && experience.Organisation) {
              const experienceId = uuidv4();
              return {
                id: experienceId,
                CandidateId: candidateId,
                JobTitle: experience.JobTitle,
                Organisation: experience.Organisation,
                StartDate: experience.StartDate,
                EndDate: experience.EndDate,
              };
            }
          });

          const values = userExperiences.map((experience) =>
            Object.values(experience)
          );

          // Delete existing user experience
          await conn.query(
            "DELETE FROM CandidateExperience WHERE CandidateId = ?",
            [candidateId]
          );

          // Insert updated user experience
          await conn.query(
            `INSERT INTO CandidateExperience (id, CandidateId, JobTitle, Organisation, StartDate, EndDate)
         VALUES ?`,
            [values]
          );
        }
      }

      if (data.Education) {
        let educationData = JSON.parse(data.Education);
        const userEducations = educationData.map((education) => {
          if (education.InstituteName && education.Course) {
            const educationId = uuidv4();

            return {
              id: educationId,
              CandidateId: candidateId,
              InstituteName: education.InstituteName,
              Course: education.Course,
              StartYear: education.StartYear,
              EndYear: education.EndYear,
              Marks: education.Marks,
            };
          }
        });

        const values = userEducations.map((education) =>
          Object.values(education)
        );

        // Delete existing user education
        await conn.query(
          "DELETE FROM CandidateEducation WHERE CandidateId = ?",
          [candidateId]
        );

        // Insert updated user education
        await conn.query(
          `INSERT INTO CandidateEducation (id, CandidateId, InstituteName,Course, StartYear, EndYear, Marks)
           VALUES ?`,
          [values]
        );
      }

      // Prepare the fields and values for the UPDATE query
      const updateFields = { ...data };
      //delete the skill,experince and education fields from data of candidate table
      delete updateFields.SelectedJobId;
      delete updateFields.DepartmentId;
      delete updateFields.Skill;
      delete updateFields.Experience;
      delete updateFields.Education;
      delete updateFields.StartDate;
      delete updateFields.EndDate;
      delete updateFields.ProfilePhotoDoc;
      delete updateFields.ResumeDoc;

      // Check if there are no fields to update
      if (Object.keys(updateFields).length === 0) {
        return failureResponse(res, 400, "No fields to update");
      }

      const [result] = await conn.query(
        `UPDATE Candidates SET ? WHERE id = ?`,
        [updateFields, candidateId]
      );

      const notificationId = uuidv4();
      io.emit("clientUpdate", {
        Message: `candidate ${
          checkCandidate[0].FirstName + " " + checkCandidate[0].LastName
        } is update by ${createdBy}`,
        Status: "clientUpdate"
      });

      await notification.create({
        id: notificationId,
        OrganisationId: OrganisationId,
        UserId: createdBy,
        Message: `candidate ${
          checkCandidate[0].FirstName + " " + checkCandidate[0].LastName
        } is update by ${createdBy}`,
        Status: "clientUpdate",
      });

      return successResponse(res, "updated successfully", result);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async getAllCandidates(req, res) {
    try {
      const conn = await connPromise;

      // Pagination
      const page = parseInt(req.query.page) || 1; // Set default value to 1 if page is not provided or is NaN
      const limit = parseInt(req.query.limit) || 12;
      const { jobId } = req.query;
      const startIndex = (page - 1) * limit;
      const endIndex = page * limit;

      const { status } = req.query;

      // Sorting
      const sortBy = req.query.sortBy || "createdAt";
      const sortOrder = req.query.sortOrder || "asc";
      const order = sortOrder === "desc" ? "DESC" : "ASC";

      // Searching
      const search = req.query.search || "";
      const currentStateFilter =
        req.query.CurrentState === "undefined" ? "" : req.query.CurrentState;
      const currentCityFilter =
        req.query.CurrentCity === "undefined" ? "" : req.query.CurrentCity;
      const genderIdFilter =
        req.query.GenderId === "undefined" ? "" : req.query.GenderId;
      const expectedCtcFilter =
        req.query.ExpectedCtc === "undefined" ? "" : req.query.ExpectedCtc;
      const jobIdFilter =
        req.query.JobId === "undefined" ? "" : req.query.JobId;

      let query;
      let params;
      let countQuery;

      if (status == "Approve") {
        query = `SELECT * FROM candidateinterview ci
        JOIN candidates c
        ON ci.CandidateId = c.id
        WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
        AND ci.SelectedJobId = ? AND ci.InterviewStatus = 'Approve' AND c.isDeleted <> 1
        ORDER BY ci.${sortBy} ${order}
        LIMIT ?, ?`;
        // Get total number of Approved candidates
        countQuery = `SELECT COUNT(*) as total
        FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
        AND ci.SelectedJobId = ? AND ci.InterviewStatus = 'Approve' AND c.isDeleted <> 1`;

        params = [
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          jobId,
          startIndex,
          limit,
        ];
      } else if (status == "Reject") {
        query = `SELECT * FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
        AND ci.SelectedJobId = ? AND ci.InterviewStatus = 'Reject' AND c.isDeleted <> 1
        ORDER BY ci.${sortBy} ${order}
        LIMIT ?, ?`;

        // Get total number of Reject candidates
        countQuery = `SELECT COUNT(*) as total
        FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
        AND ci.SelectedJobId = ? AND ci.InterviewStatus = 'Reject' AND c.isDeleted <> 1`;

        params = [
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          jobId,
          startIndex,
          limit,
        ];
      } else if (status == "waiting") {
        query = `SELECT * FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
        AND ci.SelectedJobId = ? AND ci.InterviewStatus = 'waiting' AND c.isDeleted <> 1
        ORDER BY ci.${sortBy} ${order}
        LIMIT ?, ?`;

        // Get total number of waiting candidates
        countQuery = `SELECT COUNT(*) as total
        FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
        AND ci.SelectedJobId = ? AND ci.InterviewStatus = 'waiting' AND c.isDeleted <> 1`;

        params = [
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          jobId,
          startIndex,
          limit,
        ];
      } else if (status == "scheduled") {
        query = `SELECT * FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
        AND ci.SelectedJobId = ? AND ci.InterviewStatus = 'scheduled' AND c.isDeleted <> 1
        ORDER BY ci.${sortBy} ${order}
        LIMIT ?, ?`;

        // Get total number of scheduled candidates
        countQuery = `SELECT COUNT(*) as total
        FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
        AND ci.SelectedJobId = ? AND ci.InterviewStatus = 'scheduled' AND c.isDeleted <> 1`;

        params = [
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          jobId,
          startIndex,
          limit,
        ];
      }

      //when the filters are selected
      else if (
        (req.query.CurrentState && req.query.CurrentState !== "undefined") ||
        (req.query.CurrentCity && req.query.CurrentCity !== "undefined") ||
        (req.query.GenderId && req.query.GenderId !== "undefined") ||
        (req.query.ExpectedCtc && req.query.ExpectedCtc !== "undefined") ||
        (req.query.JobId && req.query.JobId !== "undefined")
      ) {
        // Start with a base query
        query = `SELECT * FROM Candidates c WHERE c.isDeleted <> 1`;
        countQuery = `SELECT COUNT(*) as total FROM Candidates c WHERE c.isDeleted <> 1`;

        // Initialize an array to store filter conditions
        const filterConditions = [];
        const filterParams = [];

        // Add filter conditions for each filter if provided
        if (req.query.CurrentState) {
          filterConditions.push("c.CurrentState LIKE ?");
          filterParams.push(`%${currentStateFilter}%`);
        }

        if (req.query.CurrentCity) {
          filterConditions.push("c.CurrentCity LIKE ?");
          filterParams.push(`%${currentCityFilter}%`);
        }

        if (req.query.GenderId) {
          filterConditions.push("c.GenderId LIKE ?");
          filterParams.push(`%${genderIdFilter}%`);
        }

        if (req.query.ExpectedCtc) {
          filterConditions.push("c.ExpectedCtc LIKE ?");
          filterParams.push(`%${expectedCtcFilter}%`);
        }

        if (filterConditions.length > 0) {
          query += ` AND (${filterConditions.join(" AND ")})`;
          countQuery += ` AND (${filterConditions.join(" AND ")})`;
        }

        if (req.query.JobId) {
          if (filterConditions.length > 0) {
            query = `SELECT c.* FROM Candidates c
          LEFT JOIN candidateinterview as ci ON c.id = ci.CandidateId
          LEFT JOIN jobfeed as jf ON jf.id = ci.SelectedJobId
          WHERE c.isDeleted <> 1 AND ${filterConditions.join(
            " AND "
          )} AND jf.id = ?
          `;

            countQuery = `SELECT COUNT(c.id) as total FROM Candidates c
          LEFT JOIN candidateinterview as ci ON c.id = ci.CandidateId
          LEFT JOIN jobfeed as jf ON jf.id = ci.SelectedJobId
          WHERE c.isDeleted <> 1 AND ${filterConditions.join(
            " AND "
          )} AND jf.id = ?`;
          } else {
            query = `SELECT c.* FROM Candidates c
          LEFT JOIN candidateinterview as ci ON c.id = ci.CandidateId
          LEFT JOIN jobfeed as jf ON jf.id = ci.SelectedJobId
          WHERE c.isDeleted <> 1 AND jf.id = ?
          `;

            countQuery = `SELECT COUNT(c.id) as total FROM Candidates c
          LEFT JOIN candidateinterview as ci ON c.id = ci.CandidateId
          LEFT JOIN jobfeed as jf ON jf.id = ci.SelectedJobId
          WHERE c.isDeleted <> 1 AND jf.id = ?`;
          }
          filterParams.push(jobIdFilter);
        }

        // Add sorting and pagination to the query
        query += ` ORDER BY ${sortBy} ${order} LIMIT ?, ?`;
        // Set the parameters for the query
        params = [...filterParams, startIndex, limit];
      }

      // when start the page and get all candidates without filters
      else {
        query = `SELECT * FROM Candidates
        WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
        AND isDeleted <> 1
        ORDER BY ${sortBy} ${order}
        LIMIT ?, ?`;

        countQuery = `
      SELECT COUNT(*) as total FROM Candidates
      WHERE (Email LIKE ? OR FirstName LIKE ? OR LastName LIKE ? OR CurrentCompany LIKE ? OR PhoneNumber LIKE ?)
      AND isDeleted <> 1
    `;

        params = [
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          `%${search}%`,
          startIndex,
          limit,
        ];
      }

      const [result] = await conn.query(query, params);
      const [count] = await conn.query(countQuery, params);

      // Fetch experiences for each candidate
      const experienceIds = result.map((candidate) => candidate.id);
      let experiences = [];
      if (experienceIds.length > 0) {
        const experienceQuery = `SELECT * FROM CandidateExperience WHERE CandidateId IN (?)`;
        [experiences] = await conn.query(experienceQuery, [experienceIds]);
      }
      // Fetch education for each candidate
      const educationIds = result.map((candidate) => candidate.id);
      let education = [];
      if (educationIds.length > 0) {
        const educationQuery = `SELECT * FROM CandidateEducation WHERE CandidateId IN (?)`;
        [education] = await conn.query(educationQuery, [educationIds]);
      }

      const [skillquery2] = await conn.query(
        `select cs.* , s.Skill as skill from CandidateSkill as cs
      left join skills  as s
       on s.id=cs.SkillId`
      );

      // Create response object
      const response = {
        data: result.map((candidate) => {
          const candidateExperiences = experiences.filter(
            (experience) => experience.CandidateId === candidate.id
          );
          const candidateEducations = education.filter(
            (education) => education.CandidateId === candidate.id
          );
          const candidateSkills = skillquery2.filter(
            (skill) => skill.CandidateId === candidate.id
          );
          return {
            ...candidate,
            experiences:
              candidateExperiences.length > 0 ? candidateExperiences : [],
            education:
              candidateEducations.length > 0 ? candidateEducations : [],
            skill: candidateSkills,
          };
        }),
        total: count[0].total,
        currentPage: page,
        totalPages: Math.ceil(count[0].total / limit),
      };

      return successResponse(res, "Retrieved successfully", response);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async getAllRegisteredCandidates(req, res) {
    try {
      const { city, state, expectedCtc, currentCtc } = req.query;
      const conn = await connPromise;

      let query = `
            SELECT * FROM hms.Candidates
            WHERE`;

      const queryParams = []; // Array to hold query parameters
      let conditions = []; // Array to hold conditions

      // Check if city is provided
      if (city) {
        conditions.push("CurrentCity = ?");
        queryParams.push(city);
      }

      // Check if state is provided
      if (state) {
        conditions.push("CurrentState = ?");
        queryParams.push(state);
      }

      // Check if expectedCtc is provided
      if (expectedCtc) {
        conditions.push("ExpectedCtc = ?");
        queryParams.push(expectedCtc);
      }
      if (currentCtc) {
        conditions.push("CurrentCtc = ?");
        queryParams.push(currentCtc);
      }

      // Join conditions with 'AND'
      query += ` ${conditions.join(" AND ")}`;

      // Execute the query with parameters
      const [candidates, _] = await conn.query(query, queryParams);

      // Get the total count of filtered candidates
      const totalCount = candidates.length;

      return successResponse(res, "Candidates retrieved successfully", {
        totalCount,
        candidates,
      });
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async getCandidateById(req, res) {
    try {
      const candidateId = req.params.id;
      const conn = await connPromise;

      const [result] = await conn.query(
        `SELECT * FROM Candidates WHERE id IN (?) AND isDeleted <> 1`,
        [candidateId]
      );

      if (result.length === 0) {
        return failureResponse(res, 404, "Candidate Not found");
      }

      //fetch Skills from candidateskill
      const [skillsSelected] = await conn.query(
        `
        SELECT s.*
         FROM CandidateSkill AS cs
         LEFT JOIN skills as s on cs.SkillId = s.id
         WHERE cs.CandidateId = ?
        `,
        [candidateId]
      );

      // Fetch Experience from candidateexperience
      const [experienceSelected] = await conn.query(
        `
      SELECT ce.*, c.id AS CandidateId, c.FirstName, c.LastName
      FROM CandidateExperience AS ce
      LEFT JOIN Candidates AS c ON ce.CandidateId = c.id
      WHERE ce.CandidateId = ?
      `,
        [candidateId]
      );
      // Fetch Experience from candidateexperience
      const [educationSelected] = await conn.query(
        `
      SELECT ced.*, c.id AS CandidateId, c.FirstName, c.LastName
      FROM CandidateEducation AS ced
      LEFT JOIN Candidates AS c ON ced.CandidateId = c.id
      WHERE ced.CandidateId = ?
      `,
        [candidateId]
      );

      // Fetch candidate interview details
      const [candidateInterview] = await conn.query(
        `
      SELECT ci.*,jf.Title
      FROM candidateinterview AS ci
      JOIN Candidates AS c ON ci.CandidateId = c.id
      JOIN jobfeed AS jf ON jf.id = ci.SelectedJobId
      WHERE ci.CandidateId = ?
      `,
        [candidateId]
      );

      // Fetch candidate department Jobs details
      const [candidateDepartmentJobs] = await conn.query(
        `SELECT d.id AS DepartmentId, GROUP_CONCAT(DISTINCT jf.id SEPARATOR ', ') AS JobFeedIds
        FROM candidates AS c
        JOIN candidateinterview AS ci ON c.id = ci.CandidateId
        JOIN jobfeed AS jf ON jf.id = ci.SelectedJobId
        JOIN department AS d ON jf.Department = d.id
        WHERE c.id = ? AND d.isDeleted <> 1 AND jf.isDeleted <> 1
        GROUP BY DepartmentId;
      `,
        [candidateId]
      );

      const jobsByDepartments = [];

      candidateDepartmentJobs.forEach((x) => {
        const a = x.JobFeedIds.split(", ");
        jobsByDepartments.push({ DepartmentId: x.DepartmentId, JobFeedIds: a });
      });

      const response = {
        success: true,
        data: result.map((user) => {
          return {
            ...user,
            skills: skillsSelected,
            experience: experienceSelected,
            education: educationSelected,
            candidateInterviewDetails: candidateInterview,
            candidateDepartmentJobsDetails: jobsByDepartments,
          };
        }),
      };

      return successResponse(res, "Candidate found successfully", response);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async deleteCandidate(req, res) {
    try {
      const id = req.params.id;
      const conn = await connPromise;
      const createdBy = req.userId;
      const [user] = await conn.query(
        "SELECT * FROM candidates WHERE isDeleted <> 1 AND id = ?",
        [id]
      );
      if (user.length === 0) {
        return failureResponse(res, 404, "candidate not found");
      }
      const [deletedCandidate] = await conn.query(
        "UPDATE candidates SET isDeleted=1 WHERE id = ?",
        [id]
      );

      io.emit("clientDelete", {
        message: `candidate ${
          user[0].FirstName + " " + user[0].LastName
        } is deleted by ${createdBy}`,
        // Include the list of all deleted candidates
      });
      return successResponse(
        res,
        "Candidate deleted successfully",
        deletedCandidate
      );
    } catch (err) {
      return failureResponse(res, 400, err.message);
    }
  }

  static async getDocument(req, res) {
    try {
      const documentName = req.body.documentName;
      const OrganisationName = req.OrganisationName;
      const filePath = path.join(
        __dirname,
        "../Files",
        OrganisationName,
        documentName
      );

      const mimeType = mime.lookup(filePath.split("(#")[0]);

      await res.set("Content-Type", mimeType);
      await res.set(
        "Content-Disposition",
        `attachment; filename="${documentName.split("(#")[0]}"`
      );

      const fileExists = fs.existsSync(filePath);
      if (!fileExists) {
        return failureResponse(res, 404, "File not found");
      }

      const fileStream = fs.createReadStream(filePath);
      await fileStream.pipe(res);
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }

  static async getJobFeedsOfDepartment(req, res) {
    try {
      const id = req.params.id;
      const conn = await connPromise;
      const [departmentRows] = await conn.query(
        `SELECT * FROM Department WHERE id = ? AND isDeleted <> 1`,
        id
      );
      if (departmentRows.length === 0) {
        return failureResponse(res, 404, "Department does not exist");
      }

      const [departmentJobs] = await conn.query(
        `SELECT jf.id,jf.Title FROM JobFeed AS jf 
        LEFT JOIN Department AS d ON d.id = jf.Department 
        WHERE d.id = ? AND jf.isDeleted <> 1`,
        [id]
      );

      return successResponse(
        res,
        "jobs fethed of this department",
        departmentJobs
      );
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }
  static async getAllJobsOfCandidate(req, res) {
    try {
      const id = req.params.id;
      const conn = await connPromise;
      const [candidateRows] = await conn.query(
        `SELECT * FROM Candidates WHERE id = ? AND isDeleted <> 1`,
        id
      );
      if (candidateRows.length === 0) {
        return failureResponse(res, 404, "Candidate does not exist");
      }

      const [candidateJobs] = await conn.query(
        `select c.id as candidateId,jf.id as jobId, jf.Title as jobTitle from candidates as c
        join candidateinterview as ci on c.id = ci.CandidateId
        join jobfeed as jf on jf.id = ci.SelectedJobId
        where c.id = ? AND jf.isDeleted <> 1`,
        [id]
      );

      return successResponse(
        res,
        "All jobs fetched for this candidate",
        candidateJobs
      );
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }

  static async getAllInformationOfCandidates(req, res) {
    try {
      const conn = await connPromise;
      const [result] = await conn.query(
        `select CurrentState,CurrentCity,ExpectedCtc from candidates where isDeleted <> 1`
      );
      return successResponse(res, "Information fetched successfully", result);
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }

  static async candidateBulkUpload(req, res) {
    try {
      const documentName = req.file.filename;
      const OrganisationName = req.OrganisationName;
      const csvFilePath = path.join(
        __dirname,
        "../Files",
        OrganisationName,
        documentName
      );
      csvToDb(csvFilePath);
      res.json({
        msg: "File successfully inserted!",
        file: req.file,
      });
      // return successResponse(res, "Information fetched successfully", result);
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }
}
async function insertCandidateData(data) {
  const columns = Object.keys(data).join(", ");
  const placeholders = Object.values(data)
    .map(() => "?")
    .join(", ");

  const query = `INSERT INTO Candidates (${columns}) VALUES (${placeholders})`;

  const values = Object.values(data);
  const conn = await connPromise;
  await conn.query(query, values);
}

async function csvToDb(csvUrl) {
  try {
    const stream = fs.createReadStream(csvUrl);
    const collectionCsv = [];

    const csvFileStream = csv.parse().on("data", function (data) {
      const [
        FirstName,
        LastName,
        Email,
        PhoneNumber,
        GenderId,
        WorkStatus,
        CurrentState,
        CurrentCity,
        CurrentCompany,
        CurrentCtc,
        ExpectedCtc,
        Resume,
        ProfilePhoto,
        createdBy,
      ] = data;

      if (FirstName && LastName && Email) {
        const candidateData = {
          id: uuidv4(),
          FirstName,
          LastName,
          Email,
          PhoneNumber,
          GenderId,
          WorkStatus,
          CurrentState,
          CurrentCity,
          CurrentCompany,
          CurrentCtc,
          ExpectedCtc,
          Resume,
          ProfilePhoto,
          createdBy,
        };

        collectionCsv.push(candidateData);
      }
    });

    await new Promise((resolve, reject) => {
      csvFileStream
        .on("end", function () {
          resolve();
        })
        .on("error", function (error) {
          reject(error);
        });

      stream.pipe(csvFileStream);
    });

    for (const candidateData of collectionCsv) {
      await insertCandidateData(candidateData);
    }

    fs.unlinkSync(csvUrl);
  } catch (error) {
    console.error(error);
  }
}

module.exports = CandidateService;
