const { conn, query, connPromise } = require("../config/connection");
const { Organisation } = require("../models/organisation");
const bcrypt = require("bcrypt");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const { v4: uuidv4 } = require("uuid");
const dotenv = require("dotenv");
dotenv.config({ path: "../.env" });
const id = uuidv4();
const fs = require("fs");
const path = require("path");
const { roleInsertQueries } = require("../utils/role");
const { permissionInsertQueries } = require("../utils/permission");
const jwt = require("jsonwebtoken");
const util = require("util");
const { subscription } = require("../models/subscription");
const execPromise = util.promisify(require("child_process").exec);

function getDatabaseName(orgName) {
  return `HMS_${orgName.toLowerCase().replace(/\s+/g, "_")}`;
}
class OrganisationService {
  static async createOrganisation(req, res) {
    try {
      const data = req.body;
      const hashPassword = await bcrypt.hash(data.Password, 10);
      data.Password = hashPassword;

      // Check if all required fields are present
      if (
        !data.Name ||
        !data.Type ||
        !data.OwnerFirstName ||
        !data.OwnerLastName ||
        !data.Email ||
        !data.Password ||
        !data.Address ||
        !data.Pin ||
        !data.City ||
        !data.State ||
        !data.Country
      ) {
        return failureResponse(res, 400, "All required fields must be present");
      }

      // Check if database already exists
      const dbName = getDatabaseName(data.Name);
      const result = await query(
        `SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '${dbName}'`
      );
      if (result.length > 0) {
        return failureResponse(res, 403, "Organisation already exists");
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.Email)) {
        return failureResponse(res, 403, "Email is invalid");
      }

      const emailExists = await Organisation.findOne({
        where: { Email: data.Email },
      });
      if (emailExists) {
        return failureResponse(res, 403, "Email already exists");
      }
      const websiteExists = await Organisation.findOne({
        where: { Website: data.Website },
      });
      if (websiteExists) {
        return failureResponse(res, 400, "website already exists");
      }

      const newOrg = await Organisation.create({
        ...data,
        ConnectionString: `mysql://root:root@localhost/${dbName}`,
      });
      const expiryDate = new Date(
        new Date().setDate(new Date().getDate() + 14)
      );
      const newSubscription = await subscription.create({
        id: uuidv4(),
        organisationId: newOrg.Id,
        SubscriptionPackage: "trail",
        SubscriptionPurchaseDate: new Date(),
        SubscriptionExpiryDate: expiryDate,
      });

      // Create a new database for the organization
      const conn = await connPromise;
      await conn.connect();
      await conn.query(`CREATE DATABASE ${dbName};USE ${dbName}`);
      // save created db name to dotenv file
      process.env.DB_NAMES = dbName;
      const envPath = path.join(__dirname, "../.env");
      const envData = dotenv.parse(fs.readFileSync(envPath));
      // Append the new dbName value to the existing DB_NAMES value (if it doesn't already exist)
      const dbNames = envData.DB_NAMES ? envData.DB_NAMES.split(",") : [];
      if (!dbNames.includes(dbName)) {
        dbNames.push(dbName);
      }
      envData.DB_NAMES = dbNames.join(",");
      const envContent = Object.keys(envData)
        .map((key) => `${key}=${envData[key]}`)
        .join("\n");
      fs.writeFileSync(envPath, envContent);

      // await migrationUp(sequelizeDynamic.getQueryInterface(), Sequelize);
      await execPromise(
        `npx sequelize-cli db:migrate --url mysql://${process.env.DB_USER}:${process.env.DB_PASSWORD}@${process.env.DB_HOST}/${dbName}`
      );

      await execPromise(
        `npx sequelize-cli db:seed:all --url mysql://${process.env.DB_USER}:${process.env.DB_PASSWORD}@${process.env.DB_HOST}/${dbName}`
      );

      await conn.query(
        `INSERT INTO subscriptions (id,organisationId,SubscriptionPackage,SubscriptionPurchaseDate,SubscriptionExpiryDate) 
        VALUES(?,?,?,?,?)`,
        [uuidv4(), newOrg.Id, "trail", new Date(), expiryDate]
      );

      await conn.query(`INSERT INTO Role (id, Name)
            VALUES ${roleInsertQueries
              .map((query) => `('${query[0]}', '${query[1]}')`)
              .join(", ")};
            INSERT INTO Permission (id, Name)
            VALUES ${permissionInsertQueries
              .map((query) => `('${query[0]}', '${query[1]}')`)
              .join(", ")};`);
      // Loop through roleInsertQueries
      for (const role of roleInsertQueries) {
        const roleId = role[0];
        const roleName = role[1];

        // If the role is MasterAdmin, assign only the MasterAdmin permission
        if (roleName === "MasterAdmin") {
          const masterAdminPermission = permissionInsertQueries.find(
            (permission) => permission[1] === "MasterAdmin"
          );

          if (masterAdminPermission) {
            await conn.query(
              `INSERT INTO Users (id , FirstName , LastName , Email, Password , RoleId ) VALUES (? , ? , ? ,?, ?, ?)`,
              [
                id,
                data.OwnerFirstName,
                data.OwnerLastName,
                data.Email,
                (data.Password = hashPassword),
                roleId,
              ]
            );

            for (const permission of permissionInsertQueries) {
              const permissionId = permission[0];
              await conn.query(
                `
                  INSERT INTO rolepermission (RoleId, PermissionId)
                  VALUES (?, ?)
                  `,
                [roleId, permissionId]
              );
            }
          }
        } else {
          // If the role is not MasterAdmin, assign all other permissions
          for (const permission of permissionInsertQueries) {
            if (permission[1] !== "MasterAdmin") {
              const permissionId = permission[0];
              await conn.query(
                `
                INSERT INTO rolepermission (RoleId, PermissionId)
                VALUES (?, ?)
                `,
                [roleId, permissionId]
              );
            }
          }
        }
      }

      return successResponse(res, "Registered", newOrg);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async loginUser(req, res) {
    try {
      const { Email, Password, OrganisationName } = req.body;
      if (!Email || !Password) {
        return failureResponse(res, 403, "Please enter credentials");
      }
      const databaseNames = "HMS_" + OrganisationName.replace(/\s/g, "_");
      const conn = await connPromise;
      await conn.query(`use ${databaseNames}`);

      const [user] = await conn.query("SELECT * FROM users WHERE email = ?", [
        Email,
      ]);

      const [fetchOrganisationId] = await conn.query(
        `SELECT id FROM hms.organisations WHERE Name = ?`,
        [OrganisationName]
      );

      if (user.length === 0) {
        return failureResponse(res, 403, "Invalid email or password");
      }

      const checkPassword = await bcrypt.compare(Password, user[0].Password);

      if (!checkPassword) {
        return failureResponse(res, 403, "Invalid email or password");
      }

      const [roleAndPermissionAssigned] = await conn.query(
        `
      SELECT r.Name AS RoleName , p.Name as permissionName
      FROM users as u
      JOIN role AS r
      on u.roleId = r.id
      JOIN
        rolepermission AS rp 
      ON
        r.id = rp.RoleId
      JOIN
        permission AS p
      ON
        rp.PermissionId = p.id
      WHERE
        u.id = ?
      `,
        [user[0].id]
      );
      const payload = {
        userId: user[0].id,
        Email: user[0].Email,
        dbName: databaseNames,
        OrganisationName: OrganisationName,
        OrganisationId: fetchOrganisationId[0].id,
        adminName: user[0].FirstName + " " + user[0].LastName,
        permissions: roleAndPermissionAssigned,
      };
      const secret = process.env.JWT_SECRET;
      const expiresIn = process.env.JWT_EXPIRY;

      const token = jwt.sign(payload, secret, { expiresIn });

      const options = {
        expiresIn: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        httpOnly: true,
      };

      return successResponse(res, "Logged In successfully", token);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async getPermissionsByUserId(req, res) {
    try {
      const userId = req.params.id;
      const conn = await connPromise;
      const [checkUserExist] = await conn.query(
        `SELECT * FROM Users WHERE id = ?`,
        [userId]
      );

      if (checkUserExist.length === 0) {
        return failureResponse(res, 404, "User not found");
      }

      const [fetchPermissionsOfUser] = await conn.query(
        `SELECT p.Name as permissionName
      FROM users as u
      JOIN role AS r
      on u.roleId = r.id
      JOIN
        rolepermission AS rp 
      ON
        r.id = rp.RoleId
      JOIN
        permission AS p
      ON
        rp.PermissionId = p.id
      WHERE
        u.id = ?`,
        userId
      );

      return successResponse(
        res,
        "permissions fetched successfully",
        fetchPermissionsOfUser
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async editloggedInUserProfile(req, res) {
    try {
      const { FirstName, LastName, PhoneNumber, GenderId } = req.body;
      const userId = req.params.id;
      const OrganisationName = req.OrganisationName;
      let profilePhotoPath = null;
      const conn = await connPromise;

      const [checkUserExist] = await conn.query(
        `SELECT * FROM Users WHERE id = ? AND isDeleted <> 1`,
        [userId]
      );

      if (checkUserExist.length === 0) {
        return failureResponse(res, 404, "user not found");
      }

      if (!FirstName || !LastName) {
        return failureResponse(
          res,
          404,
          "Required fields can't be saved empty"
        );
      }

      // Check if a file was uploaded
      if (
        req.files &&
        req.files["ProfilePhotoDoc"] &&
        req.files["ProfilePhotoDoc"][0]
      ) {
        profilePhotoPath = req.files["ProfilePhotoDoc"][0].filename;
      } else {
        profilePhotoPath = checkUserExist[0].ProfilePhoto;
      }

      const updateQuery = `
        UPDATE Users
        SET FirstName = ?, LastName = ?, PhoneNumber = ?,GenderId = ?, ProfilePhoto = ?
        WHERE id = ?`;

      const queryParams = [
        FirstName,
        LastName,
        PhoneNumber,
        GenderId,
        profilePhotoPath,
        userId,
      ];

      const [user] = await conn.query(updateQuery, queryParams);
      return successResponse(res, "User profile updated successfully", user);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async changePassword(req, res) {
    try {
      const userId = req.params.id;
      const { oldPassword, newPassword, confirmPassword } = req.body;
      const conn = await connPromise;

      const [user] = await conn.query(
        "SELECT Password FROM Users WHERE id = ?",
        [userId]
      );

      if (user.length === 0) {
        return failureResponse(res, 404, "User not found");
      }

      if (!oldPassword) {
        return failureResponse(res, 403, "Please enter old password first!");
      }
      const isPasswordValid = await bcrypt.compare(
        oldPassword,
        user[0].Password
      );

      if (!isPasswordValid) {
        return failureResponse(res, 400, "Invalid old password");
      }

      if (!newPassword) {
        return failureResponse(res, 403, "Please enter new password");
      }

      if (newPassword !== confirmPassword) {
        return failureResponse(
          res,
          400,
          "New password and confirm password don't match"
        );
      }

      // Hash the new password
      const hashPassword = await bcrypt.hash(newPassword, 10);

      // Update the user's password in the database
      await conn.query("UPDATE Users SET Password = ? WHERE id = ?", [
        hashPassword,
        userId,
      ]);

      return successResponse(res, "Password changed successfully");
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
}

module.exports = OrganisationService;
