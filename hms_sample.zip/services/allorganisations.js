const { Organisation } = require("../models/organisation");

class getAllOrganisationService {
  static async getAllOrganisations() {
    try {
      const organisation = await Organisation.findAll({
        attributes: ["Name"],
      });
      return { organisation };
    } catch (error) {
      return new Error(error.message);
    }
  }
}

module.exports = getAllOrganisationService;
