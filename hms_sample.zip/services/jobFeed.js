const { v4: uuidv4 } = require("uuid");
require("dotenv").config();
const moment = require("moment");

const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const { connPromise } = require("../config/connection");
const mailHelper = require("../utils/mailHelper");
const { io } = require("../socket");
const { notification } = require("../models/notifications");
class jobFeedService {
  static async createJobs(req, res) {
    try {
      const data = req.body;
      const userId = req.userId;
      const id = uuidv4();

      const conn = await connPromise;

      let status = "Active"; // Default value

      if (!data.Title || !data.Department) {
        return failureResponse(res, 400, "All fields must be present");
      }

      const [checkDepartment] = await conn.query(
        `SELECT * FROM Department WHERE id = ? AND isDeleted <> 1`,
        [data.Department]
      );
      if (checkDepartment.length === 0) {
        return failureResponse(res, 404, "Invalid Department Id");
      }

      const [checkJobExist] = await conn.query(
        `SELECT * FROM JobFeed jf
        JOIN Department as d ON d.id = jf.Department 
        WHERE jf.Title = ? AND jf.isDeleted <> 1 AND d.isDeleted <> 1`,
        [data.Title]
      );

      if (checkJobExist.length > 0) {
        return failureResponse(res, 403, "This job is already exist");
      }

      await conn.query(
        `
          INSERT INTO JobFeed (id , Title, Schedule,Department , Location , Description , Goals , ExpectedHiring , status ,createdBy) VALUES (?, ? ,?,? , ? ,?,?,?,? , ?)`,
        [
          id,
          data.Title,
          data.Schedule,
          data.Department,
          data.Location,
          data.Description,
          data.Goals,
          data.ExpectedHiring,
          status,
          userId,
        ]
      );
      return successResponse(res, "Jobs created successfully", data);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async getAllJobs(req, res) {
    try {
      const conn = await connPromise;
      // Pagination
      const page = parseInt(req.query.page) || 1; // Set default value to 1 if page is not provided or is NaN
      const limit = parseInt(req.query.limit) || 12;
      const startIndex = (page - 1) * limit;
      const endIndex = page * limit;

      // Sorting
      const sortBy = req.query.sortBy || "createdAt";
      const sortOrder = req.query.sortOrder || "asc";
      const order = sortOrder === "desc" ? "DESC" : "ASC";

      // Searching
      const search = req.query.search || "";

      //status
      let status = "";
      if (req.body.status === "Active") {
        status = "Active";
      } else if (req.body.status === "Closed" || req.body.status === "Paused") {
        status = "Closed' OR Status = 'Paused";
      }
      // Get jobs based on status
      const statusCondition = status ? `AND (Status = '${status}')` : "";

      const query = `
        SELECT jf.*
        FROM JobFeed jf
        join department d on jf.department = d.id
        WHERE (jf.Title LIKE ? OR d.Name LIKE ? OR jf.Location LIKE ?)
            AND d.isDeleted <> 1 AND jf.isDeleted <> 1
            ${statusCondition}
        ORDER BY jf.${sortBy} ${order}
        LIMIT ${startIndex},${limit}
        `;
      const params = [`%${search}%`, `%${search}%`, `%${search}%`];

      const [Jobs] = await conn.query(query, params);

      // Fetch and associate counts with each job
      const responseJobs = [];
      for (const job of Jobs) {
        const [jobCounts] = await conn.query(
          `
        
          SELECT COUNT(ci.CandidateId) as totalCandidates,
          SUM(CASE WHEN ci.InterviewStatus = 'Approve' THEN 1 ELSE 0 END) as approvedCount,
          SUM(CASE WHEN ci.InterviewStatus = 'scheduled' THEN 1 ELSE 0 END) as scheduledCount
          FROM candidateinterview ci
          LEFT JOIN Candidates c ON c.id = ci.CandidateId
          WHERE ci.SelectedJobId = ? AND c.isDeleted <> 1
      `,
          [job.id]
        );

        const departmentQuery = `SELECT id,Name FROM Department WHERE id = ? AND isDeleted <> 1`;
        const [department] = await conn.query(departmentQuery, [
          job.Department,
        ]);

        responseJobs.push({
          ...job,
          fetchAllCounts: jobCounts[0],
          postedDate: job.createdAt.toISOString().split("T")[0],
          department: department[0],
        });
      }

      // Get total number of users
      const countQuery = `
      SELECT COUNT(*) as total FROM JobFeed jf
      join department d on jf.department = d.id
      WHERE (jf.Title LIKE ? OR d.Name LIKE ? OR jf.Location LIKE ?)
      AND d.isDeleted <> 1 AND jf.isDeleted <> 1
      ${statusCondition}
    `;

      const [count] = await conn.query(countQuery, [
        `%${search}%`,
        `%${search}%`,
        `%${search}%`,
      ]);

      const response = {
        data: responseJobs,
        total: count[0].total,
        currentPage: page,
        totalPages: Math.ceil(count[0].total / limit),
      };

      return successResponse(res, "All Jobs retrieved successfully", response);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async getJobById(req, res) {
    try {
      const id = req.params.id;
      const conn = await connPromise;
      const [checkJob] = await conn.query(
        `SELECT * FROM JobFeed WHERE id = ? AND isDeleted <> 1`,
        [id]
      );

      if (checkJob.length === 0) {
        return failureResponse(res, 404, "Job with this id does not exist");
      }
      const job = {
        ...checkJob[0],
        postedDate: checkJob[0].createdAt.toISOString().split("T")[0],
      };
      return successResponse(res, "Fetch Job By Id successfully", job);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async editJob(req, res) {
    try {
      const data = req.body;
      const id = req.params.id;
      const userId = req.userId;
      const conn = await connPromise;

      if (!data.Title || !data.Department) {
        return failureResponse(res, 400, "can't save empty values");
      }

      const [jobName] = await conn.query(
        "SELECT * FROM JobFeed WHERE Title = ? AND id != ? AND isDeleted <> 1",
        [data.Title, id]
      );
      if (jobName.length !== 0) {
        return failureResponse(res, 400, "Job already exists");
      }

      const [checkJobExist] = await conn.query(
        `SELECT * FROM JobFeed WHERE id = ? AND isDeleted <> 1`,
        id
      );

      if (checkJobExist.length === 0) {
        return failureResponse(res, 404, "Job not found");
      }
      const [checkDepartment] = await conn.query(
        `SELECT * FROM Department WHERE id = ? AND isDeleted <> 1`,
        [data.Department]
      );
      if (checkDepartment.length === 0) {
        return failureResponse(res, 404, "Invalid Department Id");
      }

      await conn.query(
        `UPDATE JobFeed SET 
          Title = ?, 
          Schedule = ?,
          Department = ?, 
          Location = ?, 
          Description = ?, 
          Goals = ?, 
          ExpectedHiring = ?,
          updatedAt = NOW(),
          updatedBy = ?
        WHERE id = ?`,
        [
          data.Title,
          data.Schedule,
          data.Department,
          data.Location,
          data.Description,
          data.Goals,
          data.ExpectedHiring,
          userId,
          id,
        ]
      );

      return successResponse(res, "Job updated successfully", data);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async deleteJob(req, res) {
    try {
      const id = req.params.id;
      const userId = req.userId;

      const conn = await connPromise;

      const [checkJobExist] = await conn.query(
        `SELECT * FROM JobFeed WHERE id = ? AND isDeleted <> 1`,
        [id]
      );
      if (checkJobExist.length === 0) {
        return failureResponse(res, 404, "Job with this id does not exist!");
      }
      const [deletedJob] = await conn.query(
        `UPDATE JobFeed SET isDeleted = 1 , deletedAt = NOW() , deletedBy = ? WHERE id = ?`,
        [userId, id]
      );
      return successResponse(res, "Job deleted successfully", deletedJob);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async updateJobStatus(req, res) {
    try {
      const data = req.body;
      const jobId = req.params.id;
      const { status } = req.body;
      const conn = await connPromise;

      // Check if the job exists
      const [job] = await conn.query("SELECT * FROM JobFeed WHERE id = ?", [
        jobId,
      ]);
      if (job.length === 0) {
        return failureResponse(res, 404, "Job not found");
      }

      // Check if the provided status is valid
      const allowedStatusValues = ["Active", "Paused", "Closed"];
      if (!allowedStatusValues.includes(status)) {
        return failureResponse(res, 400, "Invalid status value");
      }

      // Update the status
      const [result] = await conn.query(
        "UPDATE JobFeed SET status = ? WHERE id = ?",
        [status, jobId]
      );
      return successResponse(res, "Job status updated successfully", data);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async shareJob(req, res) {
    try {
      const data = req.body;
      const conn = await connPromise;
      const [user] = await conn.query(`SELECT Email FROM Users`);
      const sendMail = await mailHelper({
        email: "zaselawudde-6194@yopmail.com",
        subject: "Job Share email",
        message: "Send",
      });

      return successResponse(res, "success", user, sendMail);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async getCandidatesOfJobFeed(req, res) {
    try {
      const conn = await connPromise;
      const id = req.params.id;
      const currentIndex = req.body.index;

      const [jobCount] = await conn.query(
        `
      SELECT COUNT(*) AS jobCount
      FROM JobFeed
      WHERE id = ?
      `,
        [id]
      );

      if (jobCount[0].jobCount == 0) {
        return failureResponse(res, 404, "Job not found");
      }

      const query = `
      SELECT c.*
      FROM JobFeed j
      JOIN candidateinterview ci ON j.id = ci.SelectedJobId
      JOIN Candidates c ON ci.CandidateId = c.id
      WHERE j.id = ? AND c.isDeleted <> 1 AND j.isDeleted <> 1
    `;

      const countQuery = `
      SELECT COUNT(*) AS totalCandidates
      FROM JobFeed j
      JOIN candidateinterview ci ON j.id = ci.SelectedJobId
      JOIN Candidates c ON ci.CandidateId = c.id
      WHERE j.id = ? AND c.isDeleted <> 1 AND j.isDeleted <> 1
    `;

      const [results] = await conn.query(query, [id]);
      const [results2] = await conn.query(countQuery, [id]);

      if (results.length === 0) {
        const nullRes = {
          results: {
            candidate: null,
            interview: null,
          },
          approvedCount: 0,
          rejectedCount: 0,
          waitingCount: 0,
          sheduledCount: 0,
          count: 0,
          index: 0,
        };
        return successResponse(res, "No candidate found", nullRes);
      }

      let candidateIds = [];
      results.forEach((element) => {
        candidateIds.push(element.id);
      });

      const count = results2.length > 0 ? results2[0].totalCandidates : 0;

      const [candidateInterviewDetail] = await conn.query(
        `SELECT DISTINCT ci.*, CONCAT(c.FirstName, ' ', c.LastName) AS CandidateName
        FROM jobfeed AS jf
        LEFT JOIN candidateinterview AS ci ON ci.SelectedJobId = jf.id
        LEFT JOIN Candidates AS c ON ci.CandidateId = c.id
        WHERE ci.CandidateId IN (?) AND jf.id = ? AND c.isDeleted <> 1
        ORDER By ci.createdAt desc`,
        [candidateIds, id]
      );

      const [approvedCandidateCount] = await conn.query(
        `SELECT COUNT(*) as approvedCount
        FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE ci.SelectedJobId = ? AND ci.InterviewStatus = 'Approve' AND c.isDeleted <> 1`,
        [id]
      );

      const [rejectedCandidateCount] = await conn.query(
        `SELECT COUNT(*) as rejectedCount
        FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE ci.SelectedJobId = ? AND ci.InterviewStatus = 'Reject' AND c.isDeleted <> 1`,
        [id]
      );

      const [waitingCandidateCount] = await conn.query(
        `SELECT COUNT(*) as waitingCount
        FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE ci.SelectedJobId = ? AND ci.InterviewStatus = 'waiting' AND c.isDeleted <> 1`,
        [id]
      );

      const [sheduledCandidateCount] = await conn.query(
        `SELECT COUNT(*) as scheduledCount
        FROM candidateinterview ci
        JOIN candidates c 
        ON ci.CandidateId = c.id
        WHERE ci.SelectedJobId = ? AND ci.InterviewStatus = 'scheduled' AND c.isDeleted <> 1`,
        [id]
      );

      // Update the interview status if needed
      // const currentDatetime = new Date();
      // const updateStatusQuery = `
      //     UPDATE candidateinterview
      //     SET InterviewStatus = 'waiting'
      //     WHERE SelectedJobId = ? AND InterviewStatus <> 'completed' AND ScheduleDateTime < ?`;

      // await conn.query(updateStatusQuery, [id, currentDatetime]);

      const [ongoingInterviews] = await conn.query(
        `SELECT id, StartDateTime, InterviewStatus FROM candidateinterview WHERE InterviewStatus = 'scheduled' AND StartDateTime IS NOT NULL`
      );

      const currentDatetime = new Date();

      for (const interview of ongoingInterviews) {
        const startDateTime = interview.StartDateTime;

        const [fetchInterviewDuration] = await conn.query(
          `SELECT Value FROM Settings WHERE Field = 'InterviewDurationTime'`
        );
        const interviewDuration = fetchInterviewDuration[0].Value / 60000;

        const fetchInterviewEndTime = new Date(
          new Date().setMinutes(startDateTime.getMinutes() + interviewDuration)
        );

        if (currentDatetime > fetchInterviewEndTime) {
          await conn.query(
            `UPDATE candidateinterview SET InterviewStatus = ? WHERE id = ?`,
            ["completed", interview.id]
          );
        }
      }

      let index = currentIndex || 0;
      if (index === "null" || index === "undefined" || index < 0) {
        index = 0;
      } else if (index >= count) {
        index = count - 1;
      }
      const approvedCount = approvedCandidateCount[0].approvedCount;
      const rejectedCount = rejectedCandidateCount[0].rejectedCount;
      const waitingCount = waitingCandidateCount[0].waitingCount;
      const scheduledCount = sheduledCandidateCount[0].scheduledCount;

      const interview = candidateInterviewDetail.filter(
        (x) => x.CandidateId === results[index].id
      )[0];

      const [interviewScore] = await conn.query(
        `SELECT IsCorrect FROM interviewquestion 
        WHERE InterviewId = ?`,
        [interview.id]
      );

      const interviewMarks = interviewScore.reduce(
        (acc, obj) => acc + obj.IsCorrect,
        0
      );

      const response = {
        results: {
          candidate: results[index],
          interview: candidateInterviewDetail.filter(
            (x) => x.CandidateId === results[index].id
          )[0],
        },
        interviewMarks,
        approvedCount,
        rejectedCount,
        waitingCount,
        scheduledCount,
        count,
        index,
      };

      return successResponse(
        res,
        "Candidates of a Job Feed retrieved successfully",
        response
      );
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  // static async getAllInterviews(req, res) {
  //   try {
  //     const conn = await connPromise;

  //     // Sorting
  //     const sortBy = req.query.sortBy || "createdAt";
  //     const sortOrder = req.query.sortOrder || "desc";
  //     const order = sortOrder === "desc" ? "DESC" : "ASC";

  //     const [rows] = await conn.query(
  //       `SELECT ci.*, CONCAT(c.FirstName, ' ', c.LastName) AS CandidateName
  //       FROM CandidateInterview AS ci
  //       JOIN Candidates AS c ON c.id = ci.CandidateId
  //       WHERE ci.InterviewStatus = 'scheduled'
  //       ORDER BY ci.${sortBy} ${order}`
  //     );

  //     return successResponse(
  //       res,
  //       "All Interviews retrieved successfully",
  //       rows
  //     );
  //   } catch (err) {
  //     return failureResponse(res, 500, err.message);
  //   }
  // }

  static async getAllInterviews(req, res) {
    try {
      const conn = await connPromise;

      // Get the current date in the format 'YYYY-MM-DD'
      const currentDate = new Date();

      // Sorting
      const sortBy = req.query.sortBy || "createdAt";
      const sortOrder = req.query.sortOrder || "desc";
      const order = sortOrder === "desc" ? "DESC" : "ASC";

      const [rows] = await conn.query(
        `SELECT ci.*, jf.Title as jobTitle, d.Name as departmentName , CONCAT(c.FirstName, ' ', c.LastName) AS CandidateName
        FROM CandidateInterview AS ci
        JOIN JobFeed AS jf ON jf.id = ci.SelectedJobId
        JOIN Department AS d ON d.id = jf.department
        JOIN Candidates AS c ON c.id = ci.CandidateId
        WHERE ci.InterviewStatus = 'scheduled'
        AND date(ci.ScheduleDateTime) = current_date()
        ORDER BY ci.${sortBy} ${order}`,
        [currentDate]
      );

      return successResponse(
        res,
        "Today's Interviews retrieved successfully",
        rows
      );
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async editInterviewSchedule(req, res) {
    try {
      const data = req.body;
      const interviewId = req.params.id;
      const createdBy = req.userId;
      const OrganisationId = req.OrganisationId;
      const conn = await connPromise;

      if (!data.ScheduleDateTime || !data.InterviewMode) {
        return failureResponse(res, 400, "Required fields must be present");
      }

      const [checkInterview] = await conn.query(
        `SELECT * FROM CandidateInterview WHERE id = ?`,
        [interviewId]
      );
      if (checkInterview.length === 0) {
        return failureResponse(res, 404, "Interview not found");
      }

      const [fetchJobId] = await conn.query(
        `SELECT jf.id as jobId FROM CandidateInterview as ci
        JOIN jobfeed as jf ON ci.SelectedJobId = jf.id
        JOIN candidates as c ON c.id = ci.CandidateId
        WHERE ci.id = ? AND jf.isDeleted <> 1 AND c.isDeleted <> 1`,
        [interviewId]
      );

      if (fetchJobId.length === 0) {
        return failureResponse(res, 404, "Job does not exist");
      }

      const [checkInterviewScheduledForAJob] = await conn.query(
        `SELECT * FROM CandidateInterview as ci
        JOIN jobfeed as jf ON ci.SelectedJobId = jf.id
        WHERE ci.id = ? AND jf.id = ? AND jf.isDeleted <> 1`,
        [interviewId, fetchJobId[0].jobId]
      );

      // if (checkInterviewScheduledForAJob[0].ScheduleDateTime) {
      //   return failureResponse(
      //     res,
      //     403,
      //     "Interview of this candidate is already scheduled for this job"
      //   );
      // }

      await conn.query(
        `
        UPDATE CandidateInterview
        SET  ScheduleDateTime = ?, InterviewMode = ?, Location = ?, InterviewStatus = 'scheduled' , StartDateTime = null
        WHERE id = ?
        `,
        [data.ScheduleDateTime, data.InterviewMode, data.Location, interviewId]
      );
      io.emit("interviewSchedule", {
        Message: `Interview of ${
          data.FirstName + " " + data.LastName
        } is scheduled on ${data.ScheduleDateTime}`,
      });
      const notificationId = uuidv4();

      await notification.create({
        id: notificationId,
        OrganisationId: OrganisationId,
        UserId: createdBy,
        Message: `Interview of ${
          data.FirstName + " " + data.LastName
        } is scheduled on ${data.ScheduleDateTime}`,
        Status: "interviewSchedule",
      });
      return successResponse(res, "Interview updated successfully");
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async setCandidateStatus(req, res) {
    try {
      const conn = await connPromise;
      const id = req.params.id;
      const employeeId = uuidv4();
      const createdBy = req.userId;
      const OrganisationId = req.OrganisationId;
      const { status, jobId } = req.body;

      const [result] = await conn.query(
        `SELECT * FROM Candidates WHERE id IN (?) AND isDeleted <> 1`,
        [id]
      );

      if (result.length === 0) {
        return failureResponse(res, 404, "Candidate Not found");
      }

      const [fetchCandidatesDepartment] = await conn.query(
        `select d.id as DepartmentId from candidates as c
      join candidateinterview as ci on c.id = ci.CandidateId
      join jobfeed as jf on jf.id = ci.SelectedJobId
      join department as d on jf.Department = d.id
      where c.id = ?`,
        [id]
      );

      const [existingUser] = await conn.query(
        "SELECT * FROM Users WHERE Email = ? AND isDeleted <> 1",
        [result[0].Email]
      );

      const [checkInterviewComplete] = await conn.query(
        `SELECT * FROM candidateinterview WHERE InterviewStatus = 'completed' AND CandidateId = ?`,
        [id]
      );

      if (status == "Approve") {
        if (existingUser.length !== 0) {
          // The email already exists in the Users table, handle accordingly
          return failureResponse(
            res,
            400,
            "This Email already exists in the Employee Table"
          );
        }

        if (checkInterviewComplete.length === 0) {
          return failureResponse(res, 400, "Your Interview not completed yet");
        }

        await conn.query(
          `UPDATE candidateinterview SET InterviewStatus = 'Approve' WHERE CandidateId = ? AND SelectedJobId = ?`,
          [result[0].id, jobId]
        );

        const [fetchRoleId] = await conn.query(
          `SELECT id as RoleId FROM Role where Name = 'User'`
        );
        // Create a user in the user table
        await conn.query(
          `INSERT INTO Users (id, CandidateId, FirstName, LastName, Email, GenderId, DepartmentId,RoleId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            employeeId,
            result[0].id,
            result[0].FirstName,
            result[0].LastName,
            result[0].Email,
            result[0].GenderId,
            fetchCandidatesDepartment[0].DepartmentId,
            fetchRoleId[0].RoleId,
          ]
        );

        // Insert candidate's skills into user skill table
        const [candidateSkills] = await conn.query(
          `SELECT * FROM candidateskill WHERE CandidateId = ?`,
          [id]
        );
        console.log("candidateSkills +++++++++", candidateSkills);
        for (const skill of candidateSkills) {
          await conn.query(
            `INSERT INTO userskill (UserId,CandidateId,SkillId) VALUES (?, ?,?)`,
            [employeeId, result[0].id, skill.SkillId]
          );
        }

        io.emit("candidateApprove", {
          Message: `candidate ${
            result[0].FirstName + " " + result[0].LastName
          } is approved as an employee`,
        });
        const notificationId = uuidv4();

        await notification.create({
          id: notificationId,
          OrganisationId: OrganisationId,
          UserId: createdBy,
          Message: `candidate ${
            result[0].FirstName + " " + result[0].LastName
          } is approved as an employee`,
          Status: "candidateApprove",
        });

        return successResponse(res, "Status updated and user created", status);
      } else if (status == "Reject") {
        // Delete candidate's skills from user skill table first
        await conn.query(`DELETE FROM userskill WHERE UserId = ?`, [
          employeeId,
        ]);

        // Now delete the record from the Users table
        await conn.query(
          `DELETE FROM Users WHERE CandidateId = ? AND isDeleted <> 1`,
          [employeeId]
        );

        // Update the candidateinterview table to set InterviewStatus to 'Reject'
        await conn.query(
          `UPDATE candidateinterview SET InterviewStatus = 'Reject' WHERE CandidateId = ? AND SelectedJobId = ?`,
          [id, jobId]
        );
        return successResponse(res, "Status updated", status);
      } else {
        return failureResponse(res, 400, "Please Enter Status");
      }
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }

  static async getAllJobNames(req, res) {
    try {
      const conn = await connPromise;

      const query = `
      SELECT jf.*
      FROM JobFeed jf
      join department d on jf.department = d.id
      WHERE d.isDeleted <> 1 AND jf.isDeleted <> 1
        `;

      const [Jobs] = await conn.query(query);

      const response = {
        data: Jobs,
      };

      return successResponse(res, "All Jobs retrieved successfully", response);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }
}

module.exports = jobFeedService;
