const { connPromise } = require("../config/connection");
const { v4: uuidv4 } = require("uuid");
const pdfService = require("../utils/pdf");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");

const { Configuration, OpenAIApi } = require("openai");

const configuration = new Configuration({
  apiKey: process.env.OPEN_AI_SECRETKEY,
});
const openai = new OpenAIApi(configuration);
const { io } = require("../socket");

class InterviewScheduleService {
  static async addInterviewSchedule(req, res) {
    try {
      const data = req.body;
      const id = uuidv4();
      const conn = await connPromise;
      if (!data.CandidateId || !data.ScheduleDateTime || !data.InterviewMode) {
        return failureResponse(res, 400, "Required fields must be present");
      }

      const [checkCandidate] = await conn.query(
        `SELECT * FROM Candidates WHERE id = ? AND isDeleted <> 1`,
        [data.CandidateId]
      );
      if (checkCandidate.length === 0) {
        return failureResponse(res, 404, "Invalid Candidate Id");
      }

      const allowedStatusValues = ["waiting", "scheduled", "completed"];
      if (!allowedStatusValues.includes(data.Status)) {
        return failureResponse(res, 404, "Invalid Status Value");
      }
      const score = data.Status === "completed" ? data.Score : null;

      const allowedInterviewModeValues = ["walkin", "ai", "videocall"];

      if (!allowedInterviewModeValues.includes(data.InterviewMode)) {
        return failureResponse(res, 404, "Invalid InterviewMode Value");
      }

      const candidateReview =
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

      await conn.query(
        `
        INSERT INTO CandidateInterview (id, CandidateId, ScheduleDateTime, InterviewStatus, InterviewMode, Location, CandidateReview,Rating,Matching)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          id,
          data.CandidateId,
          data.ScheduleDateTime,
          data.Status,
          data.InterviewMode,
          data.Location,
          candidateReview,
          data.Rating,
          data.Matching,
        ]
      );

      return successResponse(res, "Interview added successfully", data);
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  }

  static async getInterviewDetails(req, res) {
    try {
      const conn = await connPromise;
      const { interviewId, organisationName } = req.query;

      await conn.query(`USE hms_${organisationName};`);

      const [candidateDetails] = await conn.query(
        `SELECT c.*
        FROM candidateinterview ci 
        JOIN candidates c ON 
        ci.CandidateId = c.id 

        WHERE ci.id = ?`,
        [interviewId]
      );

      if (candidateDetails.length === 0) {
        return failureResponse(res, 400, "Interview not found");
      }

      const [interviewDetails] = await conn.query(
        `SELECT ci.*
        FROM candidateinterview ci 
        JOIN candidates c ON 
        ci.CandidateId = c.id 

        WHERE ci.id = ?`,
        [interviewId]
      );

      const [jobDetails] = await conn.query(
        `SELECT j.*
        FROM candidateinterview ci 
        JOIN candidates c ON ci.CandidateId = c.id 
        JOIN jobfeed j on j.id = ci.SelectedJobId
        
        WHERE ci.id = ?`,
        [interviewId]
      );

      const reponse = {
        candidateDetails: candidateDetails[0],
        interviewDetail: interviewDetails[0],
        jobDetails: jobDetails[0],
      };

      return successResponse(res, "Interview details found", reponse);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
  static async generateInterviewQuestions(
    jobName,
    experienceDuration,
    interviewId
  ) {
    // Combine candidate skills and experience to create a prompt for OpenAI

    const prompt = `You are a Technical Test Evaluator. You will generate 10 technical questions for a candidate based on the job "${jobName}"  and relevent Experience duration which is "${experienceDuration}" years , 
    For example a candidate have an experince of 3 years and the jobName is Angular developer, then you have to give 10 questions in Angular based on 3 years of experience, same applied for all jobs and relevent experince `;

    // Make a request to OpenAI to generate the questions
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      temperature: 0.5,
      max_tokens: 500,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
    });

    // Extract the generated question from the OpenAI response
    // const generatedQuestion = response.data.choices[0].text.trim();
    const generatedQuestion = response.data.choices[0].text
      .split("\n")
      .map((question) => question.trim())
      .filter((question) => question !== "");

    const auditLogData = {
      CreatedBy: null,
      Type: "GetInterviewQuestions",
      Model: response.data.model,
      Messages: response.config.data,
      InputTokens: response.data.usage.prompt_tokens,
      ResponseTokens: response.data.usage.completion_tokens,
      TotalTokens: response.data.usage.total_tokens,
      RequestType: response.config.method,
      Response: JSON.stringify(generatedQuestion),
      StatusCode: response.status,
      RecordId: interviewId,
    };
    const conn = await connPromise;
    // Insert audit log entry with input data and response details
    const [auditLogEntry] = await conn.query(
      `INSERT INTO AuditLogs (CreatedBy, Type, Model, Messages, InputTokens, ResponseTokens, TotalTokens, RequestType, Response, StatusCode, RecordId) 
       VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        auditLogData.CreatedBy,
        auditLogData.Type,
        auditLogData.Model,
        auditLogData.Messages,
        auditLogData.InputTokens,
        auditLogData.ResponseTokens,
        auditLogData.TotalTokens,
        auditLogData.RequestType,
        auditLogData.Response,
        auditLogData.StatusCode,
        auditLogData.RecordId,
      ]
    );

    return generatedQuestion;
  }

  static async startInterview(req, res) {
    try {
      const conn = await connPromise;
      const { interviewId, organisationName } = req.body;

      await conn.query(`USE hms_${organisationName};`);

      const [checkInterviewExist] = await conn.query(
        `SELECT * FROM candidateinterview
        WHERE id = ?`,
        [interviewId]
      );

      if (checkInterviewExist.length === 0) {
        return failureResponse(res, 400, "Interview not found");
      }

      if (checkInterviewExist[0].InterviewStatus !== "scheduled") {
        return failureResponse(res, 400, "Your Interview is not scheduled yet");
      }

      const [extractJobName] = await conn.query(
        `select jf.Title as jobName , ci.CandidateId as candidateId from candidateinterview as ci
      join candidates as c on c.id = ci.CandidateId
      join jobfeed as jf on jf.id = ci.SelectedJobId
      where ci.id = ?`,
        [interviewId]
      );
      const jobName = extractJobName[0].jobName;

      const [extractCandidateExperience] = await conn.query(
        `select ce.* from candidateexperience as ce 
      join candidates as c on c.id = ce.candidateid
      join candidateinterview as ci on ci.candidateid = c.id
      where ci.id = ?`,
        [interviewId]
      );

      let experienceDurationInMs = 0;

      if (extractCandidateExperience.length > 0) {
        experienceDurationInMs =
          extractCandidateExperience[0].EndDate -
          extractCandidateExperience[0].StartDate;
      }
      const experienceDurationInYears =
        experienceDurationInMs / (1000 * 60 * 60 * 24 * 365);

      const experienceDuration = Math.floor(experienceDurationInYears);

      const currentDatetime = new Date();
      // const interviewStartTime = currentDatetime.toISOString();

      const [interviewSchedule] = await conn.query(
        `SELECT ScheduleDateTime FROM candidateinterview WHERE id = ?`,
        [interviewId]
      );

      const interviewScheduleTime = interviewSchedule[0].ScheduleDateTime;

      const [interviewStartDuration] = await conn.query(`SELECT Value
      FROM Settings
      WHERE Field = 'InterviewStartDurationTime'`);

      const interviewStartDurationTime =
        interviewStartDuration[0].Value / 60000;

      const interviewStartLimitTime = new Date(
        new Date().setMinutes(
          interviewScheduleTime.getMinutes() + interviewStartDurationTime
        )
      );

      // check fake candidate
      if (checkInterviewExist[0].StartDateTime) {
        return failureResponse(res, 500, "Interview conducted");
      } else if (interviewStartLimitTime < currentDatetime) {
        return failureResponse(res, 500, "Times up");
      } else if (interviewScheduleTime > currentDatetime) {
        return failureResponse(res, 500, "Interview scheduled in future");
      }

      const [InterviewStartTime] = await conn.query(
        `UPDATE candidateinterview SET StartDateTime =? WHERE id = ?`,
        [currentDatetime, interviewId]
      );

      const [fetchInterviewDuration] = await conn.query(`SELECT Value
      FROM Settings
      WHERE Field = 'InterviewDurationTime'`);

      const [fetchInterviewStartTime] = await conn.query(
        `SELECT StartDateTime FROM candidateinterview where id = ?`,
        [interviewId]
      );

      const generatedQuestion =
        await InterviewScheduleService.generateInterviewQuestions(
          jobName,
          experienceDuration,
          interviewId
        );

      const startDateTime = fetchInterviewStartTime[0].StartDateTime;
      const interviewDuration = fetchInterviewDuration[0].Value / 60000;

      const fetchInterviewEndTime = new Date(
        new Date().setMinutes(startDateTime.getMinutes() + interviewDuration)
      );

      await conn.query(
        `UPDATE candidateinterview SET EndDateTime = ? WHERE id = ?`,
        [fetchInterviewEndTime, interviewId]
      );

      const [existingQuestions] = await conn.query(
        `SELECT Question FROM InterviewQuestion WHERE InterviewId = ?`,
        [interviewId]
      );

      // if (existingQuestions.length > 0) {
      //   // Questions are already saved for this interview, no need to insert again
      //   return failureResponse(
      //     res,
      //     400,
      //     "Questions are already saved for this interview"
      //   );
      // }

      await conn.query(`DELETE FROM InterviewQuestion WHERE InterviewId = ?`, [
        interviewId,
      ]);

      const questionsToSave = generatedQuestion.map((question) => {
        const questionWithoutNumbering = question.replace(/^\d+\.\s+/, "");
        return questionWithoutNumbering;
      });
      for (const question of questionsToSave) {
        const id = uuidv4();
        await conn.query(
          `INSERT INTO InterviewQuestion(id, InterviewId, Question) VALUES (?,?,?)`,
          [id, interviewId, question]
        );
      }
      return successResponse(res, "Interview Started");
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
  // Helper function to check answer correctness using OpenAI
  static async generateAnswer(question, candidateAnswer, interviewId) {
    // Combine the question and candidate's answer
    const prompt = `You are a Technical Test Evaluator. For this question '${question}' , You have to match candidate this answer '${candidateAnswer}' based on your knowledge 
    and give a response in boolean value 1 or 0,
    1 means the answer is correct and 0 means the answer is not matched or not correct`;

    // Make a request to OpenAI to generate the completion
    const response = await openai.createCompletion({
      model: "text-davinci-003", // Use the language model of your choice
      prompt: prompt,
      temperature: 0.5,
      max_tokens: 500,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
    });

    // Extract the generated completion from the OpenAI response
    const isCorrect = response.data.choices[0].text.trim();
    const setIsCorrect = isCorrect.match(/\d/g).join("");

    const auditLogData = {
      CreatedBy: null,
      Type: "CheckAnswer",
      Model: response.data.model,
      Messages: response.config.data,
      InputTokens: response.data.usage.prompt_tokens,
      ResponseTokens: response.data.usage.completion_tokens,
      TotalTokens: response.data.usage.total_tokens,
      RequestType: response.config.method,
      Response: setIsCorrect,
      StatusCode: response.status,
      RecordId: interviewId,
    };
    const conn = await connPromise;
    // Insert audit log entry with input data and response details
    const [auditLogEntry] = await conn.query(
      `INSERT INTO AuditLogs (CreatedBy, Type, Model, Messages, InputTokens, ResponseTokens, TotalTokens, RequestType, Response, StatusCode, RecordId) 
       VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        auditLogData.CreatedBy,
        auditLogData.Type,
        auditLogData.Model,
        auditLogData.Messages,
        auditLogData.InputTokens,
        auditLogData.ResponseTokens,
        auditLogData.TotalTokens,
        auditLogData.RequestType,
        auditLogData.Response,
        auditLogData.StatusCode,
        auditLogData.RecordId,
      ]
    );
    return isCorrect;
  }

  static async saveAnswer(req, res) {
    try {
      const conn = await connPromise;
      const {
        interviewId,
        organisationName,
        questionId,
        Answer,
        questionIndex,
      } = req.body;
      const currentDatetime = new Date();
      await conn.query(`USE hms_${organisationName};`);

      const [checkInterviewExist] = await conn.query(
        `SELECT * FROM candidateinterview WHERE id = ?`,
        [interviewId]
      );

      if (checkInterviewExist.length === 0) {
        return failureResponse(res, 400, "Interview not found");
      }

      const [checkQuestionExist] = await conn.query(
        `SELECT * FROM InterviewQuestion WHERE id = ?`,
        [questionId]
      );

      if (checkQuestionExist.length === 0) {
        return failureResponse(res, 400, "Question not found");
      }

      // Get the actual question from the database
      const [questionData] = await conn.query(
        `SELECT Question FROM InterviewQuestion WHERE id = ?`,
        [questionId]
      );

      const actualQuestion = questionData[0].Question;

      // Use OpenAI to check the correctness of the candidate's answer
      const isCorrect = await InterviewScheduleService.generateAnswer(
        actualQuestion,
        Answer,
        interviewId
      );

      const setIsCorrect = isCorrect.match(/\d/g).join("");

      const [saveAnswer] = await conn.query(
        `UPDATE InterviewQuestion SET Answer = ? , IsCorrect = ? WHERE id = ?`,
        [Answer, setIsCorrect, questionId]
      );

      const [fetchInterviewStartTime] = await conn.query(
        `SELECT StartDateTime FROM candidateinterview where id = ?`,
        [interviewId]
      );

      const startDateTime = fetchInterviewStartTime[0].StartDateTime;

      // Calculate the interview end time based on start time and duration
      const [fetchInterviewDuration] = await conn.query(`SELECT Value
      FROM Settings
      WHERE Field = 'InterviewDurationTime'`);
      const interviewDuration = fetchInterviewDuration[0].Value / 60000;

      const fetchInterviewEndTime = new Date(
        new Date().setMinutes(startDateTime.getMinutes() + interviewDuration)
      );
      if (questionIndex >= 9 || currentDatetime > fetchInterviewEndTime) {
        // Check if all questions are answered or interview time has elapsed
        await conn.query(
          `UPDATE candidateinterview SET InterviewStatus = ? WHERE id = ?`,
          ["completed", interviewId]
        );
      }

      return successResponse(res, "Answer Saved", saveAnswer);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async getQuestionOnIndex(req, res) {
    try {
      const conn = await connPromise;
      const { interviewId, organisationName, currentIndex } = req.body;
      const currentDatetime = new Date();

      await conn.query(`USE hms_${organisationName};`);

      const [checkInterviewExist] = await conn.query(
        `SELECT * FROM candidateinterview WHERE id = ?`,
        [interviewId]
      );

      if (checkInterviewExist.length === 0) {
        return failureResponse(res, 400, "Interview not found");
      }

      const [interviewDuration] = await conn.query(`SELECT Value
      FROM Settings
      WHERE Field = 'InterviewDurationTime'`);

      const InterviewRunningTime =
        interviewDuration[0].Value + checkInterviewExist[0].StartDateTime;

      if (
        checkInterviewExist[0].ScheduleDateTime >
        checkInterviewExist[0].StartDateTime
      ) {
        return failureResponse(res, 403, "Your time is not started yet");
      } else if (InterviewRunningTime > checkInterviewExist[0].EndDateTime) {
        return failureResponse(res, 403, "Your time ends up");
      }
      const [getAllQuestions] = await conn.query(
        `SELECT * FROM InterviewQuestion WHERE InterviewId = ?`,
        [interviewId]
      );

      const [questionCount] = await conn.query(
        `SELECT count(*) as totalQustions FROM InterviewQuestion WHERE InterviewId = ?`,
        [interviewId]
      );

      const count = questionCount[0].totalQustions;
      let index = currentIndex || 0;
      if (index === "null" || index === "undefined" || index < 0) {
        index = 0;
      } else if (index >= count) {
        index = count - 1;
      }

      return successResponse(
        res,
        "All questions reterived",
        getAllQuestions[index]
      );
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async getCandidateByInterviewId(req, res) {
    try {
      const conn = await connPromise;
      const { interviewId, organisationName } = req.query;

      await conn.query(`USE hms_${organisationName};`);

      const [checkInterviewExist] = await conn.query(
        `SELECT * FROM candidateinterview WHERE id = ?`,
        [interviewId]
      );

      if (checkInterviewExist.length === 0) {
        return failureResponse(res, 400, "Interview not found");
      }

      const [candidateDetails] = await conn.query(
        `SELECT C.* FROM candidateinterview CI
        JOIN candidates C 
        ON C.id = CI.CandidateId
        WHERE C.isDeleted <> 1 AND CI.id = ?`,
        [interviewId]
      );

      const [interviewDetails] = await conn.query(
        `SELECT * FROM candidateinterview
        WHERE id = ?`,
        [interviewId]
      );

      const response = {
        candidate: candidateDetails[0],
        insterviewDetail: interviewDetails[0],
      };

      return successResponse(res, "Candidate found", response);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
}
module.exports = InterviewScheduleService;
