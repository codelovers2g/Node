const { connPromise } = require("../config/connection");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const { v4: uuidv4 } = require("uuid");

class RoleService {
  static async getRoleList(req, res) {
    try {
      const conn = await connPromise;
      const getRole = await conn.query(
        `SELECT * FROM role WHERE isDeleted <> 1 AND Name <> 'MasterAdmin'`
      );
      return successResponse(res, "Success", getRole[0]);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }
  static async getPermissionList(req, res) {
    try {
      const conn = await connPromise;
      const getPermission = await conn.query(
        `SELECT * FROM Permission WHERE Name <> 'MasterAdmin'`
      );
      return successResponse(res, "Success", getPermission[0]);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static createRole = async (req, res) => {
    try {
      const conn = await connPromise;
      const data = req.body;
      const userId = req.userId;
      const id = uuidv4();

      if (!data.Name) {
        return failureResponse(res, 400, "Role name is required");
      }

      const [checkDepartmentExist] = await conn.query(
        `SELECT Name FROM role WHERE Name = ? AND isDeleted <> 1`,
        [data.Name]
      );
      if (checkDepartmentExist.length !== 0) {
        return failureResponse(res, 400, "Role with this name already exist");
      }

      const [result] = await conn.query(
        `INSERT INTO role (id, Name, Description, createdBy, isDeleted ) VALUES (?, ? ,? ,? ,? )`,
        [id, data.Name, data.Description, userId, 0]
      );

      if (data.Permissions?.length > 0) {
        data.Permissions.forEach(async (permission) => {
          await conn.query(
            `INSERT INTO rolepermission (RoleId , PermissionId ) VALUES (?, ? )`,
            [id, permission]
          );
        });
      }

      return successResponse(res, "Role created successfully", data);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  };

  static getAllRoles = async (req, res) => {
    try {
      const conn = await connPromise;

      // Pagination
      const page = parseInt(req.query.page) || 1; // Set default value to 1 if page is not provided or is NaN
      const limit = parseInt(req.query.limit) || 10;
      const startIndex = (page - 1) * limit;
      const endIndex = page * limit;

      // Sorting
      const sortBy = req.query.sortBy || "createdAt";
      const sortOrder = req.query.sortOrder || "asc";
      const order = sortOrder === "desc" ? "DESC" : "ASC";

      // Searching
      const search = req.query.search || "";

      // Get users
      const query = `
         SELECT * FROM role
         WHERE Name LIKE ?
         AND isDeleted <> 1
         AND Name <> 'MasterAdmin'
         ORDER BY ${sortBy} ${order}
         LIMIT ${startIndex},${limit}
       `;

      const params = [`%${search}%`, startIndex, limit];

      const [roles] = await conn.query(query, params);

      // Get total number of users
      const countQuery = `
         SELECT COUNT(*) as total FROM role
         WHERE Name LIKE ?
         AND isDeleted <> 1
         AND Name <> 'MasterAdmin'
       `;

      const [count] = await conn.query(countQuery, [`%${search}%`]);

      const roleIds = roles.length > 0 ? roles.map((role) => role.id) : [""];

      const [permissions] = await conn.query(
        `SELECT R.id AS roleId , P.* FROM role R
        JOIN rolepermission RP
        ON R.id = RP.RoleId
        JOIN permission P
        ON P.id = RP.PermissionId
        WHERE R.id IN (?)`,
        [roleIds]
      );

      // Create response object
      const response = {
        data: roles.map((role) => {
          return {
            ...role,
            permissions: permissions.filter((x) => x.roleId === role.id),
          };
        }),
        total: count[0].total,
        currentPage: page,
        totalPages: Math.ceil(count[0].total / limit),
      };

      // Add links for pagination
      if (endIndex < count[0].total) {
        response.next = {
          page: page + 1,
          limit: limit,
        };
      }

      if (startIndex > 0) {
        response.previous = {
          page: page - 1,
          limit: limit,
        };
      }

      return successResponse(res, "Role retrieved successfully", response);
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  };

  static getRoleById = async (req, res) => {
    try {
      const id = req.query.id;
      const conn = await connPromise;
      const [roles] = await conn.query(`SELECT * FROM role WHERE id = ?`, id);

      if (roles.length === 0) {
        return failureResponse(res, 404, "Role not found");
      }

      const [permissions] = await conn.query(
        `SELECT R.id AS roleId , P.* FROM role R
        JOIN rolepermission RP
        ON R.id = RP.RoleId
        JOIN permission P
        ON P.id = RP.PermissionId
        WHERE R.id = ?`,
        [id]
      );

      const response = {
        data: roles.map((role) => {
          return {
            ...role,
            permissions: permissions.filter((x) => x.roleId === role.id),
          };
        }),
      };

      return successResponse(res, "Role Found successfully", response);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  };

  static updateRole = async (req, res) => {
    try {
      const conn = await connPromise;
      const id = req.params.id;
      const userId = req.userId;
      const { Name, Description, Permissions } = req.body;

      const [checkRole] = await conn.query(
        `SELECT * FROM role WHERE id = ? AND isDeleted <> 1`,
        id
      );

      if (checkRole.length === 0) {
        return failureResponse(res, 404, "Role not found");
      }

      // Update the Role details
      const updateRoleQuery = `
        UPDATE role
        SET Name = ?, Description = ?, updatedAt = NOW(),
        updatedBy = ?
        WHERE id = ?;
      `;
      const updateRoleParams = [Name, Description, userId, id];
      await conn.query(updateRoleQuery, updateRoleParams);

      await conn.query(`DELETE FROM rolepermission WHERE RoleId = ?`, [id]);

      if (Permissions.length > 0) {
        const PermissionsToUpdate = Permissions.map((permissionId) => [
          id,
          permissionId,
        ]);
        await conn.query(
          "INSERT INTO rolepermission (RoleId, PermissionId) VALUES ?",
          [PermissionsToUpdate]
        );
      }

      return successResponse(res, "Role updated successfully");
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  };

  static deleteRole = async (req, res) => {
    try {
      const id = req.params.id;
      const conn = await connPromise;
      const userId = req.userId;

      const [role] = await conn.query(
        "SELECT * FROM role WHERE id = ? and isDeleted <> 1",
        [id]
      );
      if (role.length === 0) {
        return failureResponse(res, 404, "Role not found");
      }

      const [userWithRole] = await conn.query(
        "SELECT * FROM users WHERE isDeleted <> 1 AND RoleId = ?",
        [id]
      );

      if (userWithRole.length > 0) {
        return failureResponse(
          res,
          403,
          "This role assign to employees so it can't be deleted"
        );
      }

      const deletedRole = await conn.query(
        "UPDATE role SET isDeleted=1 , deletedAt = NOW() , deletedBy = ? WHERE id = ?",
        [userId, id]
      );
      return successResponse(res, "Role deleted successfully", deletedRole);
    } catch (err) {
      return failureResponse(res, 400, err.message);
    }
  };
}

module.exports = RoleService;
