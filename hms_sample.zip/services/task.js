const { v4: uuidv4 } = require("uuid");
require("dotenv").config();
const moment = require("moment");

const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");
const { connPromise } = require("../config/connection");

class TaskService {
  static async createTask(req, res) {
    try {
      const userId = req.userId;
      const conn = await connPromise;
      const { Name, DueDate, Description, Priority, Status, AssignedTo } =
        req.body;

      const formatDueDate = DueDate != "null" ? moment(DueDate, "L") : null;

      const formatedDueDate = moment().format("YYYY-MM-DD");

      const id = uuidv4();
      if (!Name || !AssignedTo) {
        return failureResponse(res, 403, "Name and AssignedTo cant be empty");
      }

      if (AssignedTo.info === "E") {
        // Check if the assigned user exists in the user table
        const [user] = await conn.query("SELECT id FROM Users WHERE id = ?", [
          AssignedTo.id,
        ]);
        if (user.length === 0) {
          return failureResponse(res, 400, "Invalid user ID");
        }
      }
      if (AssignedTo.info === "D") {
        // Check if the assigned user exists in the user table
        const [department] = await conn.query(
          "SELECT id FROM Department WHERE id = ? AND isDeleted <> 1",
          [AssignedTo.id]
        );
        if (department.length === 0) {
          return failureResponse(res, 400, "Invalid Department ID");
        }
      }
      const [result] = await conn.query(
        `INSERT INTO Task (id, Name , DueDate , Description, Priority, Status , createdBy) 
        VALUES (?, ?, ?, ?, ?, ? , ? )`,
        [id, Name, formatedDueDate, Description, Priority, Status, userId]
      );

      const [assignedTo] = await conn.query(
        `INSERT INTO TaskAssignedTo (TaskId, UserId , DepartmentId) 
      VALUES (?, ?, ?)`,
        [
          id,
          AssignedTo.info === "E" ? AssignedTo.id : null,
          AssignedTo.info === "D" ? AssignedTo.id : null,
        ]
      );

      const response = {
        id,
        result,
      };
      return successResponse(res, "Task created successfully", response);
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }

  static async getTaskById(req, res) {
    try {
      const id = req.params.id;
      const conn = await connPromise;
      const [getTask] = await conn.query(`SELECT * FROM Task WHERE id = ?`, id);

      if (getTask.length === 0) {
        return failureResponse(res, 404, "Task not found");
      }

      const [TaskAssignedTo] = await conn.query(
        `SELECT * FROM TaskAssignedTo WHERE TaskId = ?`,
        id
      );

      const response = {
        data: getTask.map((getTask) => {
          return {
            ...getTask,
            TaskAssignedTo: TaskAssignedTo,
          };
        }),
      };

      return successResponse(res, "Task Found successfully", response);
    } catch (error) {
      return failureResponse(res, 500, error.message);
    }
  }

  static async getAllTasks(req, res) {
    try {
      const conn = await connPromise;

      // Pagination
      const page = parseInt(req.query.page) || 1; // Set default value to 1 if page is not provided or is NaN
      const limit = parseInt(req.query.limit) || 10;
      const startIndex = (page - 1) * limit;
      const endIndex = page * limit;

      // Sorting
      const sortBy = req.query.sortBy || "createdAt";
      const sortOrder = req.query.sortOrder || "asc";
      const order = sortOrder === "desc" ? "DESC" : "ASC";

      // Searching
      const search = req.query.search || "";

      // Get users
      const query = `
         SELECT * FROM Task
         WHERE Name LIKE ?
         AND isDeleted <> 1
         ORDER BY ${sortBy} ${order}
         LIMIT ${startIndex},${limit}
       `;

      const params = [`%${search}%`, startIndex, limit];

      const [tasks] = await conn.query(query, params);

      // Get total number of users
      const countQuery = `
         SELECT COUNT(*) as total FROM Task
         WHERE Name LIKE ?
         AND isDeleted <> 1
       `;

      const [count] = await conn.query(countQuery, [`%${search}%`]);

      // const [tasks] = await conn.query("SELECT * FROM Task");

      // Fetch assigned users and departments for each task
      const taskIds = tasks.length > 0 ? tasks.map((task) => task.id) : [""];

      const [assignedTo] = await conn.query(
        `SELECT
        ta.*,
        CASE
            WHEN ta.DepartmentId IS NULL THEN CONCAT(u.FirstName, ' ', u.LastName)
            WHEN ta.UserId IS NULL THEN d.name
        END AS Name
        FROM
            taskassignedto ta
        left JOIN
            users u ON ta.UserId = u.id
        left JOIN
            department d ON ta.DepartmentId = d.id
        WHERE
            ta.TaskId IN (?)`,
        [taskIds]
      );

      // Map assigned users and departments to their respective tasks
      const assignedToMap = {};
      assignedTo.forEach((assignment) => {
        const taskId = assignment.TaskId;
        if (!assignedToMap[taskId]) {
          assignedToMap[taskId] = {
            users: [],
            departments: [],
            name: assignment.Name,
          };
        }

        if (assignment.UserId) {
          assignedToMap[taskId].users.push(assignment.UserId);
        }

        if (assignment.DepartmentId) {
          assignedToMap[taskId].departments.push(assignment.DepartmentId);
        }
      });

      // Create response object
      const response = {
        data: tasks.map((task) => {
          return {
            ...task,
            assignedTo: assignedToMap[task.id] || {
              users: [],
              departments: [],
            },
          };
        }),
        total: count[0].total,
        currentPage: page,
        totalPages: Math.ceil(count[0].total / limit),
      };

      // Add links for pagination
      if (endIndex < count[0].total) {
        response.next = {
          page: page + 1,
          limit: limit,
        };
      }

      if (startIndex > 0) {
        response.previous = {
          page: page - 1,
          limit: limit,
        };
      }
      //   // Attach assigned users and departments to each task
      //   const tasksWithAssignment = tasks.map((task) => ({
      //     ...task,
      //     assignedTo: assignedToMap[task.id] || { users: [], departments: [] },
      //   }))

      return successResponse(res, "Tasks retrieved successfully", response);
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }

  static async editTask(req, res) {
    try {
      const conn = await connPromise;
      const id = req.params.id;
      const userId = req.userId;
      const { Name, DueDate, Description, Priority, Status, AssignedTo } =
        req.body;

      const [checkTask] = await conn.query(
        `SELECT * FROM Task WHERE id = ? AND isDeleted <> 1`,
        id
      );

      if (checkTask.length === 0) {
        return failureResponse(res, 404, "Task not found");
      }

      // Update the task details
      const updateTaskQuery = `
        UPDATE Task
        SET Name = ?, DueDate = ?, Description = ?, Priority = ?, Status = ? , updatedAt = NOW(),
        updatedBy = ?
        WHERE id = ?;
      `;
      const updateTaskParams = [
        Name,
        DueDate,
        Description,
        Priority,
        Status,
        userId,
        id,
      ];
      await conn.query(updateTaskQuery, updateTaskParams);

      // Update the assigned users and departments
      const deleteAssignedToQuery = `DELETE FROM TaskAssignedTo WHERE TaskId = ?`;
      await conn.query(deleteAssignedToQuery, [id]);

      if (AssignedTo.info === "E" && AssignedTo.id) {
        const assignUserQuery = `
          INSERT INTO TaskAssignedTo (TaskId, UserId)
          VALUES (?, ?);
        `;
        const assignUserParams = [id, AssignedTo.id];
        await conn.query(assignUserQuery, assignUserParams);
      } else if (AssignedTo.info === "D" && AssignedTo.id) {
        const assignDepartmentQuery = `
          INSERT INTO TaskAssignedTo (TaskId, DepartmentId)
          VALUES (?, ?);
        `;
        const assignDepartmentParams = [id, AssignedTo.id];
        await conn.query(assignDepartmentQuery, assignDepartmentParams);
      }

      return successResponse(res, "Task updated successfully");
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }

  static async deleteTask(req, res) {
    try {
      const id = req.params.id;
      const conn = await connPromise;
      const userId = req.userId;

      const [task] = await conn.query("SELECT * FROM Task WHERE id = ?", [id]);
      if (task.length === 0) {
        return failureResponse(res, 404, "Task not found");
      }
      const deletedTask = await conn.query(
        "UPDATE Task SET isDeleted=1 , deletedAt = NOW() , deletedBy = ? WHERE id = ?",
        [userId, id]
      );
      return successResponse(res, "Task deleted successfully", deletedTask);
    } catch (err) {
      return failureResponse(res, 400, err.message);
    }
  }

  static async getUserDepartmentName(req, res) {
    try {
      const conn = await connPromise;
      // Fetch users and departments from TaskAssignedTo table
      const [assignedTo] = await conn.query(`
        SELECT u.id AS id, CONCAT(u.FirstName, ' ', u.LastName) AS name, 'E' AS info
        FROM Users u
        WHERE u.id IS NOT NULL AND u.isDeleted <> 1
        UNION
        SELECT d.id AS id, d.Name AS name, 'D' AS info
        FROM Department d
        WHERE d.id IS NOT NULL AND d.isDeleted <> 1
      `);

      return successResponse(
        res,
        "Users and departments retrieved successfully",
        assignedTo
      );
    } catch (error) {
      return failureResponse(res, 400, error.message);
    }
  }
}

module.exports = TaskService;
