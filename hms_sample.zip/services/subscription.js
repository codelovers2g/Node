const { conn, query, connPromise } = require("../config/connection");
const { Organisation } = require("../models/organisation");
const { subscription } = require("../models/subscription");
const {
  successResponse,
  failureResponse,
} = require("../middlewares/errorHandler");

class subscriptionService {
  static getSubscriptionDetails = async (req, res) => {
    try {
      const { organisationName } = req.query;

      const [selectedOrganisation] = await Organisation.findAll({
        where: { Name: organisationName },
      });

      if (!selectedOrganisation) {
        return failureResponse(res, 404, "organisation not found");
      }

      const [subscriptionDetails] = await subscription.findAll({
        where: {
          organisationId: selectedOrganisation.Id,
        },
      });

      if (!subscriptionDetails) {
        return failureResponse(res, 404, "no subscription found");
      }

      return successResponse(res, "Subscription details get successfully", {
        Amount: subscriptionDetails.Amount,
        PackageName: subscriptionDetails.SubscriptionPackage,
        SubscriptionPurchaseDate: subscriptionDetails.SubscriptionPurchaseDate,
        SubscriptionExpiryDate: subscriptionDetails.SubscriptionExpiryDate,
      });
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  };
}

module.exports = subscriptionService;
