"use strict";
const { DataTypes } = require("sequelize");
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("Payment", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4,
      },
      UserId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      SubscriptionId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      PaymentId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      Status: {
        type: DataTypes.UUID,
        allowNull: true,
        defaultValue: "Pending",
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      updatedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
    });

    await queryInterface.addConstraint("Payment", {
      fields: ["SubscriptionId"],
      type: "foreign key",
      name: "fk_subsriptions_id",
      references: {
        table: "Subscriptions",
        field: "id",
      },
    });

    await queryInterface.addConstraint("Payment", {
      fields: ["UserId"],
      type: "foreign key",
      name: "fk_userspayment_id",
      references: {
        table: "Users",
        field: "id",
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("Payment");
  },
};
