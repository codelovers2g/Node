// candidate_education.js

"use strict";
const { DataTypes } = require("sequelize");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("CandidateEducation", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4,
      },
      CandidateId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      InstituteName: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      Course: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      StartYear: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      EndYear: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      Marks: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      createdBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      updatedAt: {
        type: DataTypes.DATE,
        defaultValue: null,
      },
      updatedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      isDeleted: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      deletedAt: {
        type: DataTypes.DATE,
        defaultValue: null,
      },
      deletedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
    });

    await queryInterface.addConstraint("CandidateEducation", {
      fields: ["CandidateId"],
      type: "foreign key",
      name: "fk_candidateeducation_candidate",
      references: {
        table: "Candidates",
        field: "id",
      },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("CandidateEducation");
  },
};
