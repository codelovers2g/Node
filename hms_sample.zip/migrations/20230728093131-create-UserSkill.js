"use strict";
const { DataTypes } = require("sequelize");
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("UserSkill", {
      UserId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      CandidateId: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      SkillId: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("UserSkill");
  },
};
