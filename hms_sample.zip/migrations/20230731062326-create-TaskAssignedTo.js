// task_assigned_to.js

"use strict";
const { DataTypes } = require("sequelize");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("TaskAssignedTo", {
      TaskId: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
      },
      UserId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      DepartmentId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      createdBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      updatedAt: {
        type: DataTypes.DATE,
        defaultValue: null,
      },
      updatedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
    });

    await queryInterface.addConstraint("TaskAssignedTo", {
      fields: ["TaskId"],
      type: "foreign key",
      name: "fk_taskassignedto_task",
      references: {
        table: "Task",
        field: "id",
      },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    });

    await queryInterface.addConstraint("TaskAssignedTo", {
      fields: ["UserId"],
      type: "foreign key",
      name: "fk_taskassignedto_user",
      references: {
        table: "Users",
        field: "id",
      },
    });

    await queryInterface.addConstraint("TaskAssignedTo", {
      fields: ["DepartmentId"],
      type: "foreign key",
      name: "fk_taskassignedto_department",
      references: {
        table: "Department",
        field: "id",
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("TaskAssignedTo");
  },
};
