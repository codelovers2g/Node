"use strict";
const { DataTypes } = require("sequelize");
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("RolePermission", {
      RoleId: {
        type: DataTypes.UUID,
        allowNull: true,
        references: {
          model: "Role",
          key: "id",
        },
      },
      PermissionId: {
        type: DataTypes.UUID,
        allowNull: true,
        references: {
          model: "Permission",
          key: "id",
        },
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("RolePermission");
  },
};
