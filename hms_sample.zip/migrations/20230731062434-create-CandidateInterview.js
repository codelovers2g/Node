// candidate_interview.js

"use strict";
const { DataTypes } = require("sequelize");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("CandidateInterview", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4,
      },
      CandidateId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      SelectedJobId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      ScheduleDateTime: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      StartDateTime: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      EndDateTime: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      InterviewStatus: {
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: "waiting",
      },
      InterviewMode: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      Location: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      CandidateReview: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      Rating: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      Matching: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    });

    await queryInterface.addConstraint("CandidateInterview", {
      fields: ["CandidateId"],
      type: "foreign key",
      name: "fk_candidateinterview_candidate",
      references: {
        table: "Candidates",
        field: "id",
      },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    });

    await queryInterface.addConstraint("CandidateInterview", {
      fields: ["SelectedJobId"],
      type: "foreign key",
      name: "fk_candidateinterview_jobfeed",
      references: {
        table: "JobFeed",
        field: "id",
      },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("CandidateInterview");
  },
};
