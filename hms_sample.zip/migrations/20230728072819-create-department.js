"use strict";
const { DataTypes, QueryTypes, Sequelize } = require("sequelize");
const { sequelizeDynamic } = require("../config/dbconfig");
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("Department", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4,
      },
      Name: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      Department_Rank: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      Manager: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      Description: {
        type: Sequelize.TEXT,
        allowNull: true,
      },
      Goals: {
        type: Sequelize.TEXT,
        allowNull: true,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      createdBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      updatedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
      updatedBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      isDeleted: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      },
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
      deletedBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
    });

    // await queryInterface.addConstraint("Department", {
    //   fields: ["Manager"],
    //   type: "foreign key",
    //   name: "fk_users_department", // You can give any name to the foreign key constraint
    //   references: {
    //     table: "Users", // The table this foreign key references
    //     field: "id", // The column in the referenced table
    //   },
    //   onDelete: "CASCADE",
    //   onUpdate: "CASCADE",
    // });

    // Add the afterCreate hook to add the foreign key constraint
    // await queryInterface.sequelize.query(
    //   `ALTER TABLE Department ADD CONSTRAINT fk_users_department FOREIGN KEY (Manager) REFERENCES Users(id) ON DELETE CASCADE ON UPDATE CASCADE;`
    // );
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("Department");
  },
};
