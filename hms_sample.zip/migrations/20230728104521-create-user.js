"use strict";
const { DataTypes } = require("sequelize");
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("Users", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4,
      },
      CandidateId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      EmployeeNumber: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      FirstName: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      LastName: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      Email: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true,
      },
      Password: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      PhoneNumber: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      GenderId: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      RoleId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      EthnicityId: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      DateHired: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      JobTitle: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      DepartmentId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      PerformanceMetrics: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      DateOfJoining: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      Reliability: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      Behaviour: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      SchoolAttendant: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      Notes: {
        type: Sequelize.TEXT,
        allowNull: true,
        defaultValue: null,
      },
      UserRank: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      Resume: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      DrivingLicense: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      EmployeeAgreement: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      ProfilePhoto: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      createdBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      updatedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
      updatedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      isDeleted: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      },
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
      deletedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
    });

    // Add foreign key constraint after creating the table
    // await queryInterface.addConstraint("Users", {
    //   fields: ["CandidateId"],
    //   type: "foreign key",
    //   name: "fk_users_candidate",
    //   references: {
    //     table: "Candidates",
    //     field: "id",
    //   },
    //   onDelete: "CASCADE",
    //   onUpdate: "CASCADE",
    // });

    // await queryInterface.Sequelize.query(
    //   `ALTER TABLE Users ADD CONSTRAINT fk_users_candidate FOREIGN KEY (CandidateId) REFERENCES Candidates(id);`
    // );

    await queryInterface.addConstraint("Users", {
      fields: ["GenderId"],
      type: "foreign key",
      name: "fk_users_gender",
      references: {
        table: "Gender",
        field: "id",
      },
    });
    await queryInterface.addConstraint("Users", {
      fields: ["RoleId"],
      type: "foreign key",
      name: "fk_users_role",
      references: {
        table: "Role",
        field: "id",
      },
    });
    await queryInterface.addConstraint("Users", {
      fields: ["EthnicityId"],
      type: "foreign key",
      name: "fk_users_ethnicity",
      references: {
        table: "Ethnicity",
        field: "id",
      },
    });
    await queryInterface.addConstraint("Users", {
      fields: ["DepartmentId"],
      type: "foreign key",
      name: "fk_users_department",
      references: {
        table: "Department",
        field: "id",
      },
    });
    await queryInterface.addConstraint("Department", {
      fields: ["Manager"],
      type: "foreign key",
      name: "fk_department_manager",
      name: "fk_department_manager",
      references: {
        table: "Users",
        field: "id",
      },
    });
    await queryInterface.addConstraint("UserSkill", {
      fields: ["UserId"],
      type: "foreign key",
      name: "fk_users_skill",
      references: {
        table: "Users",
        field: "id",
      },
    });
    await queryInterface.addConstraint("UserSkill", {
      fields: ["SkillId"],
      type: "foreign key",
      name: "fk_skills",
      references: {
        table: "Skills",
        field: "id",
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("Users");
  },
};
