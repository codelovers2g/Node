// task.js

"use strict";
const { DataTypes } = require("sequelize");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("Task", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
      },
      Name: {
        type: DataTypes.STRING(255),
        allowNull: false,
      },
      DueDate: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      Description: {
        type: DataTypes.TEXT,
        defaultValue: null,
      },
      Priority: {
        type: DataTypes.STRING(255),
        allowNull: false,
      },
      Status: {
        type: DataTypes.STRING(255),
        defaultValue: null,
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      createdBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      updatedAt: {
        type: DataTypes.DATE,
        defaultValue: null,
      },
      updatedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      isDeleted: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      deletedAt: {
        type: DataTypes.DATE,
        defaultValue: null,
      },
      deletedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("Task");
  },
};
