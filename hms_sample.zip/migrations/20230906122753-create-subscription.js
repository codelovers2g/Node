"use strict";
const { DataTypes } = require("sequelize");
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("Subscriptions", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4,
      },
      SubscriptionPackage: {
        type: Sequelize.STRING,
      },
      Amount: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      EmployeeSize: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      SubscriptionPurchaseDate: {
        type: Sequelize.STRING,
      },
      SubscriptionExpiryDate: {
        type: Sequelize.STRING,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      updatedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("Subscriptions");
  },
};
