// candidateSkill.js

"use strict";
const { DataTypes } = require("sequelize");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("CandidateSkill", {
      CandidateId: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
          model: "Candidates", // The table this foreign key references
          key: "id", // The column in the referenced table
        },
        onDelete: "CASCADE",
        onUpdate: "CASCADE",
      },
      SkillId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "Skills", // The table this foreign key references
          key: "id", // The column in the referenced table
        },
        onDelete: "CASCADE",
        onUpdate: "CASCADE",
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("CandidateSkill");
  },
};
