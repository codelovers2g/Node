"use strict";
const { DataTypes } = require("sequelize");
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("AuditLogs", {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      CreatedBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      Type: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      Model: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      Messages: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      InputTokens: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      ResponseTokens: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      TotalTokens: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      RequestType: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      Response: {
        type: Sequelize.TEXT,
        allowNull: true,
      },
      StatusCode: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      RecordId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      Price: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      DateTime: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("AuditLogs");
  },
};
