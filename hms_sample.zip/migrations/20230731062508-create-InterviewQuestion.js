// interview_question.js

"use strict";
const { DataTypes } = require("sequelize");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("InterviewQuestion", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4,
      },
      InterviewId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      Question: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      Answer: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      IsCorrect: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    });

    await queryInterface.addConstraint("InterviewQuestion", {
      fields: ["InterviewId"],
      type: "foreign key",
      name: "fk_interviewquestion_candidateinterview",
      references: {
        table: "CandidateInterview",
        field: "id",
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("InterviewQuestion");
  },
};
