"use strict";
const { DataTypes } = require("sequelize");
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("Candidates", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4,
      },
      FirstName: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      LastName: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      Email: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      PhoneNumber: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      GenderId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      CurrentState: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      CurrentCity: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      CurrentCompany: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      CurrentCtc: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      ExpectedCtc: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      WorkStatus: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      InterviewResult: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      Resume: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      ProfilePhoto: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      createdBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      updatedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
      updatedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      isDeleted: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      },
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
      deletedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
    });

    // Add foreign key constraint
    await queryInterface.addConstraint("Candidates", {
      fields: ["GenderId"],
      type: "foreign key",
      name: "fk_gender_id",
      references: {
        table: "Gender",
        field: "id",
      },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    });

    await queryInterface.addConstraint("UserSkill", {
      fields: ["CandidateId"],
      type: "foreign key",
      name: "fk_candidate_skill",
      references: {
        table: "Candidates",
        field: "id",
      },
    });

    await queryInterface.addConstraint("Users", {
      fields: ["CandidateId"],
      type: "foreign key",
      name: "fk_users_candidate",
      references: {
        table: "Candidates",
        field: "id",
      },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("Candidates");
  },
};
