"use strict";
const { DataTypes } = require("sequelize");
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("JobFeed", {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
      },
      Title: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      Schedule: {
        type: Sequelize.STRING,
        defaultValue: null,
      },
      Department: {
        type: DataTypes.UUID,
        allowNull: true,
        onDelete: "CASCADE",
        onUpdate: "CASCADE",
      },
      Location: {
        type: Sequelize.STRING,
        defaultValue: null,
      },
      Description: {
        type: Sequelize.TEXT,
        defaultValue: null,
      },
      Goals: {
        type: Sequelize.STRING,
        defaultValue: null,
      },
      ExpectedHiring: {
        type: Sequelize.INTEGER,
        defaultValue: null,
      },
      status: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: "active",
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      createdBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      updatedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
      updatedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
      isDeleted: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      },
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null,
      },
      deletedBy: {
        type: DataTypes.UUID,
        defaultValue: null,
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("JobFeed");
  },
};
