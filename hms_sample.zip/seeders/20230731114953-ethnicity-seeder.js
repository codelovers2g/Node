"use strict";
const { DataTypes } = require("sequelize");
module.exports = {
  async up(queryInterface, Sequelize) {
    return queryInterface.bulkInsert(
      "Ethnicity",
      [
        { id: 1, name: "Asian" },
        { id: 2, name: "African" },
        { id: 3, name: "European" },
        { id: 4, name: "Hispanic/Latino" },
        { id: 5, name: "Native American/Indigenous" },
        { id: 6, name: "Pacific Islander" },
        { id: 7, name: "Middle Eastern" },
        { id: 8, name: "Mixed or Multiracial" },
      ],
      {
        ignoreDuplicates: true,
      }
    );
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete("Ethnicity", null, {});
  },
};
