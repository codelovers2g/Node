"use strict";
const { DataTypes } = require("sequelize");
const { v4: uuidv4 } = require("uuid");

module.exports = {
  async up(queryInterface, Sequelize) {
    const existingDepartment = await queryInterface.rawSelect(
      "Department",
      {
        where: { Name: "HR" },
      },
      ["id"]
    );

    if (!existingDepartment) {
      return queryInterface.bulkInsert("Department", [
        { id: uuidv4(), Name: "HR" },
      ]);
    }
    return Promise.resolve(); // Do nothing if department already exists
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete("Department", null, {});
  },
};
