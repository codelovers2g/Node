"use strict";

module.exports = {
  async up(queryInterface, Sequelize) {
    return queryInterface.bulkInsert(
      "Skills",
      [
        { id: 1, Skill: "Development" },
        { id: 2, Skill: "Project management" },
        { id: 3, Skill: "Team lead" },
      ],
      {
        ignoreDuplicates: true, // To ignore duplicate inserts
      }
    );
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete("Skills", null, {});
  },
};
