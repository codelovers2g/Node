module.exports = {
  up: async (queryInterface, Sequelize) => {
    const defaultSettings = [
      {
        Field: "InterviewDurationTime",
        Value: String(30 * 60 * 1000),
      },
      {
        Field: "InterviewStartDurationTime",
        Value: String(30 * 60 * 1000),
      },
    ];

    for (const setting of defaultSettings) {
      const existingSetting = await queryInterface.rawSelect(
        "Settings",
        {
          where: {
            Field: setting.Field,
            Value: setting.Value,
          },
        },
        ["Field", "Value"]
      );

      // If the setting does not exist, insert it
      if (!existingSetting) {
        await queryInterface.bulkInsert("Settings", [setting], {});
      }
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Settings", null, {});
  },
};
