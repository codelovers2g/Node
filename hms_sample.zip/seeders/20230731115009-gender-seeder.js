"use strict";
const { DataTypes } = require("sequelize");
module.exports = {
  async up(queryInterface, Sequelize) {
    return queryInterface.bulkInsert(
      "Gender",
      [
        { id: 1, name: "Male" },
        { id: 2, name: "Female" },
      ],
      {
        ignoreDuplicates: true,
      }
    );
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete("Gender", null, {});
  },
};
