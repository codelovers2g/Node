exports.serverErrorHandler = (req, res) => {
  res.status(500).json({ error: "Internal Server Error" });
};
exports.notFoundErrorHandler = (err, req, res, next) => {
  res.status(404).json({ error: "Not Found" });
};
exports.badRequestErrorHandler = (err, req, res, next) => {
  res.status(400).json({ error: "Bad Request" });
};

// success response function
exports.successResponse = (res, message, data = null) => {
  return res.status(200).json({
    success: true,
    message,
    data,
  });
};

// failure response function
exports.failureResponse = (res, statusCode, message) => {
  return res.status(statusCode).json({
    success: false,
    message,
  });
};
