const fs = require("fs");
const multer = require("multer");
const { connPromise } = require("../config/connection");
const jwt = require("jsonwebtoken");
const { failureResponse } = require("./errorHandler");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const token = req.headers["x-access-token"];
    if (!token) {
      return failureResponse(file, 401, "Authentication error");
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const { OrganisationName } = decoded;
    const path = `Files/${OrganisationName}`;
    fs.mkdirSync(path, { recursive: true });
    return cb(null, path);
  },
  filename: (req, file, cb) => {
    console.log("what in req.file +++++++++", req.files);
    cb(null, file.originalname + "(" + "#" + Date.now());
  },
});
const upload = multer({ storage: storage });

module.exports = upload;
