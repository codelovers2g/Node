const jwt = require("jsonwebtoken");
require("dotenv").config();
const { failureResponse } = require("./errorHandler");
const { connPromise } = require("../config/connection");

const checkPermissions = (requiredPermission) => {
  return async (req, res, next) => {
    try {
      const conn = await connPromise;
      const [userPermissions] = await conn.query(
        `
            SELECT p.Name
            FROM users AS u
            JOIN role AS r ON u.RoleId = r.id
            JOIN rolepermission AS rp ON r.id = rp.RoleId
            JOIN permission AS p ON rp.PermissionId = p.id
            WHERE u.id = ?
          `,
        [req.userId]
      );

      // Check if the user has "MasterAdmin" permission
      const hasMasterAdminPermission = userPermissions.some(
        (permission) => permission.Name === "MasterAdmin"
      );

      // If the user has "MasterAdmin" permission, allow all access and exit the middleware
      if (hasMasterAdminPermission) {
        return next();
      }

      const hasPermission = userPermissions.some(
        (permission) => permission.Name === requiredPermission
      );

      if (!hasPermission) {
        return failureResponse(
          res,
          403,
          "You don't have the required permission"
        );
      }

      next();
    } catch (err) {
      return failureResponse(res, 500, err.message);
    }
  };
};

module.exports = { checkPermissions };
