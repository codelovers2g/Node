const jwt = require("jsonwebtoken");
require("dotenv").config();
const { failureResponse } = require("./errorHandler");
const { connPromise } = require("../config/connection");
const userAuth = async (req, res, next) => {
  const token = req.headers["x-access-token"];
  if (!token) {
    return failureResponse(res, 401, "Authentication error");
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const { dbName } = decoded;
    const { OrganisationName } = decoded;
    const { userId, OrganisationId } = decoded;
    const conn = await connPromise;
    await conn.query(`USE ${dbName}`);
    console.log("dbName +++++++++++++++", dbName);
    req.OrganisationName = OrganisationName;
    req.userId = userId;
    req.OrganisationId = OrganisationId;
    next();
  } catch (err) {
    return failureResponse(res, 401, "Auth token verification failed");
  }
};

module.exports = userAuth;
