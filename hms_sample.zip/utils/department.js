const { v4: uuidv4 } = require("uuid");
const id = uuidv4();
const department = [{ id: uuidv4(), Name: "HR" }];
const departmentInsertQueries = department.map((department) => [
  department.id,
  department.Name,
]);

const departmentValues = departmentInsertQueries
  .map((query) => `('${query[0]}', '${query[1]}')`)
  .join(", ");

module.exports = { departmentValues };
