const gender = [
  { id: 1, name: "Male" },
  { id: 2, name: "Female" },
];
const genderInsertQueries = gender.map((gender) => [gender.id, gender.name]);

const genderValues = genderInsertQueries
  .map((query) => `('${query[0]}', '${query[1]}')`)
  .join(", ");

module.exports = { genderValues };
