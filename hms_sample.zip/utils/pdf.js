const fs = require('fs');
const pdf = require("pdf-parse");

exports.pdfToText = async (path) =>{
  const pdfData = fs.readFileSync(path);
  var text = await pdf(pdfData).then((data) => {
    return data.text;
  });
  return text;
}

