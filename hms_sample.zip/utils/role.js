const { v4: uuidv4 } = require("uuid");
const id = uuidv4();
const role = [
  { id: uuidv4(), name: "Admin" },
  { id: uuidv4(), name: "MasterAdmin" },
];
const roleInsertQueries = role.map((role) => [role.id, role.name]);

// const roleValues = roleInsertQueries
//   .map((query) => `('${query[0]}', '${query[1]}')`)
//   .join(", ");

module.exports = { roleInsertQueries };
