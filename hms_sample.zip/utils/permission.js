const { v4: uuidv4 } = require("uuid");
const id = uuidv4();
const permission = [
  { id: uuidv4(), name: "Employee.view" },
  { id: uuidv4(), name: "Employee.add" },
  { id: uuidv4(), name: "Employee.edit" },
  { id: uuidv4(), name: "Employee.delete" },
  { id: uuidv4(), name: "Department.view" },
  { id: uuidv4(), name: "Department.add" },
  { id: uuidv4(), name: "Department.edit" },
  { id: uuidv4(), name: "Department.delete" },
  { id: uuidv4(), name: "Jobfeed.view" },
  { id: uuidv4(), name: "Jobfeed.add" },
  { id: uuidv4(), name: "Jobfeed.edit" },
  { id: uuidv4(), name: "Jobfeed.delete" },
  { id: uuidv4(), name: "Analytics.view" },
  { id: uuidv4(), name: "Task.view" },
  { id: uuidv4(), name: "Task.add" },
  { id: uuidv4(), name: "Task.edit" },
  { id: uuidv4(), name: "Task.delete" },
  { id: uuidv4(), name: "Setting.view" },
  { id: uuidv4(), name: "Candidate.view" },
  { id: uuidv4(), name: "Candidate.add" },
  { id: uuidv4(), name: "Candidate.edit" },
  { id: uuidv4(), name: "Candidate.delete" },
  { id: uuidv4(), name: "Calendar.view" },
  { id: uuidv4(), name: "Role.view" },
  { id: uuidv4(), name: "Role.add" },
  { id: uuidv4(), name: "Role.edit" },
  { id: uuidv4(), name: "Role.delete" },
  { id: uuidv4(), name: "MasterAdmin" },
];
const permissionInsertQueries = permission.map((permission) => [
  permission.id,
  permission.name,
]);

// const permissionValues = permissionInsertQueries
//   .map((query) => `('${query[0]}', '${query[1]}')`)
//   .join(", ");

module.exports = { permissionInsertQueries };
