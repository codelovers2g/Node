const skills = [
  { id: 1, Skill: "Development" },
  { id: 2, Skill: "Project management" },
  { id: 3, Skill: "Team lead" },
];

const skillInsertQueries = skills.map((skill) => [skill.id, skill.Skill]);

const skillValues = skillInsertQueries
  .map((query) => `('${query[0]}', '${query[1]}')`)
  .join(", ");

module.exports = { skillValues };
