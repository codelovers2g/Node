const ethnicity = [
  { id: 1, name: "Asian" },
  { id: 2, name: "African" },
  { id: 3, name: "European" },
  { id: 4, name: "Hispanic/Latino" },
  { id: 5, name: "Native American/Indigenous" },
  { id: 6, name: "Pacific Islander" },
  { id: 7, name: "Middle Eastern" },
  { id: 8, name: "Mixed or Multiracial" },
];

const ethnicityInsertQueries = ethnicity.map((ethnicity) => [
  ethnicity.id,
  ethnicity.name,
]);

const ethnicityValues = ethnicityInsertQueries
  .map((query) => `('${query[0]}', '${query[1]}')`)
  .join(", ");

module.exports = { ethnicityValues };
