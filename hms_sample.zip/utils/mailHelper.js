const nodemailer = require('nodemailer')
require('dotenv').config()

const mailHelper = async (options) =>{
    let mailTransporter = nodemailer.createTransport({
        service: "gmail",
        port: 587,
        secure: false,
        auth: {
            user: process.env.NODE_MAILER_AUTH_USERNAME,
            pass: process.env.NODE_MAILER_AUTH_PASSWORD
        }
    });

    let mailDetails = {
        from:  process.env.NODE_MAILER_AUTH_USERNAME,
        to: options.email,
        subject: options.subject,
        text: options.message,
        html:options.message
    };

    await mailTransporter.sendMail(mailDetails)

}

module.exports = mailHelper