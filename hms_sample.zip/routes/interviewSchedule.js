const express = require("express");
const router = express.Router();
const interviewController = require("../controllers/interviewSchedule");
const userAuth = require("../middlewares/auth");

router.post(
  "/interview/add",
  userAuth,
  interviewController.addInterviewSchedule
);

router.get("/interview/getDetails", interviewController.getInterviewDetails);

router.post("/interview/start", interviewController.startInterview);

router.post("/interview/saveAnswer", interviewController.saveAnswer);

router.post(
  "/interview/getQuestionOnIndex",
  interviewController.getQuestionOnIndex
);

router.get(
  "/interview/getCandidateByInterviewId",
  interviewController.getCandidateByInterviewId
);

module.exports = router;
