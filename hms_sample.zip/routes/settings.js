const express = require("express");
const router = express.Router();
const settingsController = require("../controllers/settings");

router.get("/settings/get", settingsController.getSetting);

module.exports = router;
