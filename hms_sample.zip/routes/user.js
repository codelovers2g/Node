const express = require("express");
const router = express.Router();

const userController = require("../controllers/user");
const upload = require("../middlewares/multer");
const userAuth = require("../middlewares/auth");
const { checkPermissions } = require("../middlewares/checkPermissions");

router.post(
  "/user/create",
  userAuth,
  checkPermissions("Employee.add"),
  upload.fields([
    { name: "ResumeDoc" },
    { name: "DrivingLicenseDoc" },
    { name: "EmployeeAgreementDoc" },
    { name: "ProfilePhotoDoc" },
  ]),
  userController.createUser
);

router.get(
  "/user/getAll",
  userAuth,
  checkPermissions("Employee.view"),
  userController.getAllUsers
);
router.get(
  "/user/getUserById/:id",
  userAuth,
  checkPermissions("Employee.view"),
  userController.getUserById
);
router.put(
  "/user/edit/:id",
  userAuth,
  checkPermissions("Employee.edit"),
  upload.fields([
    { name: "ResumeDoc" },
    { name: "DrivingLicenseDoc" },
    { name: "EmployeeAgreementDoc" },
    { name: "ProfilePhotoDoc" },
  ]),
  userController.updateUser
);
router.delete(
  "/user/delete/:id",
  userAuth,
  checkPermissions("Employee.delete"),
  userController.deleteUser
);

router.get("/user/getIdName", userAuth, userController.getIdName);

router.post("/user/getDocument", userAuth, userController.getDocument);

module.exports = router;
