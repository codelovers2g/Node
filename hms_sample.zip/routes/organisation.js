const express = require("express");
const router = express.Router();
const organisationController = require("../controllers/organisation");
const organisationTypeController = require("../controllers/organisationType");
const { getEthnicity } = require("../controllers/ethnicity");
const { getGender } = require("../controllers/gender");
const { getSkills } = require("../controllers/skills");
const userAuth = require("../middlewares/auth");
const upload = require("../middlewares/multer");

router.post("/organisation/register", organisationController.register);
router.get("/organisation/getAll", organisationController.getAllOrganisations);
router.post("/login", organisationController.loginUser);
router.put("/password/change/:id", userAuth, organisationController.changePassword);
router.get(
  "/getPermissionsByUserId/:id",
  userAuth,
  organisationController.getPermissions
);
router.get(
  "/getAllOrganisationsType",
  organisationTypeController.getOrganisationType
);

router.get("/getAllEthnicity", userAuth, getEthnicity);
router.get("/getGender", userAuth, getGender);
router.get("/getSkills", userAuth, getSkills);

router.put(
  "/profile/edit/:id",
  userAuth,
  upload.fields([{ name: "ProfilePhotoDoc" }]),
  organisationController.editLoggedInUserProfile
);

module.exports = router;
