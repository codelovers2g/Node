const express = require("express");
const router = express.Router();
const notificationController = require("../controllers/notification");
const userAuth = require("../middlewares/auth");
const { checkPermissions } = require("../middlewares/checkPermissions");

router.post(
  "/notifications/create",
  userAuth,
  notificationController.createNotifications
);

router.get(
  "/notifications/get",
  userAuth,
  notificationController.getAllNotifications
);

module.exports = router;
