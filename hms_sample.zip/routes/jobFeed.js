const express = require("express");
const router = express.Router();
const jobFeedController = require("../controllers/jobFeed");
const userAuth = require("../middlewares/auth");
const { checkPermissions } = require("../middlewares/checkPermissions");

router.post(
  "/job/add",
  userAuth,
  checkPermissions("Jobfeed.add"),
  jobFeedController.createJobs
);
router.post(
  "/job/getAll",
  userAuth,
  checkPermissions("Jobfeed.view"),
  jobFeedController.getAllJobs
);
router.get(
  "/job/getById/:id",
  userAuth,
  checkPermissions("Jobfeed.view"),
  jobFeedController.getJobById
);

router.put(
  "/job/edit/:id",
  userAuth,
  checkPermissions("Jobfeed.edit"),
  jobFeedController.editJob
);
router.delete(
  "/job/delete/:id",
  userAuth,
  checkPermissions("Jobfeed.delete"),
  jobFeedController.deleteJob
);
router.put(
  "/job/status/:id",
  userAuth,
  checkPermissions("Jobfeed.view"),
  jobFeedController.updateJobStatus
);
router.post(
  "/job/share",
  userAuth,
  checkPermissions("Jobfeed.view"),
  jobFeedController.shareJob
);

router.post(
  "/job/getAllCandidatesOfJobFeed/:id",
  userAuth,
  checkPermissions("Jobfeed.view"),
  jobFeedController.getAllCandidatesOfJobFeed
);

router.get(
  "/job/interview/getAll",
  userAuth,
  checkPermissions("Jobfeed.view"),
  jobFeedController.getAllInterviews
);

router.put(
  "/job/interview/schedule/:id",
  userAuth,
  checkPermissions("Jobfeed.view"),
  jobFeedController.editInterviews
);
router.put(
  "/job/interview/candidateStatus/:id",
  userAuth,
  checkPermissions("Jobfeed.view"),
  jobFeedController.setStatus
);

router.get("/job/getall/names", userAuth, jobFeedController.getAllJobNames);

module.exports = router;
