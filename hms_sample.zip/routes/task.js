const express = require("express");
const router = express.Router();
const taskController = require("../controllers/task");
const userAuth = require("../middlewares/auth");
const { checkPermissions } = require("../middlewares/checkPermissions");
router.post(
  "/task/add",
  userAuth,
  checkPermissions("Task.add"),
  taskController.createTask
);

router.get(
  "/task/get/:id",
  userAuth,
  checkPermissions("Task.view"),
  taskController.getTaskById
);

router.get(
  "/task/getAll",
  userAuth,
  checkPermissions("Task.view"),
  taskController.getAllTasks
);

router.put(
  "/task/edit/:id",
  userAuth,
  checkPermissions("Task.edit"),
  taskController.editTask
);

router.delete(
  "/task/delete/:id",
  userAuth,
  checkPermissions("Task.delete"),
  taskController.deleteTask
);

router.get(
  "/task/getUserDepartmentName",
  userAuth,
  checkPermissions("Task.view"),
  taskController.getUserDepartmentName
);

module.exports = router;
