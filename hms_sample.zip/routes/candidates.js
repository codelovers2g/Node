const express = require("express");
const router = express.Router();

const candidateController = require("../controllers/candidates");
const upload = require("../middlewares/multer");
const userAuth = require("../middlewares/auth");
const { checkPermissions } = require("../middlewares/checkPermissions");

router.post(
  "/candidate/create",
  userAuth,
  checkPermissions("Candidate.add"),
  upload.fields([{ name: "ResumeDoc" }, { name: "ProfilePhotoDoc" }]),
  candidateController.createCandidate
);

router.get(
  "/candidate/getAll",
  userAuth,
  checkPermissions("Candidate.view"),
  candidateController.getAllCandidate
);

router.get(
  "/candidate/getAllRegisterd",
  candidateController.getAllRegisterdCandidates
);

router.get(
  "/candidate/getById/:id",
  userAuth,
  checkPermissions("Candidate.view"),
  candidateController.getCandidateById
);

router.put(
  "/candidate/edit/:id",
  userAuth,
  checkPermissions("Candidate.edit"),
  upload.fields([{ name: "ResumeDoc" }, { name: "ProfilePhotoDoc" }]),
  candidateController.updateCandidate
);

router.delete(
  "/candidate/delete/:id",
  userAuth,
  checkPermissions("Candidate.delete"),
  candidateController.deleteCandidate
);

router.post(
  "/candidate/getDocument",
  userAuth,
  candidateController.getDocument
);

router.get(
  "/candidate/getJobsByDepartment/:id",
  userAuth,
  candidateController.getJobsOfDepartment
);
router.get(
  "/candidate/getAllJobsOfCandidate/:id",
  userAuth,
  candidateController.getAllJobsOfCandidate
);
router.get(
  "/candidate/getAllInformation",
  userAuth,
  candidateController.getAllInformationOfCandidate
);

router.post(
  "/candidate/bulkupload",
  userAuth,
  upload.single("uploaduser"),
  candidateController.candidateBulkUpload
);

module.exports = router;
