const express = require("express");
const router = express.Router();
const userAuth = require("../middlewares/auth");
const paymentController = require("../controllers/stripePayment");

router.post("/payment/add", userAuth, paymentController.createPayment);

module.exports = router;
