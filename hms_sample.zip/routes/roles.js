const express = require("express");
const router = express.Router();
const userAuth = require("../middlewares/auth");
const rolesController = require("../controllers/roles");
const { checkPermissions } = require("../middlewares/checkPermissions");
router.get(
  "/roles/getRole",
  userAuth,
  checkPermissions("Role.view"),
  rolesController.getRole
);

router.get(
  "/roles/getPermissionList",
  userAuth,
  checkPermissions("Role.view"),
  rolesController.getPermissionList
);

router.post(
  "/roles/createRole",
  userAuth,
  checkPermissions("Role.add"),
  rolesController.createRole
);

router.get(
  "/roles/getAllRoles",
  userAuth,
  checkPermissions("Role.view"),
  rolesController.getAllRoles
);

router.get(
  "/roles/getRoleById",
  userAuth,
  checkPermissions("Role.view"),
  rolesController.getRoleById
);

router.put("/roles/updateRole/:id", userAuth, rolesController.updateRole);

router.delete("/roles/deleteRole/:id", userAuth, rolesController.deleteRole);

module.exports = router;
