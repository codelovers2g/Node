const express = require("express");
const router = express.Router();
const departmentController = require("../controllers/department");
const userAuth = require("../middlewares/auth");
const { checkPermissions } = require("../middlewares/checkPermissions");
router.post(
  "/department/add",
  userAuth,
  checkPermissions("Department.add"),
  departmentController.createDepartment
);
router.get(
  "/department/getAll",
  userAuth,
  checkPermissions("Department.view"),
  departmentController.getAllDepartments
);
router.get(
  "/department/getById/:id",
  userAuth,
  checkPermissions("Department.view"),
  departmentController.getDepartmentById
);
router.put(
  "/department/edit/:id",
  userAuth,
  checkPermissions("Department.edit"),
  departmentController.editDepartments
);
router.delete(
  "/department/delete/:id",
  userAuth,
  checkPermissions("Department.delete"),
  departmentController.deleteDepartment
);

router.post(
  "/department/viewEmployee/:id",
  userAuth,
  checkPermissions("Department.view"),
  departmentController.viewDepartmentEmployees
);

router.get(
  "/department/get/totalCandidates/:id",
  userAuth,
  departmentController.totalCandidatesOfDepartment
);

module.exports = router;
