const express = require("express");
const router = express.Router();
const dashboardController = require("../controllers/dashboard");
const userAuth = require("../middlewares/auth");
const { checkPermissions } = require("../middlewares/checkPermissions");
router.get(
  "/dashboard/getAllCandidatesCount",
  userAuth,
  dashboardController.getAllCandidatesCounts
);

router.get(
  "/dashboard/getAvarageUserRating",
  userAuth,
  dashboardController.getAvarageUserRating
);

router.get(
  "/dashboard/getTodayTask",
  userAuth,
  dashboardController.getTodayTask
);

router.get(
  "/dashboard/getAverageUserRankingOfDepartment",
  userAuth,
  dashboardController.getAverageUserRankingOfDepartment
);

module.exports = router;
